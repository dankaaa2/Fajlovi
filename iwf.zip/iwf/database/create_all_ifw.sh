#!/bin/ksh
## =============================================================================
##
##          Copyright (c) 1998 - 2002 Portal Software (Hamburg) GmbH.
##                            All rights reserved.
##               This material is the confidential property of
##       Portal Software (Hamburg) GmbH or its subsidiaries or licensors
##    and may be used, reproduced, stored or transmitted only in accordance
##            with a valid Portal license or sublicense agreement.
##
## -----------------------------------------------------------------------------
## Module Description:
##    Shell script to create all custom tables in Integrate db scheme
##
## -----------------------------------------------------------------------------
## Responsible: Portal Software
##
## $RCSfile: create_all_ifw.sh,v $
## $Revision: 1.3 $
## $Author: pin24 $
## $Date: 2005/09/05 10:45:24 $
##
##------------------------------------------------------------------------------
## History:
## $Id: create_all_ifw.sh,v 1.3 2005/09/05 10:45:24 pin24 Exp $
## $Log: create_all_ifw.sh,v $
## Revision 1.3  2005/09/05 10:45:24  pin24
## STY: corrected checks of input arguments
##
## Revision 1.2  2005/08/04 10:49:22  pin42
## wkokorzy: corrected checks of input arguments
##
## Revision 1.1  2005/07/26 11:03:58  pin24
## STY: Initial release
##
##
## =============================================================================

## -----------------------------------------------------------------------------
## Usage: create_all_ifw.sh [instance] [user] [password]
##        will try to find the db instance, db user and db password in the
##        arguments instance, user and password. 
##        If they are not found there, the environment variables 
##        IFW_DBINSTANCE, IFW_DBUSER and IFW_DBPASSWD are looked up.
##        If they are not found there, they are prompted for interactively.
## -----------------------------------------------------------------------------

LOGFILE=create_all_ifw.log

# Get DB instance, user and password from arguments, if they were not specified
# assume they are already in the environment variables.
if [[ $1 != "" ]] then
   IFW_DBINSTANCE=$1
fi
if [[ $2 != "" ]] then
   IFW_DBUSER=$2
fi
if [[ $3 != "" ]] then
   IFW_DBPASSWD=$3
fi

# If instance and user were not given as argument or variable,
# read them interactively. Password will be read interactively later on
# by sqlplus WITHOUT echo on stdout
if [[ $IFW_DBINSTANCE == "" ]]
   then
   echo "Please enter the instance name of the Integraet database: \c"
   read IFW_DBINSTANCE
fi
if [[ $IFW_DBUSER == "" ]]
   then
   echo "Please enter the database user name for that instance: \c"
   read IFW_DBUSER
fi

# Create login string
IFW_LOGIN=$IFW_DBUSER@$IFW_DBINSTANCE
if [[ $IFW_DBPASSWD != "" ]] then
IFW_LOGIN=$IFW_LOGIN/$IFW_DBPASSWD
fi

sqlplus $IFW_LOGIN @create_all_ifw.sql $LOGFILE
