CREATE OR REPLACE PACKAGE tap_report
AS

-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    This PL/SQL find out the High Usage Limit for roaming user, and
--    output IMSI information which exceed the High usage Limit to a
--    data file
--    To see debug output, issue 'set serveroutput on;' before calling the report
--    procedures.
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--
-- ------------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: tap_report_pkg.sql,v $
--  $Revision: 1.5 $
--  $Author: pin09 $
--  $Date: 2006/03/09 13:49:43 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: tap_report_pkg.sql,v 1.5 2006/03/09 13:49:43 pin09 Exp $
--  $Log: tap_report_pkg.sql,v $
--  Revision 1.5  2006/03/09 13:49:43  pin09
--  MantisID: 1759
--  Committed by RBF
--  changed report dates handling and fixed details selection
--
--  Revision 1.4  2006/03/01 16:36:44  pin03
--  MantisID: 1715
--  Committed by Armin
--  Improved performance drastically by using two more temporary tables.
--
--  Revision 1.3  2006/02/28 18:50:13  pin03
--  MantisID: 1715
--  Committed by Armin
--  Using effective_t and audit tables.
--
--  Revision 1.2  2006/02/27 18:51:37  pin03
--  MantisID: none
--  Committed by Armin
--  Just archiving for backup purposes. This release is not meant to be delivered.
--
--  Revision 1.1  2005/09/30 20:42:26  pin24
--  STY: Initial release
--
-- ==============================================================================

FUNCTION get_duration
(innumber IN NUMBER
) RETURN VARCHAR2;

PROCEDURE run_report
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
,observation_date IN DATE
);

PROCEDURE run_report_today
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
);

PROCEDURE run_report_yesterday
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
);

END tap_report;
/

CREATE OR REPLACE PACKAGE BODY tap_report
AS

  -----------------------------------------------------------------------------
  -- CONSTANT
  -----------------------------------------------------------------------------
  v_delimiter             VARCHAR2(1)            := '|';
  v_headerrecordtype      CONSTANT VARCHAR2(3)   := '010';
  v_detailrecordtype      CONSTANT VARCHAR2(3)   := '020';
  v_trailerrecordtype     CONSTANT VARCHAR2(3)   := '090';
  v_profile_type          CONSTANT VARCHAR2(30)  := '/profile/acct_extrating';
  v_profile_extrat_name   CONSTANT VARCHAR2(30)  := 'HUR limit  (e.g. 10.5)';
  v_default_service_type  CONSTANT VARCHAR2(40)  := '/service/telco/gsm/telephony';
  v_profile_customer_care CONSTANT VARCHAR2(30)  := '/profile/customer_care';
  v_device_num            CONSTANT VARCHAR2(30)  := '/device/num';
  v_device_sim            CONSTANT VARCHAR2(30)  := '/device/sim';
  v_account_type          CONSTANT VARCHAR2(2)   := '10';
  v_phonetype_work        CONSTANT VARCHAR2(1)   := '2';
  v_phonetype_fax         CONSTANT VARCHAR2(1)   := '3';
  v_contact_type          CONSTANT VARCHAR2(32)  := 'Roaming Partner Address';
  v_rp_table_name         CONSTANT VARCHAR2(32)  := 'TMP_HUR_RP';
  v_tadig_table_name      CONSTANT VARCHAR2(32)  := 'TMP_HUR_TADIG';
  v_mccmnc_table_name     CONSTANT VARCHAR2(32)  := 'TMP_HUR_MCCMNC';
  i_output_buffer_size    CONSTANT INTEGER       := 500000;

  -----------------------------------------------------------------------------
  -- TYPES
  -----------------------------------------------------------------------------
  TYPE t_integer_array IS TABLE OF INTEGER;
  TYPE t_string_array  IS TABLE OF VARCHAR2(32);
  
  -----------------------------------------------------------------------------
  -- GLOBAL
  -----------------------------------------------------------------------------
  n_total_no_of_calls     NUMBER                 := 0;
  n_final_total_duration  NUMBER                 := 0;
  f_final_total_charge    FLOAT                  := 0.0;
  f_final_amount_exceeded FLOAT                  := 0.0;
  n_linecount             NUMBER                 := 0;
  v_output_header         VARCHAR2(1024)         := '';
  v_output_detail         VARCHAR2(1024)         := '';
  v_output_trailer        VARCHAR2(1024)         := '';
  b_output_header         BOOLEAN                := FALSE;
  b_output_detail         BOOLEAN                := FALSE;
  file_out                UTL_FILE.FILE_TYPE;
  
  v_error_code                 VARCHAR2(64);
    
  -----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Get the duration format from number
-- input : number of seconds
-- output: xx:xx:xx
-----------------------------------------------------------------------------
FUNCTION get_duration
(innumber IN NUMBER
) RETURN VARCHAR2
AS

  temp VARCHAR2(8);

BEGIN

  SELECT substr(ltrim(ltrim(numtodsinterval(innumber,'SECOND'),'+0'),' '),0,8) INTO temp FROM dual;

  RETURN temp;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;

-----------------------------------------------------------------------------
-- write out DETAIL of IMSI information
-----------------------------------------------------------------------------
-- Arguments:
-- v_imsi_prefix        IN mcc/mnc of roaming partner
-- highusagelimit       IN high usage limit set for roaming partner
-- dt_observation_date  IN observation date as DATE
-----------------------------------------------------------------------------
PROCEDURE detail
(v_imsi_prefix       IN VARCHAR2
,highusagelimit      IN FLOAT
,dt_observation_date IN DATE
)
AS

  v_imsi                VARCHAR2(30);
  n_numberofcalls       NUMBER;
  n_total_duration      NUMBER;
  v_total_duration      VARCHAR2(50);
  v_charging_start_date VARCHAR2(20);
  f_amount              FLOAT;
  f_amount_exceed       FLOAT;

  -- Select statement for the amount exceed usagelimit
  CURSOR cur_cust_agg IS
  SELECT imsi,
         number_of_records,
         duration,
         amount
    FROM cust_agg_roaming
   WHERE network_code = v_imsi_prefix
     AND charging_start_date = dt_observation_date
     AND (amount >= highusagelimit);
     --ORDER BY imsi DESC;

BEGIN

  n_total_no_of_calls     := 0;
  n_final_total_duration  := 0;
  f_final_total_charge    := 0.0;
  f_final_amount_exceeded := 0.0;
    
  OPEN cur_cust_agg;
  LOOP
    FETCH cur_cust_agg
     INTO v_imsi,
          n_numberofcalls,
          n_total_duration,
          f_amount;
    IF cur_cust_agg%NOTFOUND THEN
      EXIT;
    ELSE
    
      -- run once only for Header Record
      IF ( b_output_header = FALSE ) THEN
        tap_utl.put_line(file_out, v_output_header, n_linecount);
        b_output_header := TRUE;
      END IF;

      -- Output DETAILS information
      b_output_detail := TRUE;
                        
      f_amount_exceed := f_amount - highusagelimit;
      v_output_detail := v_detailrecordtype||v_delimiter||
                         v_imsi||v_delimiter||
                         n_numberofcalls||v_delimiter||
                         get_duration(n_total_duration)||v_delimiter||
                         f_amount||v_delimiter||
                         f_amount_exceed;
                           
      tap_utl.put_line(file_out, v_output_detail, n_linecount);

      -- accumulate the data for Trailer record
      n_total_no_of_calls     := n_total_no_of_calls + n_numberofcalls;
      n_final_total_duration  := n_final_total_duration + n_total_duration;
      f_final_total_charge    := f_final_total_charge + f_amount;
      f_final_amount_exceeded := f_final_amount_exceeded + f_amount_exceed;
    END IF;
  END LOOP;
  CLOSE cur_cust_agg;

EXCEPTION
  WHEN OTHERS THEN
    b_output_detail := FALSE;  
    RAISE;
END detail;

-----------------------------------------------------------------------------
-- Output Trailer information
-----------------------------------------------------------------------------
PROCEDURE trailer
AS
BEGIN

  IF ( b_output_detail = TRUE ) THEN
    v_output_trailer := v_trailerrecordtype||v_delimiter||
                        n_total_no_of_calls||v_delimiter||
                        get_duration(n_final_total_duration)||v_delimiter||
                        f_final_total_charge||v_delimiter||
                        f_final_amount_exceeded;

    tap_utl.put_line(file_out, v_output_trailer,n_linecount);
  END IF;    

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END trailer;

-----------------------------------------------------------------------------
-- Drops a table if it exists
-----------------------------------------------------------------------------
-- Arguments:
-- pv_table_name           IN name of table to be deleted
-----------------------------------------------------------------------------

PROCEDURE drop_table
( pv_table_name IN VARCHAR2
)
AS
  i_table_exists  INTEGER;
BEGIN
  v_error_code := 'Deletion of table ''' || pv_table_name || ''' failed';

  EXECUTE IMMEDIATE
  '
  select count(*) from user_tables where table_name = ''' || pv_table_name || '''
  '
  INTO i_table_exists
  ;
  IF i_table_exists > 0 THEN
     EXECUTE IMMEDIATE
     '
     drop table ' || pv_table_name 
     ;
  END IF;
END drop_table;

-----------------------------------------------------------------------------
-- Collect data for all roaming partner accounts and store them in the given
-- table
-----------------------------------------------------------------------------
-- Arguments:
-- pv_table_name           IN name of table to store collected data in
-- pv_pin_observation_date IN observation date as pin date in a string. This
--                            date is used to find historic data in the audit
--                            tables
-----------------------------------------------------------------------------

PROCEDURE collect_rp_data
( pv_rp_table_name        IN VARCHAR2
, pv_tadig_table_name     IN VARCHAR2
, pv_mccmnc_table_name    IN VARCHAR2
, pv_pin_observation_date IN VARCHAR2
)
AS
BEGIN
  -- create temporary table to be populated with additional data
  -- one row per roaming partner
  v_error_code := 'Creation of table ''' || pv_rp_table_name || ''' failed';
  EXECUTE IMMEDIATE '
  CREATE TABLE ' || pv_rp_table_name || ' (
     au_poid INTEGER
   , poid    INTEGER
   , account_no       VARCHAR(90)
   , tadig            VARCHAR(90)
   , mccmnc           VARCHAR(90)
   , company_name     VARCHAR(90)
   , high_usage_limit FLOAT
   , first_name       VARCHAR(90)
   , middle_name      VARCHAR(90)
   , last_name        VARCHAR(90)
   , tel              VARCHAR(90)
   , fax              VARCHAR(90)
   , email_address    VARCHAR(1032)
   )
  '
  ;
  
  -- Debug output
  dbms_output.put_line('Selecting roaming partner');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- Populate table with data
  -- Add au_account_t poids and corresponding account_t poids, one per roaming partner
  v_error_code := 'Population of table ''' || pv_rp_table_name || ''' failed';
  EXECUTE IMMEDIATE '
  INSERT INTO ' || pv_rp_table_name || '
  select poid_id0 as au_poid
       , au_parent_obj_id0 as poid
       , account_no
       , '''' as tadig
       , '''' as mccmnc
       , '''' as company_name
       , 0.0  as high_usage_limit
       , '''' as first_name
       , '''' as middle_name
       , '''' as last_name
       , '''' as tel
       , '''' as fax
       , '''' as email_address
  from   au_account_t a1
       , (
         -- find latest audit entry according to date
         select aua.au_parent_obj_id0 as parent_poid, max(aua.au_parent_obj_rev) as parent_rev 
         from   au_account_t aua
              , profile_t p
              , profile_customer_care_t pcc
         where  aua.au_parent_obj_id0 = p.account_obj_id0
         and    p.poid_id0 = pcc.obj_id0
         and    p.poid_type = ''' || v_profile_customer_care || '''
         and    pcc.customer_type = ' || v_account_type || '
         and    aua.effective_t <= ' || pv_pin_observation_date || '
         group by aua.au_parent_obj_id0
         ) a2
  where  a1.au_parent_obj_id0 = a2.parent_poid
  and    a1.au_parent_obj_rev = a2.parent_rev
  '
  ; 
  
  -- Debug output
  dbms_output.put_line('Selecting contact data');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- get company name; first, middle and last name; email address for roaming partner account
  -- update the temporary table with the values found for each roaming partner
  v_error_code := 'Selection of contact data failed';
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set    (company_name
        , first_name
        , middle_name
        , last_name
        , email_address
        ) = (
         select auni.company
              , auni.first_name
              , auni.middle_name
              , auni.last_name
              , auni.email_addr
         from   au_account_t aua
              , au_account_nameinfo_t auni
         where  aua.poid_id0 = auni.obj_id0
         and    auni.contact_type = ''' || v_contact_type || '''
         and    aua.poid_id0 = hur.au_poid
         )
  '
  ;
  
    -- Debug output
  dbms_output.put_line('Selecting phone number');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
-- update phone for roaming partner account
  v_error_code := 'Selection of phone failed';
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set    tel =
         (
         select auph.phone
         from   au_account_t aua
              , au_account_phones_t auph
         where  auph.obj_id0 = aua.poid_id0 
         and    auph.type = ' || v_phonetype_work || '
         and    aua.poid_id0 = hur.au_poid
         )
  '
  ;  

  -- Debug output
  dbms_output.put_line('Selecting fax number');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- update fax for roaming partner account
  v_error_code := 'Selection of fax failed';
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set    fax =
         (
         select auph.phone
         from   au_account_t aua
              , au_account_phones_t auph
         where  auph.obj_id0 = aua.poid_id0 
         and    auph.type = ' || v_phonetype_fax || '
         and    aua.poid_id0 = hur.au_poid
         )
  '
  ;  
  
  -- Debug output
  dbms_output.put_line('Selecting tadig name');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- update tadig name  for roaming partner account, 
  -- the poid returned by the most inner select statement is the account poid, not the au_account poid
  -- for performance reasons, the data is written to another temp table and then updated from this table
  v_error_code := 'Selection of tadig name failed';
  EXECUTE IMMEDIATE '
  create table ' || pv_tadig_table_name || ' as
  select s1.account_obj_id0 as poid, aud1.device_id as tadig
  from   au_device_t aud1
       , au_device_services_t auds1
       , service_t s1
       , (
         select aud.au_parent_obj_id0 as parent_poid
              , max(aud.au_parent_obj_rev) as parent_rev 
         from   au_device_t aud
              , au_device_services_t auds
              , service_t s
         where  aud.poid_id0 = auds.obj_id0
         and    aud.au_parent_obj_type = ''' || v_device_num || '''
         and    auds.service_obj_id0 = s.poid_id0
         and    s.poid_type = ''' || v_default_service_type || '''
         and    aud.created_t <= ' || pv_pin_observation_date || '
         and    s.account_obj_id0 in (select poid from ' || pv_rp_table_name || ') 
         group by aud.au_parent_obj_id0
         ) aud2
  where  aud1.au_parent_obj_id0 = aud2.parent_poid
  and    aud1.au_parent_obj_type = ''' || v_device_num || '''
  and    aud1.au_parent_obj_rev = aud2.parent_rev
  and    aud1.poid_id0 = auds1.obj_id0
  and    auds1.service_obj_id0 = s1.poid_id0
  and    s1.poid_type = ''' || v_default_service_type || '''
  and    s1.account_obj_id0 in (select poid from ' || pv_rp_table_name || ') 
  '
  ;
  v_error_code := 'Update of tadig name failed';
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set tadig =
      (
      select tadig 
      from   ' || pv_tadig_table_name || ' tadig
      where  tadig.poid = hur.poid
      )
  '
  ; 
  
  -- Debug output
  dbms_output.put_line('Selecting mcc/mnc');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- update mcc/mnc  for roaming partner account, 
  -- the poid returned by the most inner select statement is the account poid, not the au_account poid
  -- for performance reasons, the data is written to another temp table and then updated from this table
  v_error_code := 'Selection of mcc/mnc failed';
  EXECUTE IMMEDIATE '
  create table ' || pv_mccmnc_table_name || ' as
  select s1.account_obj_id0 as poid, aud1.device_id as mccmnc
  from   au_device_t aud1
       , au_device_services_t auds1
       , service_t s1
       , (
         select aud.au_parent_obj_id0 as parent_poid
              , max(aud.au_parent_obj_rev) as parent_rev 
         from   au_device_t aud
              , au_device_services_t auds
              , service_t s
         where  aud.poid_id0 = auds.obj_id0
         and    aud.au_parent_obj_type = ''' || v_device_sim || '''
         and    auds.service_obj_id0 = s.poid_id0
         and    s.poid_type = ''' || v_default_service_type || '''
         and    aud.created_t <= ' || pv_pin_observation_date || '
         and    s.account_obj_id0 in (select poid from ' || pv_rp_table_name || ') 
         group by aud.au_parent_obj_id0
         ) aud2
  where  aud1.au_parent_obj_id0 = aud2.parent_poid
  and    aud1.au_parent_obj_type = ''' || v_device_sim || '''
  and    aud1.au_parent_obj_rev = aud2.parent_rev
  and    aud1.poid_id0 = auds1.obj_id0
  and    auds1.service_obj_id0 = s1.poid_id0
  and    s1.poid_type = ''' || v_default_service_type || '''
  and    s1.account_obj_id0 in (select poid from ' || pv_rp_table_name || ') 
  '
  ; 
  v_error_code := 'Update of mcc/mnc failed';
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set mccmnc =
      (
      select mccmnc 
      from   ' || pv_mccmnc_table_name || ' mccmnc
      where  mccmnc.poid = hur.poid
      )
  '
  ; 

  -- Debug output
  dbms_output.put_line('Selecting high usage limit');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  -- get the high usage limit 
  v_error_code := 'Selection of high usage limit failed'; 
  EXECUTE IMMEDIATE '
  update ' || pv_rp_table_name || ' hur
  set    high_usage_limit =
         (
         select to_number(auaea.value)
         from   au_profile_t aup1
              , au_profile_acct_extrating_da_t auaea
              , (
                -- find latest audit profile according to date
                select aup.account_obj_id0 as account_poid, max(aup.au_parent_obj_rev) as parent_rev 
                from   au_profile_t aup
                where  aup.au_parent_obj_type = ''' || v_profile_type || '''
                and    aup.effective_t <= ' || pv_pin_observation_date || '
                and    aup.account_obj_id0 in (select poid from ' || pv_rp_table_name || ') 
                group by aup.account_obj_id0
                ) aup2
         where  aup1.account_obj_id0 = aup2.account_poid
         and    aup1.au_parent_obj_rev = aup2.parent_rev
         and    aup1.au_parent_obj_type = ''' || v_profile_type || '''
         and    aup1.poid_id0 = auaea.obj_id0
         and    auaea.name = ''' || v_profile_extrat_name || '''
         and    aup1.account_obj_id0 = hur.poid
         )
  '
  ; 
  
  commit;

  -- Debug output
  dbms_output.put_line('Done selecting');
  dbms_output.put_line(to_char(sysdate, 'MM.DD.YYYY HH24:MI:SS'));
  
  
END collect_rp_data;

-----------------------------------------------------------------------------
-- Run report. To see debug output, issue 'set serveroutput on;' before calling
-- this procedure.
-----------------------------------------------------------------------------
-- Arguments:
-- out_dir           IN name of directory object to write report file to
-- out_file          IN name of report file
-- observation_date  IN observation date for report in format YYYYMMDD
-----------------------------------------------------------------------------
PROCEDURE run_report
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
,observation_date IN DATE
)
AS
  TYPE t_string_array     IS TABLE OF VARCHAR2(90);
  TYPE t_longstring_array IS TABLE OF VARCHAR2(1023);
  TYPE t_float_array      IS TABLE OF FLOAT;
  
  v_report_generation_datetime VARCHAR2(19);
  v_observation_date           VARCHAR2(19);
  v_pin_observation_date       VARCHAR2(32);
  
  i_table_exists               INTEGER;
  
  a_rp_aupoid                  t_string_array;
  a_rp_code                    t_string_array;
  a_rp_company_name            t_string_array;
  a_rp_imsi_prefix             t_string_array;
  a_rp_high_usage_limit        t_float_array;
  a_rp_tel                     t_string_array;
  a_rp_fax                     t_string_array;
  a_rp_first_name              t_string_array;  
  a_rp_middle_name             t_string_array;  
  a_rp_last_name               t_string_array;
  a_rp_email_address           t_longstring_array; 
  
BEGIN
  v_error_code := 'Initialisation failed';

  -- Initialize some values
  -- Report Generation Date - system date
  SELECT TO_CHAR(sysdate,'YYYY MM DD HH24 MI SS') INTO v_report_generation_datetime FROM DUAL;
  -- Observation Date
  SELECT TO_CHAR(observation_date,'YYYY MM DD HH24 MI SS') INTO v_observation_date FROM dual;
  SELECT TO_CHAR(date2pin(observation_date)) INTO v_pin_observation_date FROM dual;

  -- set output buffer size
  DBMS_OUTPUT.ENABLE(i_output_buffer_size);  

  -- delete temporary tables if left over from a previous but unsucessful run
  drop_table(v_rp_table_name);
  drop_table(v_tadig_table_name);
  drop_table(v_mccmnc_table_name);

  -- collect all necessary data in a temporary table
  collect_rp_data(v_rp_table_name, v_tadig_table_name, v_mccmnc_table_name, v_pin_observation_date);

  -- finally, select the roaming partner data into collection variables
  v_error_code := 'Selection of collected data failed';  
  EXECUTE IMMEDIATE
  '
  select to_char(au_poid)
       , tadig
       , mccmnc
       , company_name
       , high_usage_limit
       , first_name
       , middle_name
       , last_name
       , tel
       , fax
       , email_address
  from ' || v_rp_table_name
  BULK COLLECT INTO a_rp_aupoid, a_rp_code, a_rp_imsi_prefix, a_rp_company_name, a_rp_high_usage_limit,  
     a_rp_first_name, a_rp_middle_name, a_rp_last_name, a_rp_tel, a_rp_fax, a_rp_email_address
  ;
  
  -- open a file and ready for output
  v_error_code := 'File open failed';  
  tap_utl.fopen(file_out, out_dir, out_file, tap_utl.append_mode);
  
  -- debug output
  DBMS_OUTPUT.PUT_LINE('Observation date: ' || observation_date || ', ' || v_pin_observation_date);
  
  -- loop over all roaming partner accounts and 
  FOR i_index IN 1..a_rp_code.COUNT LOOP
     -- debug output
     DBMS_OUTPUT.PUT_LINE('au_poid: ' || a_rp_aupoid(i_index) || ', code: ' || a_rp_code(i_index) || ', mcc/mnc: ' || a_rp_imsi_prefix(i_index) ||
        ', company name: ' || a_rp_company_name(i_index) || ', hur limit: ' || a_rp_high_usage_limit(i_index) || 
        ', first name: ' || a_rp_first_name(i_index) || ', middle name: ' || a_rp_middle_name(i_index) || ', last name: ' || a_rp_last_name(i_index) ||
        ', tel: ' || a_rp_tel(i_index) || ', fax: ' || a_rp_fax(i_index) || ', email ' || a_rp_email_address(i_index)
        );

      -- Generate HEADER information
      v_output_header := v_headerrecordtype || v_delimiter ||
                         a_rp_code(i_index) || v_delimiter ||
                         a_rp_company_name(i_index) || v_delimiter ||
                         a_rp_first_name(i_index) || ' ' || a_rp_middle_name(i_index) || ' ' || a_rp_last_name(i_index) || v_delimiter ||
                         a_rp_fax(i_index) || v_delimiter ||
                         a_rp_tel(i_index) || v_delimiter ||
                         a_rp_email_address(i_index) || v_delimiter ||
                         v_report_generation_datetime || v_delimiter ||
                         v_observation_date || v_delimiter ||
                         a_rp_high_usage_limit(i_index);

      b_output_header := FALSE;
      b_output_detail := FALSE;
        
      -- DETAILS for IMSI Information
      v_error_code := 'Creation of detail failed';
      detail(a_rp_imsi_prefix(i_index), a_rp_high_usage_limit(i_index), observation_date);
      -- END OF DETAILS

      -- TRAILER
      v_error_code := 'Creation of trailer failed';
      trailer;
      -- END OF TRAILER

  END LOOP;
  
  -- close output file
  v_error_code := 'File close failed';    
  tap_utl.fclose(file_out);
  
  -- drop temporary tables
  drop_table(v_rp_table_name);
  drop_table(v_tadig_table_name);
  drop_table(v_mccmnc_table_name);
  

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error: ' || v_error_code);
    tap_utl.exception_exit;
    RAISE;
END run_report;

-----------------------------------------------------------------------------
-- Run report for today
-----------------------------------------------------------------------------
-- Arguments:
-- out_dir     IN name of directory object to write report file to
-- out_file    IN name of report file
-----------------------------------------------------------------------------
PROCEDURE run_report_today
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
)
AS
  BEGIN
    run_report(out_dir, out_file, TRUNC(sysdate));
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END run_report_today;

-----------------------------------------------------------------------------
-- Run report for yesterday
-----------------------------------------------------------------------------
-- Arguments:
-- out_dir     IN name of directory object to write report file to
-- out_file    IN name of report file
-----------------------------------------------------------------------------
PROCEDURE run_report_yesterday
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
)
AS
  BEGIN
    run_report(out_dir, out_file, TRUNC(sysdate-1));
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END run_report_yesterday;

END tap_report;
/
