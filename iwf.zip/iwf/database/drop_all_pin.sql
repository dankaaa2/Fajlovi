-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to drop all custom tables in the Infranet scheme.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid, Portal Software
-- 
--  $RCSfile: drop_all_pin.sql,v $
--  $Revision: 1.4 $
--  $Author: pin30 $
--  $Date: 2010/02/16 12:37:53 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: drop_all_pin.sql,v 1.4 2010/02/16 12:37:53 pin30 Exp $
--  $Log: drop_all_pin.sql,v $
--  Revision 1.4  2010/02/16 12:37:53  pin30
--  Mantis ID: 2420
--  Fraud report - Partial GPRS sessions of T-Mobile CG customers in roaming should be stored in the Production database
--
--  Revision 1.3  2005/10/25 14:37:49  pin09
--  MantisID: 236
--  Committed by RBF
--  moved correlation to pin
--
--  Revision 1.2  2005/09/30 20:29:11  pin24
--  STY: aggregation table moved to pin
--
--  Revision 1.1  2005/06/24 18:05:09  pin03
--  ASc: Initial release
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

@drop_tap.sql
@drop_agg.sql
@drop_corr.sql
@drop_ggsn_fraud.sql

commit;

SPOOL OFF

exit
