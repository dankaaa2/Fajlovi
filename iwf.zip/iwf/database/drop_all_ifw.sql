-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to drop all custom tables in the Infranet scheme.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- 
-- ------------------------------------------------------------------------------
-- Responsible: Portal Software
--
-- $RCSfile: drop_all_ifw.sql,v $
-- $Revision: 1.4 $
-- $Author: pin09 $
-- $Date: 2005/10/25 14:37:48 $
--
--------------------------------------------------------------------------------
-- History:
-- $Id: drop_all_ifw.sql,v 1.4 2005/10/25 14:37:48 pin09 Exp $
-- $Log: drop_all_ifw.sql,v $
-- Revision 1.4  2005/10/25 14:37:48  pin09
-- MantisID: 236
-- Committed by RBF
-- moved correlation to pin
--
-- Revision 1.3  2005/09/30 20:29:12  pin24
-- STY: aggregation table moved to pin
--
-- Revision 1.2  2005/09/05 10:43:27  pin24
-- STY: include drop aggregation custom table sql
--
-- Revision 1.1  2005/07/26 11:07:15  pin24
-- STY: Initial release
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

-- no objects to be dropped at the moment

commit;

SPOOL OFF

exit
