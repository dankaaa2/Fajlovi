update ACCOUNT_CYCLE_FEES_T ac
set ac.CHARGED_TO_T = ac.CYCLE_FEE_END_T
where ac.CHARGED_TO_T != ac.CYCLE_FEE_END_T;

UPDATE au_account_cycle_fees_t ac
SET ac.charged_to_t = ac.cycle_fee_end_t
WHERE ac.charged_to_t != ac.cycle_fee_end_t
AND ac.obj_id0 IN 
        (SELECT poid_id0
         FROM au_account_t a
         WHERE (au_parent_obj_id0, au_parent_obj_rev) IN 
                      (SELECT au_parent_obj_id0, MAX (au_parent_obj_rev)
                       FROM au_account_t a
                       GROUP BY au_parent_obj_id0));

COMMIT;
