update rate_t
set type=740
where poid_id0 in 
(select rate_t.poid_id0 
from product_t,rate_plan_t,rate_t,rate_bal_impacts_t
where product_t.poid_id0=rate_plan_t.product_obj_id0
and rate_plan_t.poid_id0=rate_t.rate_plan_obj_id0
and rate_t.poid_id0=rate_bal_impacts_t.obj_id0
and element_id like '222%');

update au_rate_t
set type=740
where au_parent_obj_id0 in 
(select rate_t.poid_id0 
from product_t,rate_plan_t,rate_t,rate_bal_impacts_t
where product_t.poid_id0=rate_plan_t.product_obj_id0
and rate_plan_t.poid_id0=rate_t.rate_plan_obj_id0
and rate_t.poid_id0=rate_bal_impacts_t.obj_id0
and element_id like '222%');

commit;

