--Kreirati backup tabele
create table profile_custom_info_t_BACKUP
as 
select * from profile_custom_info_t;

create table au_pro_cust_info_t_BACKUP
as 
select * from au_profile_custom_info_t;

create table account_t_BACKUP
as
select * from account_t;

create table au_account_t_BACKUP
as
select * from au_account_t;



--Za koliko accounta treba ispraviti PIB u profile_custom_info_t tabeli:
select count(*) from profile_custom_info_t where
profile_custom_info_t.obj_id0 in (select poid_id0 from profile_t where poid_type='/profile/custom_info'
and account_obj_id0 in (select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and profile_t.account_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and not exists
(select 1 from account_t where poid_id0 = profile_t.account_obj_id0 and account_no in
('Z0043140','Z0052198','Z0055548','Z0055549','Z0055550','Z0046883','Z0071878','Z0047857','Z0059172',
'Z0047049','Z0043085','Z0062593','Z0058238','Z0049719','Z0071344','Z0058816','Z0058817','Z0055747',
'Z0049040','Z0055605','Z0055305','Z0059313','Z0051925','Z0049056','Z0049057','Z0049058'))) and inv_type = 'C'
and PIB is not null  ;
--R: 74

--Update profile_custom_info_t
update profile_custom_info_t  set
PIB = NULL  where
profile_custom_info_t.obj_id0 in (select poid_id0 from profile_t where poid_type='/profile/custom_info'
and account_obj_id0 in (select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and profile_t.account_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and not exists
(select 1 from account_t where poid_id0 = profile_t.account_obj_id0 and account_no in
('Z0043140','Z0052198','Z0055548','Z0055549','Z0055550','Z0046883','Z0071878','Z0047857','Z0059172',
'Z0047049','Z0043085','Z0062593','Z0058238','Z0049719','Z0071344','Z0058816','Z0058817','Z0055747',
'Z0049040','Z0055605','Z0055305','Z0059313','Z0051925','Z0049056','Z0049057','Z0049058'))) and inv_type = 'C'
and PIB is not null ;
--R: 74

--Za koliko accounta treba ispraviti PIB u au_profile_custom_info_t tabeli:
select count(*) from au_profile_custom_info_t where obj_id0 in
(select poid_id0 from au_profile_t where poid_type = '/au_profile/custom_info' and 
account_obj_id0 in (select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and  not exists
(select 1 from account_t where poid_id0 =account_obj_id0 and account_no in
('Z0043140','Z0052198','Z0055548','Z0055549','Z0055550','Z0046883','Z0071878','Z0047857','Z0059172',
'Z0047049','Z0043085','Z0062593','Z0058238','Z0049719','Z0071344','Z0058816','Z0058817','Z0055747',
'Z0049040','Z0055605','Z0055305','Z0059313','Z0051925','Z0049056','Z0049057','Z0049058')) and account_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T)) and inv_type = 'C'
and PIB is not null  ;
--R: 74

--Update za  au_profile_custom_info_t 
update au_profile_custom_info_t set
PIB = NULL where obj_id0 in
(select poid_id0 from au_profile_t where poid_type = '/au_profile/custom_info' and 
account_obj_id0 in (select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and  not exists
(select 1 from account_t where poid_id0 =account_obj_id0 and account_no in
('Z0043140','Z0052198','Z0055548','Z0055549','Z0055550','Z0046883','Z0071878','Z0047857','Z0059172',
'Z0047049','Z0043085','Z0062593','Z0058238','Z0049719','Z0071344','Z0058816','Z0058817','Z0055747',
'Z0049040','Z0055605','Z0055305','Z0059313','Z0051925','Z0049056','Z0049057','Z0049058')) and account_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T)) and inv_type = 'C'
and PIB is not null  ;
--R: 74

--Za koliko accounta treba da se updatuje vat_registration polje:
select count(*) from account_t where 
vat_cert is not null  and account_t.poid_id0 in 
(select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and account_t.poid_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and account_t.poid_id0 in
(select account_obj_id0 from profile_t where poid_type='/profile/custom_info' and poid_id0 in 
(select obj_id0 from profile_custom_info_t where inv_type = 'C')) 
and account_no !='Z0046883'
and account_no !='Z0071878'
and account_no !='Z0047857'
and account_no !='Z0059172'
and account_no !='Z0047049'
and account_no !='Z0043085'
and account_no !='Z0049719'
and account_no !='Z0071344'
and account_no !='Z0058816'
and account_no !='Z0058817'
and account_no !='Z0055747'
and account_no !='Z0049040'
and account_no !='Z0055605'
and account_no !='Z0055305'
and account_no !='Z0059313'
and account_no !='Z0051925';
--R: 53

--Update za vat_cert polje u account_t
update account_t set
vat_cert = NULL  where account_t.poid_id0 in 
(select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and account_t.poid_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and account_t.poid_id0 in
(select account_obj_id0 from profile_t where poid_id0 in 
(select obj_id0 from profile_custom_info_t where inv_type = 'C'))
and vat_cert is not null 
and account_no !='Z0046883'
and account_no !='Z0071878'
and account_no !='Z0047857'
and account_no !='Z0059172'
and account_no !='Z0047049'
and account_no !='Z0043085'
and account_no !='Z0049719'
and account_no !='Z0071344'
and account_no !='Z0058816'
and account_no !='Z0058817'
and account_no !='Z0055747'
and account_no !='Z0049040'
and account_no !='Z0055605'
and account_no !='Z0055305'
and account_no !='Z0059313'
and account_no !='Z0051925' ;
--R:53

--Koliko rekorda treba updatovati u au_account_t tabeli:
select count(*) from au_account_t where 
vat_cert is not null  and au_account_t.au_parent_obj_id0 in 
(select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and au_account_t.au_parent_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and au_account_t.au_parent_obj_id0  in
(select account_obj_id0 from profile_t where poid_type='/profile/custom_info' and poid_id0 in 
(select obj_id0 from profile_custom_info_t where inv_type = 'C')) and au_account_t.au_parent_obj_id0 in
(select poid_id0 from account_t where 
 account_no !='Z0046883'
and account_no !='Z0071878'
and account_no !='Z0047857'
and account_no !='Z0059172'
and account_no !='Z0047049'
and account_no !='Z0043085'
and account_no !='Z0049719'
and account_no !='Z0071344'
and account_no !='Z0058816'
and account_no !='Z0058817'
and account_no !='Z0055747'
and account_no !='Z0049040'
and account_no !='Z0055605'
and account_no !='Z0055305'
and account_no !='Z0059313'
and account_no !='Z0051925') ;
--R: 53

--update au_account_t tabele i vat_registration polja:
update au_account_t set 
vat_cert = null where  au_account_t.au_parent_obj_id0 in 
(select account_obj_id0 from billinfo_t where bill_info_id = 'Bill Unit(1)' and 
ar_billinfo_obj_id0=poid_id0 and billing_status in (0,4)) and au_account_t.au_parent_obj_id0 in
(select GROUP_BILLING_MEMBERS_T.OBJECT_ID0 from GROUP_BILLING_MEMBERS_T) and au_account_t.au_parent_obj_id0  in
(select account_obj_id0 from profile_t where poid_type='/profile/custom_info' and poid_id0 in 
(select obj_id0 from profile_custom_info_t where inv_type = 'C'))
and vat_cert is not null and au_account_t.au_parent_obj_id0 in
(select poid_id0 from account_t where 
 account_no !='Z0046883'
and account_no !='Z0071878'
and account_no !='Z0047857'
and account_no !='Z0059172'
and account_no !='Z0047049'
and account_no !='Z0043085'
and account_no !='Z0049719'
and account_no !='Z0071344'
and account_no !='Z0058816'
and account_no !='Z0058817'
and account_no !='Z0055747'
and account_no !='Z0049040'
and account_no !='Z0055605'
and account_no !='Z0055305'
and account_no !='Z0059313'
and account_no !='Z0051925') ;
--R:53

commit;
