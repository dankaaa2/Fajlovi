-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to grant to access for db schema
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- 
-- ------------------------------------------------------------------------------
-- Responsible: Portal Software
--
-- $RCSfile: grant_all_ifw.sql,v $
-- $Revision: 1.1 $
-- $Author: pin24 $
-- $Date: 2005/09/05 10:39:19 $
--
-- ------------------------------------------------------------------------------
-- History:
-- $Id: grant_all_ifw.sql,v 1.1 2005/09/05 10:39:19 pin24 Exp $
-- $Log: grant_all_ifw.sql,v $
-- Revision 1.1  2005/09/05 10:39:19  pin24
-- STY: initial release
--
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

@grant.exp.sql

commit;

SPOOL OFF

exit
