-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the storage tables for Correlation
--
--  Open Points:
--    none
--
--  Review Status:
-- -  review
--
--  -----------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: create_corr.sql,v $
--  $Revision: 1.3 $
-- -$Author: pin26 $
--  $Date: 2008/08/06 11:51:40 $
--
--  -----------------------------------------------------------------------------
--  History:
--  $Id: create_corr.sql,v 1.3 2008/08/06 11:51:40 pin26 Exp $
--  $Log: create_corr.sql,v $
--  Revision 1.3  2008/08/06 11:51:40  pin26
--  MantisID: 2343
--  Committed by RBF
--  added Starhome table
--
--  Revision 1.2  2005/11/28 19:03:40  pin09
--  MantisID: 1021
--  Committed by RBF
--  extended correlation tables
--
--  Revision 1.1  2005/07/26 11:06:18  pin24
--  STY: Initial release
--
-- ==============================================================================


@drop_corr.sql

PROMPT ==========================================================================
PROMPT Creating Correlation tables
PROMPT ==========================================================================

-- ==============================================================================
-- CUST_CORR_CAMEL
-- ==============================================================================

CREATE TABLE CUST_CORR_CAMEL
(
  CALL_REF                  VARCHAR2(10),
  PROCESSING_TIME           DATE,
  CHARGING_START_TIMESTAMP  DATE,
  B_NUMBER                  VARCHAR2(40),
  B_NPI                     VARCHAR2(2),
  B_TON                     VARCHAR2(2)
);

COMMENT ON TABLE CUST_CORR_CAMEL                           IS 'Camel Correlation Information';
COMMENT ON COLUMN CUST_CORR_CAMEL.CALL_REF                 IS 'Chain Reference';
COMMENT ON COLUMN CUST_CORR_CAMEL.PROCESSING_TIME          IS 'System time when CDR is being processing';
COMMENT ON COLUMN CUST_CORR_CAMEL.CHARGING_START_TIMESTAMP IS 'Charging start time stamp';
COMMENT ON COLUMN CUST_CORR_CAMEL.B_NUMBER                 IS 'B Number';
COMMENT ON COLUMN CUST_CORR_CAMEL.B_NPI                    IS 'B Number numbering plan';
COMMENT ON COLUMN CUST_CORR_CAMEL.B_TON                    IS 'B Number type of number';

-- ==============================================================================
-- CUST_CORR_USSD
-- ==============================================================================

CREATE TABLE CUST_CORR_USSD
(
  CALL_REF                  VARCHAR2(10),
  PROCESSING_TIME           DATE,
  CHARGING_START_TIMESTAMP  DATE,
  DURATION                  NUMBER,
  PORT_NUMBER               VARCHAR2(15),
  TRUNK_OUTPUT              VARCHAR2(7)
);

COMMENT ON TABLE CUST_CORR_USSD                            IS 'USSD Correlation Information';
COMMENT ON COLUMN CUST_CORR_USSD.CALL_REF                  IS 'Chain Reference';
COMMENT ON COLUMN CUST_CORR_USSD.PROCESSING_TIME           IS 'System time when CDR is being processing';
COMMENT ON COLUMN CUST_CORR_USSD.CHARGING_START_TIMESTAMP  IS 'Charging start time stamp';
COMMENT ON COLUMN CUST_CORR_USSD.DURATION                  IS 'Call Duration';
COMMENT ON COLUMN CUST_CORR_USSD.PORT_NUMBER               IS 'IMSI';
COMMENT ON COLUMN CUST_CORR_USSD.TRUNK_OUTPUT              IS 'Outgoing route';

-- ==============================================================================
-- CUST_CORR_STARHOME
-- ==============================================================================

CREATE TABLE CUST_CORR_STARHOME
(
  CALL_REF                  VARCHAR2(10),
  PROCESSING_TIME           DATE,
  CHARGING_START_TIMESTAMP  DATE,
  B_NUMBER                  VARCHAR2(40),
  B_NPI                     VARCHAR2(2),
  B_TON                     VARCHAR2(2)
);

COMMENT ON TABLE CUST_CORR_STARHOME                           IS 'Starhome Correlation Information';
COMMENT ON COLUMN CUST_CORR_STARHOME.CALL_REF                 IS 'Chain Reference';
COMMENT ON COLUMN CUST_CORR_STARHOME.PROCESSING_TIME          IS 'System time when CDR is being processing';
COMMENT ON COLUMN CUST_CORR_STARHOME.CHARGING_START_TIMESTAMP IS 'Charging start time stamp';
COMMENT ON COLUMN CUST_CORR_STARHOME.B_NUMBER                 IS 'B Number';
COMMENT ON COLUMN CUST_CORR_STARHOME.B_NPI                    IS 'B Number numbering plan';
COMMENT ON COLUMN CUST_CORR_STARHOME.B_TON                    IS 'B Number type of number';

