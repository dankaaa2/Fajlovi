#!/bin/sh
## =============================================================================
##
##          Copyright (c) 1998 - 2002 Portal Software (Hamburg) GmbH.
##                            All rights reserved.
##               This material is the confidential property of
##       Portal Software (Hamburg) GmbH or its subsidiaries or licensors
##    and may be used, reproduced, stored or transmitted only in accordance
##            with a valid Portal license or sublicense agreement.
##
## -----------------------------------------------------------------------------
## Module Description:
##    Shell script to create all custom tables in Infranet db scheme
##
## -----------------------------------------------------------------------------
## Responsible: Armin Schmid, Portal Software
##
## $RCSfile: create_all_pin.sh,v $
## $Revision: 1.1 $
## $Author: pin03 $
## $Date: 2005/06/24 18:05:09 $
## -----------------------------------------------------------------------------
## $Id: create_all_pin.sh,v 1.1 2005/06/24 18:05:09 pin03 Exp $
## $Log: create_all_pin.sh,v $
## Revision 1.1  2005/06/24 18:05:09  pin03
## ASc: Initial release
##
## =============================================================================

## -----------------------------------------------------------------------------
## Usage: create_all_pin.sh [instance] [user] [password]
##        will try to find the db instance, db user and db password in the
##        arguments instance, user and password. 
##        If they are not found there, the environment variables 
##        PIN_DBINSTANCE, PIN_DBUSER and PIN_DBPASSWD are looked up.
##        If they are not found there, they are prompted for interactively.
## -----------------------------------------------------------------------------

LOGFILE=create_all_pin.log

# Get DB instance, user and password from arguments, if they were not specified
# assume they are already in the environment variables.
if [ "$1" != "" ]; then
   PIN_DBINSTANCE=$1
fi
if [ "$2" != "" ]; then
   PIN_DBUSER=$2
fi
if [ "$3" != "" ]; then
   PIN_DBPASSWD=$3
fi

# If instance and user were not given as argument or variable,
# read them interactively. Password will be read interactively later on
# by sqlplus WITHOUT echo on stdout
if [ "$PIN_DBINSTANCE" = "" ]; then
   echo "Please enter the instance name of the Infranet database \c"
   read PIN_DBINSTANCE
fi
if [ "$PIN_DBUSER" = "" ]; then
   echo "Please enter the database user name for that instance \c"
   read PIN_DBUSER
fi

# Create login string
PIN_LOGIN=$PIN_DBUSER@$PIN_DBINSTANCE
if [ "$PIN_DBPASSWD" != "" ]; then
PIN_LOGIN=$PIN_LOGIN/$PIN_DBPASSWD
fi

sqlplus $PIN_LOGIN @create_all_pin.sql $LOGFILE
