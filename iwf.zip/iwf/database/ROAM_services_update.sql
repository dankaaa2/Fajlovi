create table service_t_BCK
as 
select * from service_t;

create table au_service_t_BCK
as 
select * from au_service_t;


update service_t 
set effective_t = 
	(select s.effective_t 
	 from service_t s 
	 where s.account_obj_id0 = service_t.account_obj_id0  
	 and poid_type = '/service/telco/roam/gsm/telephony')  
where poid_type like '/service/roam/%'
and effective_t = 1149112800;

update service_t 
set created_t = 
	(select s.created_t 
	 from service_t s 
	 where s.account_obj_id0 = service_t.account_obj_id0  
	 and poid_type = '/service/telco/roam/gsm/telephony')  
where poid_type like '/service/roam/%'
and created_t = 1149112800;

	
update au_service_t 
set effective_t = 
	(select min (aus.effective_t) 
	 from au_service_t aus 
	 where aus.account_obj_id0 = au_service_t.account_obj_id0  
	 and poid_type = '/au_service/telco/roam/gsm/telephony')  
where poid_type like '/au_service/roam/%'
and effective_t = 1149112800;
	
	
update au_service_t 
set created_t = 
	(select min (aus.created_t) 
	 from au_service_t aus 
	 where aus.account_obj_id0 = au_service_t.account_obj_id0  
	 and poid_type = '/au_service/telco/roam/gsm/telephony')  
where poid_type like '/au_service/roam/%'
and created_t = 1149112800;


update account_products_t
set PURCHASE_START_T = (select a.PURCHASE_START_T
	 from account_products_t a 
	 where a.obj_id0 = account_products_t.obj_id0  
	 and service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;

update account_products_t
set USAGE_START_T = (select a.USAGE_START_T
	 from account_products_t a 
	 where a.obj_id0 = account_products_t.obj_id0  
	 and service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;

update account_products_t
set CREATED_T  = (select a.CREATED_T
	 from account_products_t a 
	 where a.obj_id0 = account_products_t.obj_id0  
	 and service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;



-- au_account_products_t
update au_account_products_t
set PURCHASE_START_T = (select min(au.PURCHASE_START_T)
	 from au_account_products_t au 
	 where service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;

update au_account_products_t
set USAGE_START_T = (select min(au.USAGE_START_T)
	 from au_account_products_t au 
	 where service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;

update au_account_products_t
set CREATED_T = (select min(au.CREATED_T)
	 from au_account_products_t au 
	 where service_obj_type = '/service/telco/roam/gsm/telephony'
	 and descr ='ROAM')  
where service_obj_type like '/service/roam/%'
and created_t = 1149112800;

commit;