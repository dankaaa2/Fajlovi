CREATE OR REPLACE PACKAGE tap_utl
AS

-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    Utilities package
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--
-- ------------------------------------------------------------------------------
--  Responsible: Robert Frydrych, Portal Software
--
--  $RCSfile: tap_utl_pkg.sql,v $
--  $Revision: 1.1 $
--  $Author: pin09 $
--  $Date: 2005/09/05 16:20:53 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: tap_utl_pkg.sql,v 1.1 2005/09/05 16:20:53 pin09 Exp $
--  $Log: tap_utl_pkg.sql,v $
--  Revision 1.1  2005/09/05 16:20:53  pin09
--  RBF: Initial release
--
-- ==============================================================================

PROCEDURE fopen
(file_handler IN OUT UTL_FILE.FILE_TYPE
,file_path IN VARCHAR2
,file_name IN VARCHAR2
,open_mode IN VARCHAR2
);

PROCEDURE fclose
(file_handler IN OUT UTL_FILE.FILE_TYPE
,flush IN BOOLEAN DEFAULT TRUE
);

PROCEDURE put_line
(file_handler IN UTL_FILE.FILE_TYPE
,line IN VARCHAR2
,line# IN OUT NUMBER
,line_size IN NUMBER DEFAULT 0
,indent IN VARCHAR2 DEFAULT NULL
);

PROCEDURE check_field
(input IN VARCHAR2
,output OUT VARCHAR2
,max_size IN NUMBER
,pad IN BOOLEAN DEFAULT TRUE
,def_pad IN VARCHAR2 DEFAULT ' '
,def_val IN VARCHAR2 DEFAULT ' '
);

PROCEDURE check_field
(input IN NUMBER
,output OUT VARCHAR2
,frmt IN VARCHAR2
,scale IN NUMBER DEFAULT 5
);

PROCEDURE check_field
(input IN DATE
,output OUT VARCHAR2
,frmt IN VARCHAR2
,def_val IN VARCHAR2 DEFAULT NULL
);

PROCEDURE exception_exit
(close_files IN BOOLEAN DEFAULT TRUE
);

--------------
-- constants
--------------
 --append mode
 append_mode               CONSTANT CHAR(1) := 'a';
 --write mode
 write_mode                CONSTANT CHAR(1) := 'w';


---------------
-- exceptions
---------------
 file_invalid_path               EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_invalid_path, -20010);

 file_invalid_open_mode          EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_invalid_open_mode, -20011);

 file_invalid_open_operation     EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_invalid_open_operation, -20012);

 file_open_undef                 EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_open_undef, -20019);

 file_invalid_filehandle         EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_invalid_filehandle, -20020);

 file_invalid_write_operation    EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_invalid_write_operation, -20021);

 file_write_error                EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_write_error, -20022);

 file_wirte_undef                EXCEPTION;
 PRAGMA EXCEPTION_INIT(file_wirte_undef, -20029);

END tap_utl;
/

CREATE OR REPLACE PACKAGE BODY tap_utl
AS

PROCEDURE fopen
(file_handler IN OUT UTL_FILE.FILE_TYPE
,file_path IN VARCHAR2
,file_name IN VARCHAR2
,open_mode IN VARCHAR2
)
AS
--variables
-- open_mode CONSTANT VARCHAR2(1) := 'a';

BEGIN

  BEGIN
    file_handler := UTL_FILE.FOPEN(file_path,file_name,open_mode);
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN
      RAISE file_invalid_path;
    WHEN UTL_FILE.INVALID_MODE THEN
      RAISE file_invalid_open_mode;
    WHEN UTL_FILE.INVALID_OPERATION THEN
      RAISE file_invalid_open_operation;
    WHEN OTHERS THEN
      RAISE file_open_undef;
  END;

EXCEPTION
  WHEN file_invalid_path THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'file location ('||file_path||') or name ('||file_name||') was invalid');
  WHEN file_invalid_open_mode THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'the open_mode string ('||open_mode||') was invalid');
  WHEN file_invalid_open_operation THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'file ('||file_name||') at location ('||file_path||') could not be opened as requested');
  WHEN file_open_undef THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'undefined error when opening file ('||file_name||') - '||SQLERRM);
  WHEN OTHERS THEN
    RAISE;
END fopen;

PROCEDURE fclose
(file_handler IN OUT UTL_FILE.FILE_TYPE
,flush IN BOOLEAN DEFAULT TRUE
)
AS
--variables

BEGIN

  IF flush THEN
    BEGIN
      UTL_FILE.FFLUSH(file_handler);
    EXCEPTION
      WHEN UTL_FILE.INVALID_FILEHANDLE THEN
        RAISE file_invalid_filehandle;
      WHEN UTL_FILE.INVALID_OPERATION THEN
        RAISE file_invalid_write_operation;
      WHEN UTL_FILE.WRITE_ERROR THEN
        RAISE file_write_error;
      WHEN OTHERS THEN
        RAISE file_wirte_undef;
    END;
  END IF;

  BEGIN
    UTL_FILE.FCLOSE(file_handler);
  EXCEPTION
    WHEN UTL_FILE.INVALID_FILEHANDLE THEN
      RAISE file_invalid_filehandle;
    WHEN UTL_FILE.WRITE_ERROR THEN
      RAISE file_write_error;
    WHEN OTHERS THEN
      RAISE file_wirte_undef;
  END;

EXCEPTION
  WHEN file_invalid_filehandle THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'not a valid file handle');
  WHEN file_invalid_write_operation THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'file is not open for writing/appending');
  WHEN file_write_error THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'OS error occured during write operation');
  WHEN file_wirte_undef THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'undefined error when writing file - '||SQLERRM);
  WHEN OTHERS THEN
    RAISE;
END fclose;

PROCEDURE put_line
(file_handler IN UTL_FILE.FILE_TYPE
,line IN VARCHAR2
,line# IN OUT NUMBER
,line_size IN NUMBER DEFAULT 0
,indent IN VARCHAR2 DEFAULT NULL
)
AS
--variables
 def_value CONSTANT VARCHAR2(256) := ' ';

BEGIN

  IF line_size = 0 THEN
    BEGIN
      UTL_FILE.PUT_LINE(file_handler,indent||line);
    EXCEPTION
      WHEN UTL_FILE.INVALID_FILEHANDLE THEN
        RAISE file_invalid_filehandle;
      WHEN UTL_FILE.INVALID_OPERATION THEN
        RAISE file_invalid_write_operation;
      WHEN UTL_FILE.WRITE_ERROR THEN
        RAISE file_write_error;
      WHEN OTHERS THEN
        RAISE file_wirte_undef;
    END;
  ELSE
    BEGIN
      UTL_FILE.PUT_LINE(file_handler,RPAD(NVL(indent||line,def_value),line_size));
    EXCEPTION
      WHEN UTL_FILE.INVALID_FILEHANDLE THEN
        RAISE file_invalid_filehandle;
      WHEN UTL_FILE.INVALID_OPERATION THEN
        RAISE file_invalid_write_operation;
      WHEN UTL_FILE.WRITE_ERROR THEN
        RAISE file_write_error;
      WHEN OTHERS THEN
        RAISE file_wirte_undef;
    END;
  END IF;
  line# := line# + 1;

EXCEPTION
  WHEN file_invalid_filehandle THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'not a valid file handle');
  WHEN file_invalid_write_operation THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'file is not open for writing/appending');
  WHEN file_write_error THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'OS error occured during write operation');
  WHEN file_wirte_undef THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'undefined error when writing file - '||SQLERRM);
  WHEN OTHERS THEN
    RAISE;
END put_line;

PROCEDURE check_field
(input IN VARCHAR2
,output OUT VARCHAR2
,max_size IN NUMBER
,pad IN BOOLEAN DEFAULT TRUE
,def_pad IN VARCHAR2 DEFAULT ' '
,def_val IN VARCHAR2 DEFAULT ' '
)
AS
--variables

BEGIN

  IF LENGTH(input) >= max_size THEN
    output := SUBSTR(input,1,max_size);
  ELSE
    output := NVL(input,def_val);
    IF pad THEN
      output := RPAD(output,max_size,def_pad);
    ELSE
      output := LPAD(output,max_size,def_pad);
    END IF;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END check_field;

PROCEDURE check_field
(input IN NUMBER
,output OUT VARCHAR2
,frmt IN VARCHAR2
,scale IN NUMBER DEFAULT 5
)
AS
--variables

BEGIN

  output := TO_CHAR(ROUND(NVL(input,0),scale),frmt);

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END check_field;

PROCEDURE check_field
(input IN DATE
,output OUT VARCHAR2
,frmt IN VARCHAR2
,def_val IN VARCHAR2 DEFAULT NULL
)
AS
--variables

BEGIN

  output := TO_CHAR(input,frmt);

  IF def_val IS NOT NULL THEN
    output := NVL(output,def_val);
  ELSE
    output := NVL(output,RPAD(' ',LENGTH(frmt)));
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END check_field;

PROCEDURE exception_exit
(close_files IN BOOLEAN DEFAULT TRUE
)
AS
--variables

BEGIN

  ROLLBACK;

  IF close_files THEN
    BEGIN
      UTL_FILE.FCLOSE_ALL;
    EXCEPTION
      WHEN UTL_FILE.WRITE_ERROR THEN
        RAISE file_write_error;
      WHEN OTHERS THEN
        RAISE file_wirte_undef;
    END;
  END IF;

EXCEPTION
  WHEN file_write_error THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'OS error occured during write operation in emergency exit');
  WHEN file_wirte_undef THEN
    RAISE_APPLICATION_ERROR(SQLCODE,'undefined error when writing file in emergency exit - '||SQLERRM);
  WHEN OTHERS THEN
    RAISE;
END exception_exit;

END tap_utl;
/

