-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--   SQL statement file to drop the stroage table for Correlation
--
--  Open Points:
--    none
--
--  Review Status:
-- -  review
--
--  -----------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: drop_corr.sql,v $
--  $Revision: 1.2 $
-- -$Author: pin26 $
--  $Date: 2008/08/06 11:51:41 $
--
--  -----------------------------------------------------------------------------
--  History:
--  $Id: drop_corr.sql,v 1.2 2008/08/06 11:51:41 pin26 Exp $
--  $Log: drop_corr.sql,v $
--  Revision 1.2  2008/08/06 11:51:41  pin26
--  MantisID: 2343
--  Committed by RBF
--  added Starhome table
--
--  Revision 1.1  2005/07/26 11:08:04  pin24
--  STY: Initial release
--
-- ==============================================================================


PROMPT ==========================================================================
PROMPT Dropping correlation tables
PROMPT Error messages complaining about missing tables or views can be ignored
PROMPT ==========================================================================

WHENEVER SQLERROR CONTINUE

DROP TABLE CUST_CORR_CAMEL;
DROP TABLE CUST_CORR_USSD;
DROP TABLE CUST_CORR_STARHOME;

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
