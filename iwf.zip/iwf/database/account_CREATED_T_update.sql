create table account_t_2 as
select * from account_t;

create table au_account_t_BACKUP as
select * from au_account_t;


--UPDATE ACCOUNT_T -- koristeci service_t
update account_t set created_t = (select service_t.created_t from 
service_t where service_t.account_obj_id0 = account_t.poid_id0 and poid_type = '/service/telco/gsm/telephony') ,
mod_t = (select service_t.created_t from 
service_t where service_t.account_obj_id0 = account_t.poid_id0 and poid_type = '/service/telco/gsm/telephony')   
where account_t.poid_id0 in (select subs_poid_id0 from subscriber_details,subscriber_mapping,account_t 
where subscriber_details.subscriber_id = subscriber_mapping.subscriber_id and 
subs_poid_id0=account_t.poid_id0 and subs_disconnect_date is null and 
pin2date(created_t)!=subs_connect_date) and account_t.status <> 10103;

update au_account_t set created_t = 
(select service_t.created_t from 
service_t,account_t where service_t.account_obj_id0 = account_t.poid_id0 and 
service_t.poid_type = '/service/telco/gsm/telephony' 
and account_t.account_no = au_account_t.account_no),
mod_t = (select service_t.created_t from 
service_t,account_t where service_t.account_obj_id0 = account_t.poid_id0 and 
service_t.poid_type = '/service/telco/gsm/telephony' 
and account_t.account_no = au_account_t.account_no)
where au_account_t.account_no in (select subs_acc_no from subscriber_details,subscriber_mapping,account_t_2
where subscriber_details.subscriber_id = subscriber_mapping.subscriber_id and 
subs_poid_id0=account_t_2.poid_id0 and subs_disconnect_date is  null and 
pin2date(created_t)!=subs_connect_date and account_t_2.status <> 10103);

commit;
