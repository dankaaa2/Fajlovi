update AU_PROFILE_ACCT_EXTRATING_DA_T 
set valid_from = 946681200 
where valid_from is null;

update AU_PROFILE_ACCT_EXTRATING_DA_T
set valid_to = 0 
where valid_to is null;

update PROFILE_ACCT_EXTRATING_DATA_T
set valid_from = 946681200 
where valid_from is null;

update PROFILE_ACCT_EXTRATING_DATA_T
set valid_to = 0 
where valid_to is null;

commit;
