-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the storage tables for roaming aggregation
--
--  Open Points:
--    none
--
--  Review Status:
-- -  review
--
--  -----------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: create_agg.sql,v $
--  $Revision: 1.2 $
--  $Author: pin24 $
--  $Date: 2005/09/28 14:41:19 $
--
-- ------------------------------------------------------------------------------
--  History:
--  $Id: create_agg.sql,v 1.2 2005/09/28 14:41:19 pin24 Exp $
--  $Log: create_agg.sql,v $
--  Revision 1.2  2005/09/28 14:41:19  pin24
--  STY: adjustment
--
--  Revision 1.1  2005/09/05 10:40:18  pin24
--  STY: initial release
--
-- ==============================================================================

@drop_agg.sql

PROMPT ==========================================================================
PROMPT Creating Aggregation Table for Roaming
PROMPT ==========================================================================

-- ==============================================================================
-- CUST_AGG_ROAMING
-- ==============================================================================
CREATE TABLE CUST_AGG_ROAMING
(
  IMSI                 VARCHAR2(15),
  NETWORK_CODE         VARCHAR2(5),
  CHARGING_START_DATE  DATE,
  DURATION             NUMBER,
  NUMBER_OF_RECORDS    NUMBER,
  AMOUNT               NUMBER
);

COMMENT ON COLUMN CUST_AGG_ROAMING.IMSI IS 'IMSI number';
COMMENT ON COLUMN CUST_AGG_ROAMING.NETWORK_CODE IS '5 Digit network code';
COMMENT ON COLUMN CUST_AGG_ROAMING.CHARGING_START_DATE IS 'Call charging start date';
COMMENT ON COLUMN CUST_AGG_ROAMING.DURATION IS 'Total Duration for an IMSI';
COMMENT ON COLUMN CUST_AGG_ROAMING.NUMBER_OF_RECORDS IS 'Total number of calls for an IMSI';
COMMENT ON COLUMN CUST_AGG_ROAMING.AMOUNT IS 'Total Retail Charged amount for an IMSI';

