update config_glid_t
set descr='Pozivi u Monet mreži'
where rec_id=1000005;

update config_glid_t
set descr='Pozivi prema drugim mrežama u CG'
where rec_id=1000007;

update config_glid_t
set descr='Pozivi prema mrežama u Srbiji'
where rec_id=1000008;

update config_glid_t
set descr='Međunarodni pozivi'
where rec_id=1000009;

update config_glid_t
set descr='Međunarodni data pozivi'
where rec_id=1000010;

update config_glid_t
set descr='UCSSW - Promjena vlasništva'
where rec_id=1000013;

update config_glid_t
set descr='FALM - Pozivi u Monet mreži - LIBERO'
where rec_id=1000045;

update config_glid_t
set descr='FALP - Pozivi prema drugim mrežama u CG - LIBERO'
where rec_id=1000046;

update config_glid_t
set descr='KOR - Korekcija računa'
where rec_id=1000064;

update config_glid_t
set descr='KOR1 - Korekcija računa'
where rec_id=1000065;

update config_glid_t
set descr='KOR2 - Korekcija računa'
where rec_id=1000066;

update config_glid_t
set descr='KORNG - Novogodišnji popust'
where rec_id=1000078;

update config_glid_t
set descr='sponsor - Potrošnja korisnika pod limitom'
where rec_id=1099999;
