update item_t 
set name ='Korekcija računa ' || substr(name,18) 
where name like  '%Korekcija ra%';

update item_t 
set name = 'Međunarodni data pozivi ' || substr(name,25) 
where name like  '%unarodni data pozivi%';

update item_t 
set name = 'Međunarodni pozivi ' || substr(name,20) 
where name like  '%unarodni pozivi%';

update item_t 
set name = 'Novogodišnji popust ' || substr(name,20) 
where name like  '%Novog%nji popust%';

update item_t 
set name = 'Potrošnja korisnika pod limitom ' || substr(name,32) 
where name like  '%korisnika pod limitom%';

update item_t 
set name = 'Pozivi prema drugim mrežama u CG - LIBERO ' || substr(name,42) 
where name like '%Pozivi prema drugim %ama u CG - LIBERO%';

update item_t 
set name = 'Pozivi prema drugim mrežama u CG ' || substr(name,33)  
where name like '%Pozivi prema drugim %ama u CG%'  
and name not like '%ama u CG - LIBERO%';

update item_t 
set name = 'Pozivi prema mrežama u Srbiji ' || substr(name,30)  
where name like '%Pozivi prema %ama u Srbiji%';
 
update item_t 
set name = 'Pozivi u Monet mreži - LIBERO ' || substr(name,30)  
where name like '%Pozivi u Monet mre%'  and name like'%LIBERO%';

update item_t 
set name = 'Pozivi u Monet mreži ' || substr(name,21)  
where name like '%Pozivi u Monet mre%'  and name not like'%LIBERO%';

update item_t 
set name = 'Promjena vlasništva ' || substr(name,20)
where name like '%Promjena vlasni%';

update item_t
set name='Internet dopuna 06.2006'
where name='Internet Refill';

update item_t
set name='Prepaid dopuna 06.2006'
where name='Prepaid Refill';

commit;
