CREATE OR REPLACE PACKAGE tap_scheduler
AS

-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    Scheduler package
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--
-- ------------------------------------------------------------------------------
--  Responsible: Robert Frydrych, Portal Software
--
--  $RCSfile: tap_scheduler_pkg.sql,v $
--  $Revision: 1.5 $
--  $Author: pin29 $
--  $Date: 2008/10/21 09:47:34 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: tap_scheduler_pkg.sql,v 1.5 2008/10/21 09:47:34 pin29 Exp $
--  $Log: tap_scheduler_pkg.sql,v $
--  Revision 1.5  2008/10/21 09:47:34  pin29
--  Mantis ID:2353
--  Added column CALL_IDENT_NUMBER to TAP_CDR_GSM table
--
--  Revision 1.4  2006/04/10 12:30:58  pin03
--  MantisID: 1904
--  Committed by Armin
--  Added support for QOS_REQUESTED/USED_PRECEDENCE/DELAY/RELIABILITY/PEAK_THROUGHPUT/MEAN_THROUGHPUT
--
--  Revision 1.3  2006/01/19 13:44:37  pin03
--  MantisID: 1467
--  Committed by Armin
--  Added service_code and service_class columns.
--
--  Revision 1.2  2005/11/01 23:58:41  pin09
--  MantisID: 393
--  Committed by RBF
--  added supplementary service columns
--
--  Revision 1.1  2005/09/05 16:20:48  pin09
--  RBF: Initial release
--
-- ==============================================================================

PROCEDURE schedule_file
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
,db_file IN VARCHAR2
,tap_file IN VARCHAR2
);

--------------
-- constants
--------------
 --field separator
-- sep                       CONSTANT CHAR(1) := '	';
 sep                       CONSTANT CHAR(1) := CHR(9);

 --GSM call type
 gsm_call_type             CONSTANT VARCHAR2(5) := 'GSM';
 --GPRS call type
 gprs_call_type            CONSTANT VARCHAR2(5) := 'GPRS';

 --record type of charge packet
 cp_record_type            CONSTANT VARCHAR2(5) := 'CP';
 --record type of camel
 camel_record_type         CONSTANT VARCHAR2(5) := 'CAMEL';

 --extract flag selected for extraction
 flag_select               CONSTANT VARCHAR2(1) := '1';
 --extract flag extracted for TAP parsing
 flag_extract              CONSTANT VARCHAR2(1) := '2';

 --date format
 frmt_date                 CONSTANT VARCHAR2(16) := 'YYYYMMDDHH24MISS';

 --header constants
 curr_type                 CONSTANT CHAR(1) := 'H';

---------------
-- exceptions
---------------

END tap_scheduler;
/

CREATE OR REPLACE PACKAGE BODY tap_scheduler
AS

PROCEDURE schedule_file
(out_dir IN VARCHAR2
,out_file IN VARCHAR2
,db_file IN VARCHAR2
,tap_file IN VARCHAR2
)
AS
--variables
 line  VARCHAR2(1024) := '';
-- field VARCHAR2(1024) := '';

 line#       NUMBER := 0;

 CURSOR GSMlist (my_tap_filename VARCHAR2) IS
 SELECT
   file_id
  ,id
  ,record_type
  ,record_number
  ,destination_network
  ,a_number
  ,b_number
  ,c_number
  ,port_number
  ,device_number
  ,location_area_indicator
  ,cell_id
  ,basic_service
  ,charging_start_timestamp
  ,utc_time_offset
  ,duration
  ,service_code
  ,service_class
  ,originating_switch_id
  ,call_completion_indicator
  ,ms_class_mark
  ,qos_requested
  ,qos_used
  ,connect_type
  ,connect_sub_type
  ,called_country_code
  ,action_code
  ,ss_event
  ,call_ident_number
  ,wholesale_charged_tax_rate
  ,extract_flag
  ,tap_filename
 FROM
   tap_cdr_gsm cdr
 WHERE cdr.extract_flag = flag_select
   AND cdr.tap_filename = my_tap_filename;

 CURSOR GPRSlist (my_tap_filename VARCHAR2) IS
 SELECT
   file_id
  ,id
  ,record_type
  ,record_number
  ,destination_network
  ,a_number
  ,port_number
  ,device_number
  ,location_area_indicator
  ,cell_id
  ,basic_service
  ,charging_start_timestamp
  ,utc_time_offset
  ,duration
  ,service_code
  ,service_class
  ,originating_switch_id
  ,call_completion_indicator
  ,ms_class_mark
  ,qos_requested
  ,qos_requested_precedence
  ,qos_requested_delay
  ,qos_requested_reliability
  ,qos_requested_peak_throughput
  ,qos_requested_mean_throughput
  ,qos_used
  ,qos_used_precedence
  ,qos_used_delay
  ,qos_used_reliability
  ,qos_used_peak_throughput
  ,qos_used_mean_throughput
  ,connect_type
  ,connect_sub_type
  ,pdp_type
  ,pdp_address
  ,pdp_remote_address
  ,apn_address
  ,ggsn_address
  ,sgsn_address
  ,charging_id
  ,volume_sent
  ,volume_received
  ,wholesale_charged_tax_rate
  ,extract_flag
  ,tap_filename
 FROM
   tap_cdr_gprs cdr
 WHERE cdr.extract_flag = flag_select
   AND cdr.tap_filename = my_tap_filename;

 CURSOR CPlist (cdrid NUMBER) IS
 SELECT
   cdr_id
  ,rec_num
  ,rum
  ,exchange_rate
  ,impact_category
  ,chargeable_quantity_value
  ,rounded_quantity_value
  ,day_code
  ,time_interval_code
  ,charged_amount_value
  ,charging_start_timestamp
  ,pricemodel_type
  ,charged_amount_currency
  ,exchange_currency
  ,charged_currency_type
  ,productcode_used
  ,tax_treatment
  ,tax_value
  ,taxable_amount
 FROM tap_cdr_charge
 WHERE cdr_id = cdrid
   AND charged_currency_type = curr_type;

 CURSOR CAMELlist (cdrid NUMBER) IS
 SELECT
   cdr_id
  ,server_address
  ,service_level
  ,service_key
  ,default_call_handling_ind
  ,msc_address
  ,camel_reference_number
  ,dest_gsmw_number
  ,dest_gprs_apn_address
 FROM tap_cdr_camel
 WHERE cdr_id = cdrid;

 file_handler       UTL_FILE.FILE_TYPE;

BEGIN

-------------------------
-- Open file for writing
-------------------------
  tap_utl.fopen(file_handler,out_dir,out_file,tap_utl.append_mode);

  line# := 0;

---------------------------
-- Create DETAIL
---------------------------
  FOR cdr IN GSMlist(db_file)
  LOOP
  ---------------------------------------------------------------------
  -- Process GSM
  ---------------------------------------------------------------------
    line := gsm_call_type||sep||
            cdr.file_id||sep||
            cdr.id||sep||
            cdr.record_type||sep||
            cdr.record_number||sep||
            cdr.destination_network||sep||
            cdr.a_number||sep||
            cdr.b_number||sep||
            cdr.c_number||sep||
            cdr.port_number||sep||
            cdr.device_number||sep||
            cdr.location_area_indicator||sep||
            cdr.cell_id||sep||
            cdr.basic_service||sep||
            TO_CHAR(cdr.charging_start_timestamp,frmt_date)||sep||
            cdr.utc_time_offset||sep||
            cdr.duration||sep||
            cdr.service_code||sep||
            cdr.service_class||sep||
            cdr.originating_switch_id||sep||
            cdr.call_completion_indicator||sep||
            cdr.ms_class_mark||sep||
            cdr.qos_requested||sep||
            cdr.qos_used||sep||
            cdr.connect_type||sep||
            cdr.connect_sub_type||sep||
            cdr.called_country_code||sep||
            cdr.action_code||sep||
            cdr.ss_event||sep||
            cdr.call_ident_number||sep||
            cdr.wholesale_charged_tax_rate||sep||
            cdr.extract_flag||sep||
            cdr.tap_filename;

    tap_utl.put_line(file_handler,line,line#);

    FOR cp IN CPlist(cdr.id)
    LOOP
      line := cp_record_type||sep||
              cp.cdr_id||sep||
              cp.rec_num||sep||
              cp.rum||sep||
              cp.exchange_rate||sep||
              cp.impact_category||sep||
              cp.chargeable_quantity_value||sep||
              cp.rounded_quantity_value||sep||
              cp.day_code||sep||
              cp.time_interval_code||sep||
              cp.charged_amount_value||sep||
              TO_CHAR(cp.charging_start_timestamp,frmt_date)||sep||
              cp.pricemodel_type||sep||
              cp.charged_amount_currency||sep||
              cp.exchange_currency||sep||
              cp.charged_currency_type||sep||
              cp.productcode_used||sep||
              cp.tax_treatment||sep||
              cp.tax_value||sep||
              cp.taxable_amount;

      tap_utl.put_line(file_handler,line,line#);
    END LOOP; --CPlist

    FOR camel IN CAMELlist(cdr.id)
    LOOP
      line := camel_record_type||sep||
              camel.cdr_id||sep||
              camel.server_address||sep||
              camel.service_level||sep||
              camel.service_key||sep||
              camel.default_call_handling_ind||sep||
              camel.msc_address||sep||
              camel.camel_reference_number||sep||
              camel.dest_gsmw_number||sep||
              camel.dest_gprs_apn_address;

      tap_utl.put_line(file_handler,line,line#);
    END LOOP; --CAMELlist
  END LOOP; -- GSMlist

  FOR cdr IN GPRSlist(db_file)
  LOOP
  ---------------------------------------------------------------------
  -- Process GPRS
  ---------------------------------------------------------------------
    line := gprs_call_type||sep||
            cdr.file_id||sep||
            cdr.id||sep||
            cdr.record_type||sep||
            cdr.record_number||sep||
            cdr.destination_network||sep||
            cdr.a_number||sep||
            cdr.port_number||sep||
            cdr.device_number||sep||
            cdr.location_area_indicator||sep||
            cdr.cell_id||sep||
            cdr.basic_service||sep||
            TO_CHAR(cdr.charging_start_timestamp,frmt_date)||sep||
            cdr.utc_time_offset||sep||
            cdr.duration||sep||
            cdr.service_code||sep||
            cdr.service_class||sep||
            cdr.originating_switch_id||sep||
            cdr.call_completion_indicator||sep||
            cdr.ms_class_mark||sep||
            cdr.qos_requested||sep||
            cdr.qos_requested_precedence||sep||
            cdr.qos_requested_delay||sep||
            cdr.qos_requested_reliability||sep||
            cdr.qos_requested_peak_throughput||sep||
            cdr.qos_requested_mean_throughput||sep||
            cdr.qos_used||sep||
            cdr.qos_used_precedence||sep||
            cdr.qos_used_delay||sep||
            cdr.qos_used_reliability||sep||
            cdr.qos_used_peak_throughput||sep||
            cdr.qos_used_mean_throughput||sep||
            cdr.connect_type||sep||
            cdr.connect_sub_type||sep||
            cdr.pdp_type||sep||
            cdr.pdp_address||sep||
            cdr.pdp_remote_address||sep||
            cdr.apn_address||sep||
            cdr.ggsn_address||sep||
            cdr.sgsn_address||sep||
            cdr.charging_id||sep||
            cdr.volume_sent||sep||
            cdr.volume_received||sep||
            cdr.wholesale_charged_tax_rate||sep||
            cdr.extract_flag||sep||
            cdr.tap_filename;

    tap_utl.put_line(file_handler,line,line#);

    FOR cp IN CPlist(cdr.id)
    LOOP
      line := cp_record_type||sep||
              cp.cdr_id||sep||
              cp.rec_num||sep||
              cp.rum||sep||
              cp.exchange_rate||sep||
              cp.impact_category||sep||
              cp.chargeable_quantity_value||sep||
              cp.rounded_quantity_value||sep||
              cp.day_code||sep||
              cp.time_interval_code||sep||
              cp.charged_amount_value||sep||
              TO_CHAR(cp.charging_start_timestamp,frmt_date)||sep||
              cp.pricemodel_type||sep||
              cp.charged_amount_currency||sep||
              cp.exchange_currency||sep||
              cp.charged_currency_type||sep||
              cp.productcode_used||sep||
              cp.tax_treatment||sep||
              cp.tax_value||sep||
              cp.taxable_amount;

      tap_utl.put_line(file_handler,line,line#);
    END LOOP; --CPlist
  END LOOP; -- GPRSlist

-------------------------------
-- Update extract_flag for GSM
-------------------------------
  UPDATE tap_cdr_gsm
     SET extract_flag = flag_extract
        ,tap_filename = tap_file
   WHERE extract_flag = flag_select
     AND tap_filename = db_file;

--------------------------------
-- Update extract_flag for GPRS
--------------------------------
  UPDATE tap_cdr_gprs
     SET extract_flag = flag_extract
        ,tap_filename = tap_file
   WHERE extract_flag = flag_select
     AND tap_filename = db_file;

--------------
-- Close file
--------------
  tap_utl.fclose(file_handler);

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    tap_utl.exception_exit;
    RAISE;
END schedule_file;

END tap_scheduler;
/

