-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--   SQL statement file to drop the stroage table for aggregation
--
--  Open Points:
--    none
--
--  Review Status:
-- -  review
--
--  -----------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: drop_agg.sql,v $
--  $Revision: 1.1 $
--  $Author: pin24 $
--  $Date: 2005/09/05 10:40:57 $
--
-- ------------------------------------------------------------------------------
--  History:
--  $Id: drop_agg.sql,v 1.1 2005/09/05 10:40:57 pin24 Exp $
--  $Log: drop_agg.sql,v $
--  Revision 1.1  2005/09/05 10:40:57  pin24
--  STY: initial release
--
--
-- ==============================================================================


PROMPT ==========================================================================
PROMPT Dropping Roaming Aggregation Table
PROMPT Error messages complaining about missing tables or views can be ignored
PROMPT ==========================================================================

WHENEVER SQLERROR CONTINUE

DROP TABLE CUST_AGG_ROAMING;

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
