-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the CDR report tables for GGSN partial records for T-Mobile CG customer in roaming
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 

PROMPT ==========================================================================
PROMPT Dropping cust_ggsn_fraud table
PROMPT Error messages complaining about missing tables or views can be ignored
PROMPT ==========================================================================

WHENEVER SQLERROR CONTINUE

DROP TABLE CUST_GGSN_FRAUD;

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
