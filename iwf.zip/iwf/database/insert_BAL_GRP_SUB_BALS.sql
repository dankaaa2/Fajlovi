create table bal_grp_sub_bals_t_FAT
as select * from bal_grp_sub_bals_t
where obj_id0=11299352;

create table BAL_GRP_BALS_T_FAT AS
select * from BAL_GRP_BALS_T 
WHERE OBJ_ID0=11299352;

delete from bal_grp_sub_bals_t_FAT;
delete from BAL_GRP_BALS_T_FAT;

INSERT INTO bal_grp_sub_bals_t_FAT 
SELECT aa.BAL_GRP_OBJ_ID0,0, rbi.ELEMENT_ID,1149112800,1151704800,sum(rbi.SCALED_AMOUNT),0,0,0,1149112800
FROM ACCOUNT_T aa,ACCOUNT_PRODUCTS_T ap, PRODUCT_T pp,RATE_PLAN_T rp, RATE_T rr, RATE_BAL_IMPACTS_T rbi
WHERE rp.PRODUCT_OBJ_ID0=pp.POID_ID0
  AND rr.RATE_PLAN_OBJ_ID0=rp.POID_ID0
  AND rbi.OBJ_ID0=rr.POID_ID0 
  AND ap.obj_id0=aa.poid_id0
  AND ap.STATUS=1
  AND ap.PRODUCT_OBJ_ID0=pp.poid_id0 
  AND pp.name in (select fat_code from subscriber_fat)
  AND not exists(select 1 from bal_grp_sub_bals_t bgb where bgb.OBJ_ID0=aa.BAL_GRP_OBJ_ID0
  AND bgb.REC_ID2=rbi.ELEMENT_ID)
GROUP BY aa.BAL_GRP_OBJ_ID0, rbi.ELEMENT_ID;

INSERT INTO bal_grp_sub_bals_t
select * from bal_grp_sub_bals_t_FAT;

 INSERT INTO BAL_GRP_BALS_T_FAT
 SELECT DISTINCT bgsb.OBJ_ID0,bgsb.REC_ID2,0,0,0
 FROM ACCOUNT_T aa, BAL_GRP_SUB_BALS_T bgsb
 WHERE bgsb.OBJ_ID0=aa.BAL_GRP_OBJ_ID0
   AND NOT EXISTS(SELECT 1 FROM BAL_GRP_BALS_T bgb WHERE bgsb.OBJ_ID0=bgb.OBJ_ID0 AND bgb.REC_ID=bgsb.REC_ID2);

INSERT INTO bal_grp_bals_t
select * from BAL_GRP_BALS_T_FAT; 

---------------------- UPDATE AU_ tabela

INSERT INTO AU_BAL_GRP_BALS_T
   SELECT tb2.poid_id0, tb.rec_id, tb.credit_profile, tb.next_bal,
          tb.reserved_amount
     FROM BAL_GRP_BALS_T_FAT tb, AU_BAL_GRP_T tb2
    WHERE tb.obj_id0 = tb2.au_parent_obj_id0; 

INSERT INTO AU_BAL_GRP_SUB_BALS_T
   SELECT tb2.poid_id0, tb.rec_id, tb.rec_id2, tb.valid_from, tb.valid_to,
          tb.current_bal, tb.next_bal, tb.delayed_bal, tb.contributor,
          tb.rollover_data
     FROM bal_grp_sub_bals_t_FAT tb, AU_BAL_GRP_T tb2
    WHERE tb.obj_id0 = tb2.au_parent_obj_id0; 

COMMIT; 
