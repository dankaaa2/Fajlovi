-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the CDR storage tables for TAPOUT
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid, Portal Software
--
--  $RCSfile: create_tap.sql,v $
--  $Revision: 1.12 $
--  $Author: pin48 $
--  $Date: 2012/03/30 06:36:19 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: create_tap.sql,v 1.12 2012/03/30 06:36:19 pin48 Exp $
--  $Log: create_tap.sql,v $
--  Revision 1.12  2012/03/30 06:36:19  pin48
--  0002510: Problem with TAP_OUT files generation for networks with 6 digits IMSI code
--
--  Revision 1.11  2008/10/21 09:43:07  pin29
--  Mantis ID:2353
--  Added column CALL_IDENT_NUMBER to TAP_CDR_GSM table
--
--  Revision 1.10  2006/05/22 15:54:06  pin09
--  MantisID: 2062
--  Committed by RBF
--  extended length of connect sub type to 3
--
--  Revision 1.9  2006/04/10 12:29:22  pin03
--  MantisID: 1904
--  Committed by Armin
--  Added support for QOS_REQUESTED/USED_PRECEDENCE/DELAY/RELIABILITY/PEAK_THROUGHPUT/MEAN_THROUGHPUT
--
--  Revision 1.8  2006/01/19 11:09:11  pin03
--  MantisID: 1467
--  Committed by Armin
--  Added SERVICE_CODE and SERVICE_CLASS columns to GSM and GPRS tables.
--
--  Revision 1.7  2005/10/31 21:45:45  pin03
--  MantisID: 393
--  Committed by Armin
--  Added ACTION_CODE and SS_EVENT to TAP_CDR_GSM.
--
--  Revision 1.6  2005/10/20 18:01:55  pin03
--  MantisID: 809
--  Committed by Armin
--  Moved TOTAL_CHARGE from TAP_CDR_FILE to TAP_OUT_FILE.
--
--  Revision 1.5  2005/10/03 16:27:30  pin03
--  ASc: Added TOTAL_CHARGE to TAP_CDR_FILE
--
--  Revision 1.4  2005/08/29 20:34:18  pin03
--  ASc: Removed unused columns from TAP_CDR_FILE, added table TAP_OUT_FILE.
--
--  Revision 1.3  2005/08/24 20:50:08  pin03
--  ASc: Added DESTINATION_NETWORK, EXPORT_DATE and EXPORT_FILE_NAME became
--       EXTRACT_FLAG and TAP3_FILENAME.
--
--  Revision 1.2  2005/07/28 08:24:44  pin03
--  ASc: Moved EXPORTED_TIMESTAMP column, added EXPORTED_FILE_NAME column.
--
--  Revision 1.1  2005/06/24 18:05:09  pin03
--  ASc: Initial release
--
-- ==============================================================================

@drop_tap.sql

PROMPT ==========================================================================
PROMPT Creating tap cdr tables
PROMPT ==========================================================================

-- ==============================================================================
-- TAP_CDR_FILE
-- ==============================================================================

CREATE TABLE TAP_CDR_FILE
(
   ID                   NUMBER(24)                    NOT NULL,
   FILE_NAME            VARCHAR2(64)                  NOT NULL,
   FIRST_CALL_TIMESTAMP DATE                          NOT NULL,
   LAST_CALL_TIMESTAMP  DATE                          NOT NULL,
   SEQ_NUMBER           NUMBER(9)                     NOT NULL,
   CREATION_TIMESTAMP   DATE                          NOT NULL,
   PROCESSING_TIMESTAMP DATE         DEFAULT sysdate  NOT NULL,
   TOTAL_RECORDS        NUMBER(9)                     NOT NULL,
   PROCESSED_RECORDS    NUMBER(9)                     NOT NULL
);

COMMENT ON TABLE TAP_CDR_FILE                         IS 'Input file information of tap out records stored in db';
COMMENT ON COLUMN TAP_CDR_FILE.ID                     IS 'File id';
COMMENT ON COLUMN TAP_CDR_FILE.FILE_NAME              IS 'Input file name';
COMMENT ON COLUMN TAP_CDR_FILE.FIRST_CALL_TIMESTAMP   IS 'First call date/time';
COMMENT ON COLUMN TAP_CDR_FILE.LAST_CALL_TIMESTAMP    IS 'Last call date/time';
COMMENT ON COLUMN TAP_CDR_FILE.SEQ_NUMBER             IS 'Input file sequence number';
COMMENT ON COLUMN TAP_CDR_FILE.CREATION_TIMESTAMP     IS 'Input file creation date/time';
COMMENT ON COLUMN TAP_CDR_FILE.PROCESSING_TIMESTAMP   IS 'Input file processing date/time';
COMMENT ON COLUMN TAP_CDR_FILE.TOTAL_RECORDS          IS 'Number of records in input file';
COMMENT ON COLUMN TAP_CDR_FILE.PROCESSED_RECORDS      IS 'Number of stored detail records';

CREATE UNIQUE INDEX PK_TAP_CDRFILE ON TAP_CDR_FILE
(ID)
NOPARALLEL;
-- CREATE INDEX AK_TAP_CDRFILE1 ON TAP_CDR_FILE
-- (FILE_NAME, PROCESSING_TIMESTAMP)
-- NOPARALLEL;

ALTER TABLE TAP_CDR_FILE ADD (
   CONSTRAINT PK_TAP_CDRFILE PRIMARY KEY (ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_CDR_GSM
-- ==============================================================================

CREATE TABLE TAP_CDR_GSM
(
   FILE_ID                    NUMBER(24)     NOT NULL,
   ID                         NUMBER(24)     NOT NULL,
   RECORD_TYPE                VARCHAR2(3)    NOT NULL,
   RECORD_NUMBER              NUMBER(9)      NOT NULL,
   DESTINATION_NETWORK        VARCHAR2(6)    NOT NULL,
   A_NUMBER                   VARCHAR2(40)   NOT NULL,
   B_NUMBER                   VARCHAR2(40)   NOT NULL,
   C_NUMBER                   VARCHAR2(40),
   PORT_NUMBER                VARCHAR2(24),
   DEVICE_NUMBER              VARCHAR2(24),
   LOCATION_AREA_INDICATOR    VARCHAR2(10),
   CELL_ID                    VARCHAR2(15),
   BASIC_SERVICE              VARCHAR2(3),
   CHARGING_START_TIMESTAMP   DATE           NOT NULL,
   UTC_TIME_OFFSET            VARCHAR2(5),
   DURATION                   NUMBER,
   SERVICE_CODE               VARCHAR2(5),
   SERVICE_CLASS              VARCHAR2(5),
   ORIGINATING_SWITCH_ID      VARCHAR2(15),
   CALL_COMPLETION_INDICATOR  VARCHAR2(4),
   MS_CLASS_MARK              NUMBER(1),
   QOS_REQUESTED              VARCHAR2(2000),
   QOS_USED                   VARCHAR2(2000),
   CONNECT_TYPE               VARCHAR2(2),
   CONNECT_SUB_TYPE           VARCHAR2(3),
   CALLED_COUNTRY_CODE        VARCHAR2(3),
   ACTION_CODE                VARCHAR2(1),
   SS_EVENT                   VARCHAR2(2),
   CALL_IDENT_NUMBER          VARCHAR2(256),
   WHOLESALE_CHARGED_TAX_RATE NUMBER(4),
   EXTRACT_FLAG               VARCHAR2(1)    DEFAULT '0' NOT NULL,
   TAP_FILENAME               VARCHAR2(256)
);

COMMENT ON TABLE TAP_CDR_GSM                             IS 'TAP Out CDR information';
COMMENT ON COLUMN TAP_CDR_GSM.FILE_ID                    IS 'ID of file this record was in';
COMMENT ON COLUMN TAP_CDR_GSM.ID                         IS 'ID of this record';
COMMENT ON COLUMN TAP_CDR_GSM.RECORD_TYPE                IS 'Record type';
COMMENT ON COLUMN TAP_CDR_GSM.RECORD_NUMBER              IS 'Record number';
COMMENT ON COLUMN TAP_CDR_GSM.DESTINATION_NETWORK        IS 'MCC/MNC of destination network';
COMMENT ON COLUMN TAP_CDR_GSM.A_NUMBER                   IS 'A Number';
COMMENT ON COLUMN TAP_CDR_GSM.B_NUMBER                   IS 'B Number';
COMMENT ON COLUMN TAP_CDR_GSM.C_NUMBER                   IS 'C Number';
COMMENT ON COLUMN TAP_CDR_GSM.PORT_NUMBER                IS 'IMSI';
COMMENT ON COLUMN TAP_CDR_GSM.DEVICE_NUMBER              IS 'IMEI';
COMMENT ON COLUMN TAP_CDR_GSM.LOCATION_AREA_INDICATOR    IS 'Loation area indicator';
COMMENT ON COLUMN TAP_CDR_GSM.CELL_ID                    IS 'Cell Id';
COMMENT ON COLUMN TAP_CDR_GSM.BASIC_SERVICE              IS 'Basic service';
COMMENT ON COLUMN TAP_CDR_GSM.CHARGING_START_TIMESTAMP   IS 'Charging start time stamp';
COMMENT ON COLUMN TAP_CDR_GSM.UTC_TIME_OFFSET            IS 'UTC time offset, f. e. +0100';
COMMENT ON COLUMN TAP_CDR_GSM.DURATION                   IS 'Call duration';
COMMENT ON COLUMN TAP_CDR_GSM.SERVICE_CODE               IS 'Service code';
COMMENT ON COLUMN TAP_CDR_GSM.SERVICE_CLASS              IS 'Service class';
COMMENT ON COLUMN TAP_CDR_GSM.ORIGINATING_SWITCH_ID      IS 'Originating switch Id';
COMMENT ON COLUMN TAP_CDR_GSM.CALL_COMPLETION_INDICATOR  IS 'Close cause';
COMMENT ON COLUMN TAP_CDR_GSM.MS_CLASS_MARK              IS 'Mobile station class mark';
COMMENT ON COLUMN TAP_CDR_GSM.QOS_REQUESTED              IS 'Quality of service requested';
COMMENT ON COLUMN TAP_CDR_GSM.QOS_USED                   IS 'Quality of service used';
COMMENT ON COLUMN TAP_CDR_GSM.CONNECT_TYPE               IS 'Connect type';
COMMENT ON COLUMN TAP_CDR_GSM.CONNECT_SUB_TYPE           IS 'Connect sub type';
COMMENT ON COLUMN TAP_CDR_GSM.CALLED_COUNTRY_CODE        IS 'Called country code';
COMMENT ON COLUMN TAP_CDR_GSM.ACTION_CODE                IS 'Qualifies the way in which the supplementary service is used';
COMMENT ON COLUMN TAP_CDR_GSM.SS_EVENT                   IS 'Uniquely defines the supplementary service or a group of supplementary services';
COMMENT ON COLUMN TAP_CDR_GSM.CALL_IDENT_NUMBER          IS 'callIdentificationNumber';
COMMENT ON COLUMN TAP_CDR_GSM.WHOLESALE_CHARGED_TAX_RATE IS 'Wholesale charged tax rate';
COMMENT ON COLUMN TAP_CDR_GSM.EXTRACT_FLAG               IS 'Extraction status: "0" inserted, "1" selected for extraction, "2" extracted';
COMMENT ON COLUMN TAP_CDR_GSM.TAP_FILENAME               IS 'Name of TAP3 file';

CREATE UNIQUE INDEX PK_TAP_CDRGSM ON TAP_CDR_GSM
(FILE_ID, ID)
NOPARALLEL;

CREATE INDEX IDX_TAP_CDRGSM ON TAP_CDR_GSM
(FILE_ID, ID, DESTINATION_NETWORK, EXTRACT_FLAG)
NOPARALLEL;

ALTER TABLE TAP_CDR_GSM ADD (
   CONSTRAINT PK_TAP_CDRGSM PRIMARY KEY (FILE_ID, ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_CDR_GPRS
-- ==============================================================================

CREATE TABLE TAP_CDR_GPRS
(
   FILE_ID                    NUMBER(24)        NOT NULL,
   ID                         NUMBER(24)        NOT NULL,
   RECORD_TYPE                VARCHAR2(3)       NOT NULL,
   RECORD_NUMBER              NUMBER(9)         NOT NULL,
   DESTINATION_NETWORK        VARCHAR2(6)       NOT NULL,
   A_NUMBER                   VARCHAR2(40)      NOT NULL,
   PORT_NUMBER                VARCHAR2(24),
   DEVICE_NUMBER              VARCHAR2(24),
   LOCATION_AREA_INDICATOR    VARCHAR2(10),
   CELL_ID                    VARCHAR2(15),
   BASIC_SERVICE              VARCHAR2(3),
   CHARGING_START_TIMESTAMP   DATE              NOT NULL,
   UTC_TIME_OFFSET            VARCHAR2(5),
   DURATION                   NUMBER,
   SERVICE_CODE               VARCHAR2(5),
   SERVICE_CLASS              VARCHAR2(5),
   ORIGINATING_SWITCH_ID      VARCHAR2(15),
   CALL_COMPLETION_INDICATOR  VARCHAR2(4),
   MS_CLASS_MARK              NUMBER(1),
   QOS_REQUESTED              VARCHAR2(2000),
   QOS_REQUESTED_PRECEDENCE   VARCHAR2(1),      -- Mantis 1904
   QOS_REQUESTED_DELAY        VARCHAR2(1),
   QOS_REQUESTED_RELIABILITY  VARCHAR2(1),
   QOS_REQUESTED_PEAK_THROUGHPUT VARCHAR2(2),
   QOS_REQUESTED_MEAN_THROUGHPUT VARCHAR2(2),
   QOS_USED                   VARCHAR2(2000),
   QOS_USED_PRECEDENCE        VARCHAR2(1),
   QOS_USED_DELAY             VARCHAR2(1),
   QOS_USED_RELIABILITY       VARCHAR2(1),
   QOS_USED_PEAK_THROUGHPUT   VARCHAR2(2),
   QOS_USED_MEAN_THROUGHPUT   VARCHAR2(2),
   CONNECT_TYPE               VARCHAR2(2),
   CONNECT_SUB_TYPE           VARCHAR2(3),
   PDP_TYPE                   VARCHAR2(4),
   PDP_ADDRESS                VARCHAR2(64),
   PDP_REMOTE_ADDRESS         VARCHAR2(255),
   APN_ADDRESS                VARCHAR2(64),
   GGSN_ADDRESS               VARCHAR2(64),
   SGSN_ADDRESS               VARCHAR2(64),
   CHARGING_ID                NUMBER,
   VOLUME_SENT                NUMBER,
   VOLUME_RECEIVED            NUMBER,
   WHOLESALE_CHARGED_TAX_RATE NUMBER(4),
   EXTRACT_FLAG               VARCHAR2(1)    DEFAULT '0' NOT NULL,
   TAP_FILENAME               VARCHAR2(256)
);

COMMENT ON TABLE TAP_CDR_GPRS                             IS 'TAP Out CDR information';
COMMENT ON COLUMN TAP_CDR_GPRS.FILE_ID                    IS 'ID of file this record was in';
COMMENT ON COLUMN TAP_CDR_GPRS.ID                         IS 'ID of this record';
COMMENT ON COLUMN TAP_CDR_GPRS.RECORD_TYPE                IS 'Record type';
COMMENT ON COLUMN TAP_CDR_GPRS.RECORD_NUMBER              IS 'Record number';
COMMENT ON COLUMN TAP_CDR_GPRS.DESTINATION_NETWORK        IS 'MCC/MNC of destination network';
COMMENT ON COLUMN TAP_CDR_GPRS.A_NUMBER                   IS 'A Number';
COMMENT ON COLUMN TAP_CDR_GPRS.PORT_NUMBER                IS 'IMSI';
COMMENT ON COLUMN TAP_CDR_GPRS.DEVICE_NUMBER              IS 'IMEI';
COMMENT ON COLUMN TAP_CDR_GPRS.LOCATION_AREA_INDICATOR    IS 'Loation area indicator';
COMMENT ON COLUMN TAP_CDR_GPRS.CELL_ID                    IS 'Cell Id';
COMMENT ON COLUMN TAP_CDR_GPRS.BASIC_SERVICE              IS 'Basic service';
COMMENT ON COLUMN TAP_CDR_GPRS.CHARGING_START_TIMESTAMP   IS 'Charging start time stamp';
COMMENT ON COLUMN TAP_CDR_GPRS.UTC_TIME_OFFSET            IS 'UTC time offset, f. e. +0100';
COMMENT ON COLUMN TAP_CDR_GPRS.DURATION                   IS 'Call duration';
COMMENT ON COLUMN TAP_CDR_GPRS.SERVICE_CODE               IS 'Service code';
COMMENT ON COLUMN TAP_CDR_GPRS.SERVICE_CLASS              IS 'Service class';
COMMENT ON COLUMN TAP_CDR_GPRS.ORIGINATING_SWITCH_ID      IS 'Originating switch Id';
COMMENT ON COLUMN TAP_CDR_GPRS.CALL_COMPLETION_INDICATOR  IS 'Close cause';
COMMENT ON COLUMN TAP_CDR_GPRS.MS_CLASS_MARK              IS 'Mobile station class mark';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED              IS 'Quality of service requested';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED_PRECEDENCE   IS 'Quality of service requested precedence';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED_DELAY        IS 'Quality of service requested delay';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED_RELIABILITY  IS 'Quality of service requested reliability';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED_PEAK_THROUGHPUT IS 'Quality of service requested peak throughput';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_REQUESTED_MEAN_THROUGHPUT IS 'Quality of service requested mean throughput';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USED                   IS 'Quality of service used';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USEd_PRECEDENCE        IS 'Quality of service used precedence';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USEd_DELAY             IS 'Quality of service used delay';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USEd_RELIABILITY       IS 'Quality of service used reliability';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USEd_PEAK_THROUGHPUT   IS 'Quality of service used peak throughput';
COMMENT ON COLUMN TAP_CDR_GPRS.QOS_USEd_MEAN_THROUGHPUT   IS 'Quality of service used mean throughput';
COMMENT ON COLUMN TAP_CDR_GPRS.CONNECT_TYPE               IS 'Connect type';
COMMENT ON COLUMN TAP_CDR_GPRS.CONNECT_SUB_TYPE           IS 'Connect sub type';
COMMENT ON COLUMN TAP_CDR_GPRS.PDP_TYPE                   IS 'PDP type';
COMMENT ON COLUMN TAP_CDR_GPRS.PDP_ADDRESS                IS 'PDP address';
COMMENT ON COLUMN TAP_CDR_GPRS.PDP_REMOTE_ADDRESS         IS 'PDP remote address';
COMMENT ON COLUMN TAP_CDR_GPRS.APN_ADDRESS                IS 'APN address';
COMMENT ON COLUMN TAP_CDR_GPRS.GGSN_ADDRESS               IS 'GGSN address';
COMMENT ON COLUMN TAP_CDR_GPRS.SGSN_ADDRESS               IS 'CGSN address';
COMMENT ON COLUMN TAP_CDR_GPRS.CHARGING_ID                IS 'Charging Id';
COMMENT ON COLUMN TAP_CDR_GPRS.VOLUME_SENT                IS 'Upload volume';
COMMENT ON COLUMN TAP_CDR_GPRS.VOLUME_RECEIVED            IS 'Download volume';
COMMENT ON COLUMN TAP_CDR_GPRS.WHOLESALE_CHARGED_TAX_RATE IS 'Wholesale charged tax rate';
COMMENT ON COLUMN TAP_CDR_GPRS.EXTRACT_FLAG               IS 'Extraction status: "0" inserted, "1" selected for extraction, "2" extracted';
COMMENT ON COLUMN TAP_CDR_GPRS.TAP_FILENAME               IS 'Name of TAP3 file';

CREATE UNIQUE INDEX PK_TAP_CDRGPRS ON TAP_CDR_GPRS
(FILE_ID, ID)
NOPARALLEL;

CREATE INDEX IDX_TAP_CDRGPRS ON TAP_CDR_GPRS
(FILE_ID, ID, DESTINATION_NETWORK, EXTRACT_FLAG)
NOPARALLEL;

ALTER TABLE TAP_CDR_GPRS ADD (
   CONSTRAINT PK_TAP_CDRGPRS PRIMARY KEY (FILE_ID, ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_CDR_CHARGE
-- ==============================================================================

CREATE TABLE TAP_CDR_CHARGE
(
   CDR_ID                     NUMBER(24)        NOT NULL,
   REC_NUM                    NUMBER(9)         NOT NULL,
   RUM                        VARCHAR2(10)      NOT NULL,
   EXCHANGE_RATE              NUMBER,
   IMPACT_CATEGORY            VARCHAR2(10),
   CHARGEABLE_QUANTITY_VALUE  NUMBER            NOT NULL,
   ROUNDED_QUANTITY_VALUE     NUMBER            NOT NULL,
   DAY_CODE                   VARCHAR2(10)      NOT NULL,
   TIME_INTERVAL_CODE         VARCHAR2(10)      NOT NULL,
   CHARGED_AMOUNT_VALUE       NUMBER            NOT NULL,
   CHARGING_START_TIMESTAMP   DATE,
   PRICEMODEL_TYPE            VARCHAR2(1),
   CHARGED_AMOUNT_CURRENCY    VARCHAR2(3),
   EXCHANGE_CURRENCY          VARCHAR2(3),
   CHARGED_CURRENCY_TYPE      VARCHAR2(1),
   PRODUCTCODE_USED           VARCHAR2(10),
   TAX_TREATMENT              VARCHAR2(1),
   TAX_VALUE                  NUMBER,
   TAXABLE_AMOUNT             NUMBER
);

COMMENT ON TABLE TAP_CDR_CHARGE                             IS 'TAP Out CDR charge information';
COMMENT ON COLUMN TAP_CDR_CHARGE.CDR_ID                     IS 'ID of the record this charge packet belongs to';
COMMENT ON COLUMN TAP_CDR_CHARGE.REC_NUM                    IS 'Number of charge packet';
COMMENT ON COLUMN TAP_CDR_CHARGE.RUM                        IS 'RUM';
COMMENT ON COLUMN TAP_CDR_CHARGE.EXCHANGE_RATE              IS 'Exchange rate';
COMMENT ON COLUMN TAP_CDR_CHARGE.IMPACT_CATEGORY            IS 'Impact category';
COMMENT ON COLUMN TAP_CDR_CHARGE.CHARGEABLE_QUANTITY_VALUE  IS 'Chargeable quantity value';
COMMENT ON COLUMN TAP_CDR_CHARGE.ROUNDED_QUANTITY_VALUE     IS 'Rounded quantity value';
COMMENT ON COLUMN TAP_CDR_CHARGE.DAY_CODE                   IS 'Day code';
COMMENT ON COLUMN TAP_CDR_CHARGE.TIME_INTERVAL_CODE         IS 'Time interval code';
COMMENT ON COLUMN TAP_CDR_CHARGE.CHARGED_AMOUNT_VALUE       IS 'Charged amount value';
COMMENT ON COLUMN TAP_CDR_CHARGE.CHARGING_START_TIMESTAMP   IS 'Charging start timestamp';
COMMENT ON COLUMN TAP_CDR_CHARGE.PRICEMODEL_TYPE            IS 'Price model type';
COMMENT ON COLUMN TAP_CDR_CHARGE.CHARGED_AMOUNT_CURRENCY    IS 'Charged amount currency';
COMMENT ON COLUMN TAP_CDR_CHARGE.EXCHANGE_CURRENCY          IS 'Exchange currency';
COMMENT ON COLUMN TAP_CDR_CHARGE.CHARGED_CURRENCY_TYPE      IS 'Charged currency type';
COMMENT ON COLUMN TAP_CDR_CHARGE.PRODUCTCODE_USED           IS 'Product code used';
COMMENT ON COLUMN TAP_CDR_CHARGE.TAX_TREATMENT              IS 'Tax treatment';
COMMENT ON COLUMN TAP_CDR_CHARGE.TAX_VALUE                  IS 'Tax value';
COMMENT ON COLUMN TAP_CDR_CHARGE.TAXABLE_AMOUNT             IS 'Taxable amount';

CREATE UNIQUE INDEX PK_TAP_CDRCHRG ON TAP_CDR_CHARGE
(CDR_ID, REC_NUM)
NOPARALLEL;

ALTER TABLE TAP_CDR_CHARGE ADD (
   CONSTRAINT PK_TAP_CDRCHRG PRIMARY KEY (CDR_ID, REC_NUM)
      USING INDEX
);

-- ==============================================================================
-- TAP_CDR_CAMEL
-- ==============================================================================

CREATE TABLE TAP_CDR_CAMEL
(
   CDR_ID                     NUMBER(24)        NOT NULL,
   SERVER_ADDRESS             VARCHAR2(40)      NOT NULL,
   SERVICE_LEVEL              NUMBER(1)         NOT NULL,
   SERVICE_KEY                NUMBER(10)        NOT NULL,
   DEFAULT_CALL_HANDLING_IND  NUMBER(1)         NOT NULL,
   MSC_ADDRESS                VARCHAR2(40)      NOT NULL,
   CAMEL_REFERENCE_NUMBER     VARCHAR2(20)      NOT NULL,
   DEST_GSMW_NUMBER           VARCHAR2(40),
   DEST_GPRS_APN_ADDRESS      VARCHAR2(64)
);

COMMENT ON TABLE TAP_CDR_CAMEL                              IS 'TAP Out CDR CAMEL information';
COMMENT ON COLUMN TAP_CDR_CAMEL.CDR_ID                      IS 'ID of the record this charge packet belongs to';
COMMENT ON COLUMN TAP_CDR_CAMEL.SERVER_ADDRESS              IS 'Server address';
COMMENT ON COLUMN TAP_CDR_CAMEL.SERVICE_LEVEL               IS 'Service level';
COMMENT ON COLUMN TAP_CDR_CAMEL.SERVICE_KEY                 IS 'Service key';
COMMENT ON COLUMN TAP_CDR_CAMEL.DEFAULT_CALL_HANDLING_IND   IS 'Default call handling operator';
COMMENT ON COLUMN TAP_CDR_CAMEL.MSC_ADDRESS                 IS 'MSC address';
COMMENT ON COLUMN TAP_CDR_CAMEL.CAMEL_REFERENCE_NUMBER      IS 'Camel reference number';
COMMENT ON COLUMN TAP_CDR_CAMEL.DEST_GSMW_NUMBER            IS 'Destination GSMW number';
COMMENT ON COLUMN TAP_CDR_CAMEL.DEST_GPRS_APN_ADDRESS       IS 'Destination APN address';

CREATE UNIQUE INDEX PK_TAP_CDRCML ON TAP_CDR_CAMEL
(CDR_ID)
NOPARALLEL;

ALTER TABLE TAP_CDR_CAMEL ADD (
   CONSTRAINT PK_TAP_CDRCML PRIMARY KEY (CDR_ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_CDR_FILE
-- ==============================================================================

CREATE TABLE TAP_OUT_FILE
(
   ID                   NUMBER(24)                    NOT NULL,
   FILE_NAME            VARCHAR2(64)                  NOT NULL,
   RECIPIENT            VARCHAR2(5)                   NOT NULL,
   FIRST_CALL_TIMESTAMP DATE                          NOT NULL,
   LAST_CALL_TIMESTAMP  DATE                          NOT NULL,
   CREATION_TIMESTAMP   DATE                          NOT NULL,
   TOTAL_RECORDS        NUMBER(9)                     NOT NULL,
   TOTAL_CHARGE         NUMBER                        NOT NULL
);

COMMENT ON TABLE TAP_OUT_FILE                         IS 'Tap out file log';
COMMENT ON COLUMN TAP_OUT_FILE.ID                     IS 'File id';
COMMENT ON COLUMN TAP_OUT_FILE.FILE_NAME              IS 'Tap file name';
COMMENT ON COLUMN TAP_OUT_FILE.RECIPIENT              IS 'Destination network';
COMMENT ON COLUMN TAP_OUT_FILE.FIRST_CALL_TIMESTAMP   IS 'First call date/time';
COMMENT ON COLUMN TAP_OUT_FILE.LAST_CALL_TIMESTAMP    IS 'Last call date/time';
COMMENT ON COLUMN TAP_OUT_FILE.CREATION_TIMESTAMP     IS 'Tap file creation date/time';
COMMENT ON COLUMN TAP_OUT_FILE.TOTAL_RECORDS          IS 'Number of records in tap file';
COMMENT ON COLUMN TAP_OUT_FILE.TOTAL_CHARGE           IS 'Sum of charges in this file';

CREATE UNIQUE INDEX PK_TAP_OUT ON TAP_OUT_FILE
(ID)
NOPARALLEL;

CREATE INDEX IDX_TAP_OUT ON TAP_OUT_FILE
(ID, RECIPIENT, CREATION_TIMESTAMP)
NOPARALLEL;

ALTER TABLE TAP_OUT_FILE ADD (
   CONSTRAINT PK_TAP_OUT PRIMARY KEY (ID)
      USING INDEX
);
