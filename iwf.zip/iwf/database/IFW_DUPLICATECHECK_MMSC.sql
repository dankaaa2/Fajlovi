--==============================================================================
--
--          Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                            All rights reserved.
--               This material is the confidential property of
--       Portal Software Germany GmbH or its subsidiaries or licensors
--    and may be used, reproduced, stored or transmitted only in accordance
--            with a valid Portal license or sublicense agreement.
--
--------------------------------------------------------------------------------
-- Block: iScript
--------------------------------------------------------------------------------
-- Module Description:
--   Create tables for IFW_Duplicatecheck for MSC, GPRS, MMSC
--
-- Open Points:
--   <open points>
--
-- Review Status:
--   in-work
--
--------------------------------------------------------------------------------
-- Responsible: Piotr Skarpetowski
--
-- $RCSfile: IFW_DUPLICATECHECK_MMSC.sql.tpl.DEV,v $
-- $Revision: 1.2 $
-- $Author: pin27 $
-- $Date: 2006/01/04 17:24:25 $
--------------------------------------------------------------------------------


CREATE TABLE IFW_DUPLICATECHECK_MMSC
(
  TRANS_ID  NUMBER(18)                          NOT NULL,
  DATA      VARCHAR2(255 BYTE)                  NOT NULL,
  EDR_DATE  DATE                                NOT NULL
)
TABLESPACE PIPE
PCTUSED    80
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

COMMENT ON TABLE IFW_DUPLICATECHECK_MMSC IS 'Duplicate detection based on the contents of DATA';

COMMENT ON COLUMN IFW_DUPLICATECHECK_MMSC.TRANS_ID IS 'Transaction Id';

COMMENT ON COLUMN IFW_DUPLICATECHECK_MMSC.DATA IS 'Duplicate Data';

COMMENT ON COLUMN IFW_DUPLICATECHECK_MMSC.EDR_DATE IS 'EDR Date';

CREATE UNIQUE INDEX IDX_DUPCHK_DATA_MMSC ON IFW_DUPLICATECHECK_MMSC
(DATA)
NOLOGGING
TABLESPACE PIPEX
PCTFREE    10
INITRANS   12
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        12
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
PARALLEL ( DEGREE 6 INSTANCES 1 );

GRANT SELECT ON  IFW_DUPLICATECHECK_MMSC TO PIPE01_ROLE_SEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  IFW_DUPLICATECHECK_MMSC TO PIPE01_ROLE_ALL;


