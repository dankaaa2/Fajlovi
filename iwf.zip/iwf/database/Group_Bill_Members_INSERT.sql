   DECLARE
   au_par au_group_t.AU_PARENT_OBJ_ID0%TYPE;
   c1 INTEGER;
   c2 INTEGER;
   object_id0  AU_GROUP_BILLING_MEMBERS_T.OBJECT_ID0%TYPE;
   object_type AU_GROUP_BILLING_MEMBERS_T.OBJECT_TYPE%TYPE;
   object_rev   AU_GROUP_BILLING_MEMBERS_T.OBJECT_REV%TYPE ;
   acc_tag  AU_GROUP_BILLING_MEMBERS_T.ACCOUNT_TAG%TYPE ;
   
CURSOR memb_ins IS
	SELECT 
    ag.AU_PARENT_OBJ_ID0, 
 1,
 1,
 agm.OBJECT_ID0,
 agm.OBJECT_TYPE,
 max(agm.OBJECT_REV),
 agm.ACCOUNT_TAG 
FROM AU_GROUP_BILLING_MEMBERS_T agm, AU_GROUP_T ag  
WHERE ag.POID_ID0=agm.OBJ_ID0 
  AND agm.object_id0 in
       (SELECT aa.poid_id0
        FROM account_t aa
     WHERE length(aa.lineage)>24 
    AND NOT EXISTS(SELECT 1 
                   FROM GROUP_BILLING_MEMBERS_T 
       WHERE  object_id0=aa.POID_ID0)
       AND EXISTS(SELECT 1 
               FROM AU_GROUP_BILLING_MEMBERS_T 
      WHERE  object_id0=aa.POID_ID0)
    )
GROUP BY  ag.AU_PARENT_OBJ_ID0, agm.OBJECT_ID0, agm.OBJECT_TYPE, agm.ACCOUNT_TAG;

BEGIN
   OPEN memb_ins;
	LOOP
	   --  process next row in cursor
	   FETCH memb_ins into au_par,c1,c2,object_id0,object_type,object_rev,acc_tag;
	   EXIT WHEN memb_ins%NOTFOUND;
	
	 select max(rec_id)+1 into c1 from GROUP_BILLING_MEMBERS_T where obj_id0 = au_par;
	INSERT INTO GROUP_BILLING_MEMBERS_T values(au_par,c1,c2,object_id0,object_type,object_rev,acc_tag);
	
	END LOOP;
	CLOSE memb_ins ;
	
	COMMIT;
	
END;	
/
