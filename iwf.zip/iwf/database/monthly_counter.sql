create table bal_grp_sub_bals_t_MC
as select * from bal_grp_sub_bals_t
where obj_id0=11299352;

create table bal_grp_bals_t_MC as
select * from bal_grp_bals_t  
where obj_id0=11299352;

delete from bal_grp_sub_bals_t_MC;

delete from bal_grp_bals_t_MC;

insert into bal_grp_sub_bals_t_MC
select bal_grp_obj_id0,0,2000200,0,0,0,0,0,null,0
from account_t
where account_no like 'Z%'
and not exists
(select 1 from bal_grp_sub_bals_t 
where obj_id0=bal_grp_obj_id0
and rec_id2=2000200);

insert into bal_grp_bals_t_MC
select bal_grp_obj_id0,2000200,0,0,0
from account_t
where account_no like 'Z%'
and not exists
(select 1 from bal_grp_bals_t
where bal_grp_obj_id0=obj_id0 and rec_id=2000200);

insert into bal_grp_sub_bals_t
select * from bal_grp_sub_bals_t_MC;

insert into bal_grp_bals_t
select * from bal_grp_bals_t_MC;

insert into au_bal_grp_bals_t
select t2.poid_id0,t1.rec_id,t1.credit_profile,t1.next_bal,t1.reserved_amount
from bal_grp_bals_t_MC t1,au_bal_grp_t t2
where t1.obj_id0=t2.au_parent_obj_id0; 

insert into au_bal_grp_sub_bals_t
select t2.poid_id0,t1.rec_id,t1.rec_id2,t1.valid_from,t1.valid_to,t1.current_bal,t1.next_bal,t1.delayed_bal,t1.contributor,t1.rollover_data
from bal_grp_sub_bals_t_MC t1,au_bal_grp_t t2
where t1.obj_id0=t2.au_parent_obj_id0; 

commit;
