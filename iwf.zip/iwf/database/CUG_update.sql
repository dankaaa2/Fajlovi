update profile_t p
set effective_t=(select created_t
from account_t a
where p.account_obj_id0=a.poid_id0)
where name='CUG_MEMBERS';
 
update au_profile_t p
set effective_t=(select created_t
from account_t a
where p.account_obj_id0=a.poid_id0)
where name='CUG_MEMBERS';

commit;
