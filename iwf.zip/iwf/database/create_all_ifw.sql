-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create all custom tables in the Integrate scheme.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- 
-- ------------------------------------------------------------------------------
-- Responsible: Portal Software
--
-- $RCSfile: create_all_ifw.sql,v $
-- $Revision: 1.5 $
-- $Author: pin09 $
-- $Date: 2005/10/25 14:37:46 $
--
--------------------------------------------------------------------------------
-- History:
-- $Id: create_all_ifw.sql,v 1.5 2005/10/25 14:37:46 pin09 Exp $
-- $Log: create_all_ifw.sql,v $
-- Revision 1.5  2005/10/25 14:37:46  pin09
-- MantisID: 236
-- Committed by RBF
-- moved correlation to pin
--
-- Revision 1.4  2005/09/30 20:29:11  pin24
-- STY: aggregation table moved to pin
--
-- Revision 1.3  2005/09/07 14:32:12  pin03
-- ASc: Added create_ifw_funcs.sql
--
-- Revision 1.2  2005/09/05 10:42:13  pin24
-- STY: include create aggregation table sql
--
-- Revision 1.1  2005/07/26 11:05:22  pin24
-- STY: Initial release
--
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

@create_ifw_funcs.sql

commit;

SPOOL OFF

exit
