-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create all needed functions
--
--  Open Points:
--    none
--
--  Review Status:
-- -  review
--
--  -----------------------------------------------------------------------------
--  Responsible: Portal Software
--
--  $RCSfile: create_ifw_funcs.sql,v $
--  $Revision: 1.1 $
-- -$Author: pin03 $
--  $Date: 2005/09/07 14:31:28 $
--  -----------------------------------------------------------------------------
--  History:
--  $Id: create_ifw_funcs.sql,v 1.1 2005/09/07 14:31:28 pin03 Exp $
--  $Log: create_ifw_funcs.sql,v $
--  Revision 1.1  2005/09/07 14:31:28  pin03
--  ASc: Initial release.
--
-- ==============================================================================

PROMPT ==========================================================================
PROMPT Creating IFW functions
PROMPT ==========================================================================

-- ==============================================================================
-- match()
-- ==============================================================================

create or replace function match(psString varchar2, psRegExp varchar2) return number as
ret number;
begin
   if (owa_pattern.match(psString, psRegExp)) then 
      return 1;
   else 
      return 0;
   end if;
end;
/
