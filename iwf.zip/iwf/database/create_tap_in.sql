-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the CDR report tables for TAPIN
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid, Portal Software
--
--  $RCSfile: create_tap_in.sql,v $
--  $Revision: 1.3 $
--  $Author: pin48 $
--  $Date: 2012/03/30 06:30:22 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: create_tap_in.sql,v 1.3 2012/03/30 06:30:22 pin48 Exp $
--  $Log: create_tap_in.sql,v $
--  Revision 1.3  2012/03/30 06:30:22  pin48
--  0002513: problem with TAP IN CDRs insert from networks with 6 digit IMSI prefix
--
--  Revision 1.2  2006/05/22 15:54:07  pin09
--  MantisID: 2062
--  Committed by RBF
--  extended length of connect sub type to 3
--
--  Revision 1.1  2006/05/03 20:19:36  pin03
--  MantisID: 2003
--  Committed by Armin
--  Initial release.
--
-- ==============================================================================

@drop_tap_in.sql

PROMPT ==========================================================================
PROMPT Creating tap_in cdr tables
PROMPT ==========================================================================

-- ==============================================================================
-- TAP_IN_CDR_FILE
-- ==============================================================================

CREATE TABLE TAP_IN_CDR_FILE
(
   ID                    NUMBER(24)                    NOT NULL,
   FILE_NAME             VARCHAR2(64)                  NOT NULL,
   FIRST_CALL_TIMESTAMP  DATE                          NOT NULL,
   LAST_CALL_TIMESTAMP   DATE                          NOT NULL,
   SEQ_NUMBER            NUMBER(9)                     NOT NULL,
   CREATION_TIMESTAMP    DATE                          NOT NULL,
   CREATION_UTC_OFFSET   VARCHAR2(6)                   NOT NULL,
   PROCESSING_TIMESTAMP  DATE         DEFAULT sysdate  NOT NULL,
   PROCESSING_UTC_OFFSET VARCHAR2(6)                   NOT NULL,
   TOTAL_RECORDS         NUMBER(9)                     NOT NULL,
   PROCESSED_RECORDS     NUMBER(9)                     NOT NULL,
   TOTAL_CHARGE          NUMBER                        NOT NULL
);

COMMENT ON TABLE TAP_IN_CDR_FILE                         IS 'Report table for tap in files';
COMMENT ON COLUMN TAP_IN_CDR_FILE.ID                     IS 'File id';
COMMENT ON COLUMN TAP_IN_CDR_FILE.FILE_NAME              IS 'Tap in file name';
COMMENT ON COLUMN TAP_IN_CDR_FILE.FIRST_CALL_TIMESTAMP   IS 'First call date/time';
COMMENT ON COLUMN TAP_IN_CDR_FILE.LAST_CALL_TIMESTAMP    IS 'Last call date/time';
COMMENT ON COLUMN TAP_IN_CDR_FILE.SEQ_NUMBER             IS 'Tap in file sequence number';
COMMENT ON COLUMN TAP_IN_CDR_FILE.CREATION_TIMESTAMP     IS 'Tap in file creation date/time';
COMMENT ON COLUMN TAP_IN_CDR_FILE.CREATION_UTC_OFFSET    IS 'UTC time offset';
COMMENT ON COLUMN TAP_IN_CDR_FILE.PROCESSING_TIMESTAMP   IS 'Tap in file processing date/time';
COMMENT ON COLUMN TAP_IN_CDR_FILE.PROCESSING_UTC_OFFSET  IS 'UTC time offset';
COMMENT ON COLUMN TAP_IN_CDR_FILE.TOTAL_RECORDS          IS 'Number of records in input file';
COMMENT ON COLUMN TAP_IN_CDR_FILE.PROCESSED_RECORDS      IS 'Number of stored detail records';
COMMENT ON COLUMN TAP_IN_CDR_FILE.TOTAL_CHARGE           IS 'Total charge of all records in file';

CREATE UNIQUE INDEX PK_TAP_IN_CDRFILE ON TAP_IN_CDR_FILE
(ID)
NOPARALLEL;

ALTER TABLE TAP_IN_CDR_FILE ADD (
   CONSTRAINT PK_TAP_IN_CDRFILE PRIMARY KEY (ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_IN_CDR_GSM
-- ==============================================================================

CREATE TABLE TAP_IN_CDR_GSM
(
   FILE_ID                    NUMBER(24)     NOT NULL,
   ID                         NUMBER(24)     NOT NULL,
   RECORD_TYPE                VARCHAR2(3)    NOT NULL,
   RECORD_NUMBER              NUMBER(9)      NOT NULL,
   SOURCE_NETWORK             VARCHAR2(6)    NOT NULL,
   A_NUMBER                   VARCHAR2(40)   NOT NULL,
   B_NUMBER                   VARCHAR2(40)   NOT NULL,
   C_NUMBER                   VARCHAR2(40)   NOT NULL,
   PORT_NUMBER                VARCHAR2(24),
   DEVICE_NUMBER              VARCHAR2(24),
   LOCATION_AREA_INDICATOR    VARCHAR2(10),
   CELL_ID                    VARCHAR2(15),
   BASIC_SERVICE              VARCHAR2(3),
   CHARGING_START_TIMESTAMP   DATE           NOT NULL,
   UTC_TIME_OFFSET            VARCHAR2(5),
   DURATION                   NUMBER,
   SERVICE_CODE               VARCHAR2(5),
   SERVICE_CLASS              VARCHAR2(5),
   ORIGINATING_SWITCH_ID      VARCHAR2(15),
   CALL_COMPLETION_INDICATOR  VARCHAR2(4),
   MS_CLASS_MARK              NUMBER(1),
   QOS_REQUESTED              VARCHAR2(2000),
   QOS_USED                   VARCHAR2(2000),
   CONNECT_TYPE               VARCHAR2(2),
   CONNECT_SUB_TYPE           VARCHAR2(3),
   ACTION_CODE                VARCHAR2(1),
   SS_EVENT                   VARCHAR2(2),
   WHOLESALE_CHARGED_TAX_RATE NUMBER(4)   
);

COMMENT ON TABLE TAP_IN_CDR_GSM                             IS 'TAP In CDR information';
COMMENT ON COLUMN TAP_IN_CDR_GSM.FILE_ID                    IS 'ID of file this record was in';
COMMENT ON COLUMN TAP_IN_CDR_GSM.ID                         IS 'ID of this record';
COMMENT ON COLUMN TAP_IN_CDR_GSM.RECORD_TYPE                IS 'Record type';
COMMENT ON COLUMN TAP_IN_CDR_GSM.RECORD_NUMBER              IS 'Record number';
COMMENT ON COLUMN TAP_IN_CDR_GSM.SOURCE_NETWORK             IS 'MCC/MNC of source network';
COMMENT ON COLUMN TAP_IN_CDR_GSM.A_NUMBER                   IS 'A Number';
COMMENT ON COLUMN TAP_IN_CDR_GSM.B_NUMBER                   IS 'B Number';
COMMENT ON COLUMN TAP_IN_CDR_GSM.C_NUMBER                   IS 'C Number';
COMMENT ON COLUMN TAP_IN_CDR_GSM.PORT_NUMBER                IS 'IMSI';
COMMENT ON COLUMN TAP_IN_CDR_GSM.DEVICE_NUMBER              IS 'IMEI';
COMMENT ON COLUMN TAP_IN_CDR_GSM.LOCATION_AREA_INDICATOR    IS 'Loation area indicator';
COMMENT ON COLUMN TAP_IN_CDR_GSM.CELL_ID                    IS 'Cell Id';
COMMENT ON COLUMN TAP_IN_CDR_GSM.BASIC_SERVICE              IS 'Basic service';
COMMENT ON COLUMN TAP_IN_CDR_GSM.CHARGING_START_TIMESTAMP   IS 'Charging start time stamp';
COMMENT ON COLUMN TAP_IN_CDR_GSM.UTC_TIME_OFFSET            IS 'UTC time offset, f. e. +0100';
COMMENT ON COLUMN TAP_IN_CDR_GSM.DURATION                   IS 'Call duration';
COMMENT ON COLUMN TAP_IN_CDR_GSM.SERVICE_CODE               IS 'Service code';
COMMENT ON COLUMN TAP_IN_CDR_GSM.SERVICE_CLASS              IS 'Service class';
COMMENT ON COLUMN TAP_IN_CDR_GSM.ORIGINATING_SWITCH_ID      IS 'Originating switch Id';
COMMENT ON COLUMN TAP_IN_CDR_GSM.CALL_COMPLETION_INDICATOR  IS 'Close cause';
COMMENT ON COLUMN TAP_IN_CDR_GSM.MS_CLASS_MARK              IS 'Mobile station class mark';
COMMENT ON COLUMN TAP_IN_CDR_GSM.QOS_REQUESTED              IS 'Quality of service requested';
COMMENT ON COLUMN TAP_IN_CDR_GSM.QOS_USED                   IS 'Quality of service used';
COMMENT ON COLUMN TAP_IN_CDR_GSM.CONNECT_TYPE               IS 'Connect type';
COMMENT ON COLUMN TAP_IN_CDR_GSM.CONNECT_SUB_TYPE           IS 'Connect sub type';
COMMENT ON COLUMN TAP_IN_CDR_GSM.ACTION_CODE                IS 'Qualifies the way in which the supplementary service is used';
COMMENT ON COLUMN TAP_IN_CDR_GSM.SS_EVENT                   IS 'Uniquely defines the supplementary service or a group of supplementary services';
COMMENT ON COLUMN TAP_IN_CDR_GSM.WHOLESALE_CHARGED_TAX_RATE IS 'Wholesale charged tax rate';

CREATE UNIQUE INDEX PK_TAP_IN_CDRGSM ON TAP_IN_CDR_GSM
(FILE_ID, ID)
NOPARALLEL;

CREATE INDEX IDX_TAP_IN_CDRGSM ON TAP_IN_CDR_GSM
(FILE_ID, ID, SOURCE_NETWORK)
NOPARALLEL;

ALTER TABLE TAP_IN_CDR_GSM ADD (
   CONSTRAINT PK_TAP_IN_CDRGSM PRIMARY KEY (FILE_ID, ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_IN_CDR_GPRS
-- ==============================================================================

CREATE TABLE TAP_IN_CDR_GPRS
(
   FILE_ID                    NUMBER(24)        NOT NULL,
   ID                         NUMBER(24)        NOT NULL,
   RECORD_TYPE                VARCHAR2(3)       NOT NULL,
   RECORD_NUMBER              NUMBER(9)         NOT NULL,
   SOURCE_NETWORK             VARCHAR2(6)       NOT NULL,
   A_NUMBER                   VARCHAR2(40)      NOT NULL,
   PORT_NUMBER                VARCHAR2(24),
   DEVICE_NUMBER              VARCHAR2(24),
   LOCATION_AREA_INDICATOR    VARCHAR2(10),
   CELL_ID                    VARCHAR2(15),
   BASIC_SERVICE              VARCHAR2(3),
   CHARGING_START_TIMESTAMP   DATE              NOT NULL,
   UTC_TIME_OFFSET            VARCHAR2(5),
   DURATION                   NUMBER,
   SERVICE_CODE               VARCHAR2(5),
   SERVICE_CLASS              VARCHAR2(5),
   ORIGINATING_SWITCH_ID      VARCHAR2(15),
   CALL_COMPLETION_INDICATOR  VARCHAR2(4),
   MS_CLASS_MARK              NUMBER(1),
   QOS_REQUESTED              VARCHAR2(2000),
   QOS_REQUESTED_PRECEDENCE   VARCHAR2(1),      -- Mantis 1904
   QOS_REQUESTED_DELAY        VARCHAR2(1),
   QOS_REQUESTED_RELIABILITY  VARCHAR2(1),
   QOS_REQUESTED_PEAK_THROUGHPUT VARCHAR2(2),
   QOS_REQUESTED_MEAN_THROUGHPUT VARCHAR2(2),
   QOS_USED                   VARCHAR2(2000),
   QOS_USED_PRECEDENCE        VARCHAR2(1),
   QOS_USED_DELAY             VARCHAR2(1),
   QOS_USED_RELIABILITY       VARCHAR2(1),
   QOS_USED_PEAK_THROUGHPUT   VARCHAR2(2),
   QOS_USED_MEAN_THROUGHPUT   VARCHAR2(2),
   CONNECT_TYPE               VARCHAR2(2),
   CONNECT_SUB_TYPE           VARCHAR2(3),
   PDP_TYPE                   VARCHAR2(4),
   PDP_ADDRESS                VARCHAR2(64),
   PDP_REMOTE_ADDRESS         VARCHAR2(255),
   APN_ADDRESS                VARCHAR2(64),
   GGSN_ADDRESS               VARCHAR2(64),
   SGSN_ADDRESS               VARCHAR2(64),
   CHARGING_ID                NUMBER,
   VOLUME_SENT                NUMBER,
   VOLUME_RECEIVED            NUMBER,
   WHOLESALE_CHARGED_TAX_RATE NUMBER(4)
);

COMMENT ON TABLE TAP_IN_CDR_GPRS                             IS 'TAP In CDR information';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.FILE_ID                    IS 'ID of file this record was in';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.ID                         IS 'ID of this record';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.RECORD_TYPE                IS 'Record type';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.RECORD_NUMBER              IS 'Record number';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.SOURCE_NETWORK             IS 'MCC/MNC of source network';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.A_NUMBER                   IS 'A Number';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.PORT_NUMBER                IS 'IMSI';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.DEVICE_NUMBER              IS 'IMEI';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.LOCATION_AREA_INDICATOR    IS 'Loation area indicator';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CELL_ID                    IS 'Cell Id';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.BASIC_SERVICE              IS 'Basic service';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CHARGING_START_TIMESTAMP   IS 'Charging start time stamp';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.UTC_TIME_OFFSET            IS 'UTC time offset, f. e. +0100';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.DURATION                   IS 'Call duration';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.SERVICE_CODE               IS 'Service code';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.SERVICE_CLASS              IS 'Service class';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.ORIGINATING_SWITCH_ID      IS 'Originating switch Id';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CALL_COMPLETION_INDICATOR  IS 'Close cause';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.MS_CLASS_MARK              IS 'Mobile station class mark';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED              IS 'Quality of service requested';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED_PRECEDENCE   IS 'Quality of service requested precedence';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED_DELAY        IS 'Quality of service requested delay';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED_RELIABILITY  IS 'Quality of service requested reliability';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED_PEAK_THROUGHPUT IS 'Quality of service requested peak throughput';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_REQUESTED_MEAN_THROUGHPUT IS 'Quality of service requested mean throughput';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USED                   IS 'Quality of service used';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USEd_PRECEDENCE        IS 'Quality of service used precedence';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USEd_DELAY             IS 'Quality of service used delay';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USEd_RELIABILITY       IS 'Quality of service used reliability';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USEd_PEAK_THROUGHPUT   IS 'Quality of service used peak throughput';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.QOS_USEd_MEAN_THROUGHPUT   IS 'Quality of service used mean throughput';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CONNECT_TYPE               IS 'Connect type';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CONNECT_SUB_TYPE           IS 'Connect sub type';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.PDP_TYPE                   IS 'PDP type';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.PDP_ADDRESS                IS 'PDP address';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.PDP_REMOTE_ADDRESS         IS 'PDP remote address';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.APN_ADDRESS                IS 'APN address';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.GGSN_ADDRESS               IS 'GGSN address';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.SGSN_ADDRESS               IS 'CGSN address';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.CHARGING_ID                IS 'Charging Id';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.VOLUME_SENT                IS 'Upload volume';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.VOLUME_RECEIVED            IS 'Download volume';
COMMENT ON COLUMN TAP_IN_CDR_GPRS.WHOLESALE_CHARGED_TAX_RATE IS 'Wholesale charged tax rate';

CREATE UNIQUE INDEX PK_TAP_IN_CDRGPRS ON TAP_IN_CDR_GPRS
(FILE_ID, ID)
NOPARALLEL;

CREATE INDEX IDX_TAP_IN_CDRGPRS ON TAP_IN_CDR_GPRS
(FILE_ID, ID, SOURCE_NETWORK)
NOPARALLEL;

ALTER TABLE TAP_IN_CDR_GPRS ADD (
   CONSTRAINT PK_TAP_IN_CDRGPRS PRIMARY KEY (FILE_ID, ID)
      USING INDEX
);

-- ==============================================================================
-- TAP_IN_CDR_CHARGE
-- ==============================================================================

CREATE TABLE TAP_IN_CDR_CHARGE
(
   CDR_ID                     NUMBER(24)        NOT NULL,
   REC_NUM                    NUMBER(9)         NOT NULL,
   RUM                        VARCHAR2(10),
   EXCHANGE_RATE              NUMBER,
   IMPACT_CATEGORY            VARCHAR2(10),
   CHARGEABLE_QUANTITY_VALUE  NUMBER            NOT NULL,
   ROUNDED_QUANTITY_VALUE     NUMBER            NOT NULL,
   DAY_CODE                   VARCHAR2(10)      NOT NULL,
   TIME_INTERVAL_CODE         VARCHAR2(10)      NOT NULL,
   CHARGED_AMOUNT_VALUE       NUMBER            NOT NULL,
   CHARGING_START_TIMESTAMP   DATE,
   PRICEMODEL_TYPE            VARCHAR2(1),
   CHARGED_AMOUNT_CURRENCY    VARCHAR2(3),
   EXCHANGE_CURRENCY          VARCHAR2(3),
   CHARGED_CURRENCY_TYPE      VARCHAR2(1)
);

COMMENT ON TABLE TAP_IN_CDR_CHARGE                             IS 'TAP In CDR charge information';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CDR_ID                     IS 'ID of the record this charge packet belongs to';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.REC_NUM                    IS 'Number of charge packet';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.RUM                        IS 'RUM';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.EXCHANGE_RATE              IS 'Exchange rate';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.IMPACT_CATEGORY            IS 'Impact category';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CHARGEABLE_QUANTITY_VALUE  IS 'Chargeable quantity value';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.ROUNDED_QUANTITY_VALUE     IS 'Rounded quantity value';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.DAY_CODE                   IS 'Day code';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.TIME_INTERVAL_CODE         IS 'Time interval code';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CHARGED_AMOUNT_VALUE       IS 'Charged amount value';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CHARGING_START_TIMESTAMP   IS 'Charging start timestamp';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.PRICEMODEL_TYPE            IS 'Price model type';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CHARGED_AMOUNT_CURRENCY    IS 'Charged amount currency';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.EXCHANGE_CURRENCY          IS 'Exchange currency';
COMMENT ON COLUMN TAP_IN_CDR_CHARGE.CHARGED_CURRENCY_TYPE      IS 'Charged currency type';

CREATE UNIQUE INDEX PK_TAP_IN_CDRCHRG ON TAP_IN_CDR_CHARGE
(CDR_ID, REC_NUM)
NOPARALLEL;

ALTER TABLE TAP_IN_CDR_CHARGE ADD (
   CONSTRAINT PK_TAP_IN_CDRCHRG PRIMARY KEY (CDR_ID, REC_NUM)
      USING INDEX
);
