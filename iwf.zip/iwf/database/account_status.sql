update account_products_t
set status_flags=1
where obj_id0 in (select poid_id0 from account_t
where status=10102
)
and not ((service_obj_type is null or service_obj_type like '%roam%') and service_obj_type<>'/service/telco/roam/gsm/telephony');

update account_products_t
set status_flags=8
where obj_id0 in (select poid_id0 from account_t
where status=10102 
)
and ((service_obj_type is null or service_obj_type like '%roam%') and service_obj_type<>'/service/telco/roam/gsm/telephony');


update au_account_products_t
set status_flags=1 
where obj_id0 in (select poid_id0 from au_account_t 
where au_parent_obj_id0 in (select poid_id0 from account_t
where status=10102 
))
and not ((service_obj_type is null or service_obj_type like '%roam%') and service_obj_type<>'/service/telco/roam/gsm/telephony');

update au_account_products_t
set status_flags=8
where obj_id0 in (select poid_id0 from au_account_t 
where au_parent_obj_id0 in (select poid_id0 from account_t
where status=10102 
))
and ((service_obj_type is null or service_obj_type like '%roam%') and service_obj_type<>'/service/telco/roam/gsm/telephony') ;

commit;
