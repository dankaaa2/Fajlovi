create table remove_disc as
select subs_poid_id0 
from subscriber_mapping sm,subscriber_details sd 
where sm.subscriber_id=sd.subscriber_id 
and subs_msisdn in (select subs_msisdn from subscriber_cug_info 
where subs_cug_id=293 and basic_indicator='Y' and cug_access='OIA')
and sd.subscriber_id in 
(select subs_id from subscriber_msisdn 
where subs_status_code in ('1','4')
and subs_msisdn_hierarchy = '0');

create table split as
select distinct g.parent_id0 sponsor_poid,substr(s.name,18) limit, gm.account_obj_id0 member_poid
from group_t g,group_sharing_members_t gm,group_sharing_charges_t gsg,sponsorship_t s
where g.poid_id0=gm.obj_id0
and g.poid_id0=gsg.obj_id0
and gsg.sponsor_obj_id0=s.poid_id0
and s.name like 'Split billing - F%'
and s.name not like 'Split billing - FS%';

create table spent as
select account_obj_id0,sum(current_bal) balance
from bal_grp_t bg,bal_grp_sub_bals_t bgsb
where bg.poid_id0=bgsb.obj_id0
and rec_id2=2002000
and exists
(select 1
from remove_disc,split
where member_poid=subs_poid_id0
and account_obj_id0=member_poid)
group by account_obj_id0
order by balance;

create table updated_acc as
select distinct account_obj_id0 
from event_bal_impacts_t eb
where exists
(select 1 from remove_disc
where account_obj_id0=subs_poid_id0)
and product_obj_id0=21218
and not exists
(select 1
from split,spent
where member_poid=eb.account_obj_id0
and spent.account_obj_id0=member_poid
and to_number(limit,'9999.99')>balance);

create table updated_events as
select distinct obj_id0 
from event_bal_impacts_t eb
where exists
(select 1 from remove_disc
where account_obj_id0=subs_poid_id0)
and product_obj_id0=21218
and not exists
(select 1
from split,spent
where member_poid=eb.account_obj_id0
and spent.account_obj_id0=member_poid
and to_number(limit,'9999.99')>balance);

update event_bal_impacts_t eb 
set amount=0,amount_deferred=0,quantity=0
where exists
(select 1 from remove_disc
where account_obj_id0=subs_poid_id0)
and product_obj_id0=21218
and not exists
(select 1
from split,spent
where member_poid=eb.account_obj_id0
and spent.account_obj_id0=member_poid
and to_number(limit,'9999.99')>balance);

update item_t set 
item_total=(select sum(amount) from event_bal_impacts_t eb 
where eb.account_obj_id0=item_t.account_obj_id0 
and eb.item_obj_id0=item_t.poid_id0 and resource_id=978),
due=(select round(sum(amount),2) from event_bal_impacts_t eb 
where eb.account_obj_id0=item_t.account_obj_id0 
and eb.item_obj_id0=item_t.poid_id0 and resource_id=978),
delta_due=(select sum(amount)-round(sum(amount),2) 
from event_bal_impacts_t eb 
where eb.account_obj_id0=item_t.account_obj_id0 
and eb.item_obj_id0=item_t.poid_id0 and resource_id=978)
where exists
(select 1 from updated_acc ua
where ua.account_obj_id0=item_t.account_obj_id0)
and poid_type='/item/U210' 
and item_no is null; 

update c_usage_view 
set final_charge=(select sum(amount) from event_bal_impacts_t
where poid_id0=obj_id0 and resource_id=978)
where exists
(select 1 from updated_events
where obj_id0=poid_id0);

update c_usage_ext cuex set
amount = (select amount from event_bal_impacts_t eb
where cuex.obj_id0=eb.obj_id0 and cuex.rec_id=eb.rec_id), 
amount_deferred = (select amount_deferred from event_bal_impacts_t eb
where cuex.obj_id0=eb.obj_id0 and cuex.rec_id=eb.rec_id),
quantity = (select quantity from event_bal_impacts_t eb
where cuex.obj_id0=eb.obj_id0 and cuex.rec_id=eb.rec_id)
where exists
(select 1 from updated_events eu
where cuex.obj_id0=eu.obj_id0);

--report 
create table to_be_corrected as
select account_obj_id0,sum(amount) amount
from event_bal_impacts_t,split
where account_obj_id0=member_poid 
and exists
(select 1
from spent
where spent.account_obj_id0=member_poid
and to_number(limit,'9999.99')>balance)
and resource_id=978
and product_obj_id0=21218
group by account_obj_id0;

select account_no,-round(amount,2) 
from to_be_corrected,account_t
where account_obj_id0=poid_id0;

commit;
