-- ==============================================================================
--
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
--
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create the CDR report tables for GGSN partial records for T-Mobile CG customer in roaming
--
--  Open Points:
--    none
--
--  Review Status:
--    review
--

@drop_ggsn_fraud.sql

PROMPT ==========================================================================
PROMPT Creating cust_ggsn_fraud table
PROMPT ==========================================================================

-- ==============================================================================
-- CUST_GGSN_FRAUD
-- ==============================================================================

CREATE TABLE CUST_GGSN_FRAUD
(
  RECORD_TYPE                VARCHAR2(3 BYTE),
  RECORD_NUMBER              NUMBER(9),
  FILE_NAME                  VARCHAR2(64 BYTE)  NOT NULL,
  A_NUMBER                   VARCHAR2(40 BYTE),
  PORT_NUMBER                VARCHAR2(24 BYTE),
  BASIC_SERVICE              VARCHAR2(3 BYTE),
  CHARGING_START_TIMESTAMP   DATE,
  UTC_TIME_OFFSET            VARCHAR2(5 BYTE),
  DURATION                   NUMBER,
  CALL_COMPLETION_INDICATOR  VARCHAR2(4 BYTE),
  PDP_TYPE                   VARCHAR2(4 BYTE),
  PDP_ADDRESS                VARCHAR2(64 BYTE),
  APN_ADDRESS                VARCHAR2(64 BYTE),
  GGSN_ADDRESS               VARCHAR2(64 BYTE),
  SGSN_ADDRESS               VARCHAR2(64 BYTE),
  CHARGING_ID                NUMBER,
  VOLUME_SENT                NUMBER,
  VOLUME_RECEIVED            NUMBER
);



COMMENT ON COLUMN CUST_GGSN_FRAUD.RECORD_TYPE IS 'Record type';

COMMENT ON COLUMN CUST_GGSN_FRAUD.RECORD_NUMBER IS 'Record number';

COMMENT ON COLUMN CUST_GGSN_FRAUD.FILE_NAME IS 'GGSN file name';

COMMENT ON COLUMN CUST_GGSN_FRAUD.A_NUMBER IS 'A Number';

COMMENT ON COLUMN CUST_GGSN_FRAUD.PORT_NUMBER IS 'IMSI';

COMMENT ON COLUMN CUST_GGSN_FRAUD.BASIC_SERVICE IS 'Basic service';

COMMENT ON COLUMN CUST_GGSN_FRAUD.CHARGING_START_TIMESTAMP IS 'Charging start time stamp';

COMMENT ON COLUMN CUST_GGSN_FRAUD.UTC_TIME_OFFSET IS 'UTC time offset, f. e. +0100';

COMMENT ON COLUMN CUST_GGSN_FRAUD.DURATION IS 'Call duration';

COMMENT ON COLUMN CUST_GGSN_FRAUD.CALL_COMPLETION_INDICATOR IS 'Close cause';

COMMENT ON COLUMN CUST_GGSN_FRAUD.PDP_TYPE IS 'PDP type';

COMMENT ON COLUMN CUST_GGSN_FRAUD.PDP_ADDRESS IS 'PDP address';

COMMENT ON COLUMN CUST_GGSN_FRAUD.APN_ADDRESS IS 'APN address';

COMMENT ON COLUMN CUST_GGSN_FRAUD.GGSN_ADDRESS IS 'GGSN address';

COMMENT ON COLUMN CUST_GGSN_FRAUD.SGSN_ADDRESS IS 'CGSN address';

COMMENT ON COLUMN CUST_GGSN_FRAUD.CHARGING_ID IS 'Charging Id';

COMMENT ON COLUMN CUST_GGSN_FRAUD.VOLUME_SENT IS 'Upload volume';

COMMENT ON COLUMN CUST_GGSN_FRAUD.VOLUME_RECEIVED IS 'Download volume';

