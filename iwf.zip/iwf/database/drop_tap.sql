-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to drop the CDR storage tables for TAPOUT
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid, Portal Software
-- 
--  $RCSfile: drop_tap.sql,v $
--  $Revision: 1.2 $
--  $Author: pin03 $
--  $Date: 2005/08/29 20:34:33 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: drop_tap.sql,v 1.2 2005/08/29 20:34:33 pin03 Exp $
--  $Log: drop_tap.sql,v $
--  Revision 1.2  2005/08/29 20:34:33  pin03
--  ASc: Added table TAP_OUT_FILE.
--
--  Revision 1.1  2005/06/24 18:05:09  pin03
--  ASc: Initial release
--
-- ==============================================================================

PROMPT ==========================================================================
PROMPT Dropping tap cdr tables
PROMPT Error messages complaining about missing tables or views can be ignored
PROMPT ==========================================================================

WHENEVER SQLERROR CONTINUE

DROP TABLE TAP_CDR_FILE;
DROP TABLE TAP_CDR_GSM;
DROP TABLE TAP_CDR_GPRS;
DROP TABLE TAP_CDR_CHARGE;
DROP TABLE TAP_CDR_CAMEL;
DROP TABLE TAP_OUT_FILE;

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
