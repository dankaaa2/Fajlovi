-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create all custom tables in the Infranet scheme.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid, Portal Software Germany GmbH
-- 
--  $RCSfile: create_all_pin.sql,v $
--  $Revision: 1.7 $
--  $Author: pin30 $
--  $Date: 2010/02/16 12:38:25 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: create_all_pin.sql,v 1.7 2010/02/16 12:38:25 pin30 Exp $
--  $Log: create_all_pin.sql,v $
--  Revision 1.7  2010/02/16 12:38:25  pin30
--  Mantis ID: 2420
--  Fraud report - Partial GPRS sessions of T-Mobile CG customers in roaming should be stored in the Production database
--
--  Revision 1.6  2006/05/03 20:21:20  pin03
--  MantisID: 2003
--  Committed by Armin
--  Added create_tap_in.sql.
--
--  Revision 1.5  2005/10/25 14:37:47  pin09
--  MantisID: 236
--  Committed by RBF
--  moved correlation to pin
--
--  Revision 1.4  2005/09/30 20:37:33  pin24
--  STY: added HUR package
--
--  Revision 1.3  2005/09/30 20:29:11  pin24
--  STY: aggregation table moved to pin
--
--  Revision 1.2  2005/09/05 17:04:52  pin09
--  RBF: added TAP packages
--
--  Revision 1.1  2005/06/24 18:05:09  pin03
--  ASc: Initial release
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

@create_tap.sql
@create_tap_in.sql
@create_agg.sql
@create_corr.sql
@create_ggsn_fraud.sql
@tap_utl_pkg.sql
@tap_scheduler_pkg.sql
@tap_report_pkg.sql

commit;

SPOOL OFF

exit
