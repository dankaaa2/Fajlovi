create table ACCOUNT_PRODUCTS_T_BCK_0506
as
select * from ACCOUNT_PRODUCTS_T;

create table AU_ACCOUNT_PRODUCTS_T_BCK_0506
as
select * from AU_ACCOUNT_PRODUCTS_T;
  

create table plans (poid integer, obj_id0 integer);
CREATE INDEX p ON plans(poid);
insert into plans
select distinct account_products_t.obj_id0,plan_obj_id0 
from account_products_t,deal_t 
where deal_t.poid_id0=deal_obj_id0 
and deal_t.name like 'RP%_TEL' and status!=3;


--koliko treba da se update
select count(*) from account_products_t 
where deal_obj_id0 in
(select poid_id0 from deal_t where name in ('SFS','SFL10','SFL20','SFL30'))
and plan_obj_id0 = 0;
--R 10967 

update account_products_t set 
plan_obj_db = 1,
plan_obj_id0=(select poid from plans where poid = account_products_t.obj_id0),
plan_obj_type = '/plan',
plan_obj_rev =0
where deal_obj_id0 in
(select poid_id0 from deal_t where name in ('SFS','SFL10','SFL20','SFL30'))
and plan_obj_id0 = 0;
--R 10967

--koliko treba da se update
select count(*) from au_account_products_t 
where deal_obj_id0 in
(select poid_id0 from deal_t where name in ('SFS','SFL10','SFL20','SFL30'))
and plan_obj_id0 = 0;


CREATE INDEX au_poid ON au_account_t(poid_id0);
CREATE INDEX au_deal ON au_account_products_t(deal_obj_id0);
 
create table au_poid as 
select poid_id0 as obj_id0,au_parent_obj_id0 
from au_account_t
where au_account_t.POID_REV=(select POID_REV from account_t where account_t.POID_ID0=au_parent_obj_id0);



update au_account_products_t set 
plan_obj_db = 1,
plan_obj_id0=(select poid from plans where poid = (select distinct au_parent_obj_id0 from au_poid 
where au_poid.obj_id0 = au_account_products_t.obj_id0)),
plan_obj_type = 'plan',
plan_obj_rev =0
where deal_obj_id0 in
(select poid_id0 from deal_t where name in ('SFS','SFL10','SFL20','SFL30'))
and plan_obj_id0 = 0;



drop index au_poid;
drop index au_deal;
drop table au_poid;
drop table plans1;
drop table plans;

