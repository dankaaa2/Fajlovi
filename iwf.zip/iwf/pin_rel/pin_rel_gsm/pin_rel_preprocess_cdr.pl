#!/opt/portal/7.0/bin/perl
#
#       Copyright (c) 2001-2005 Portal Software, Inc. All rights reserved.  
#       This material is the confidential property of Portal Software, Inc. 
#       or its subsidiaries or licensors and may be used, reproduced, stored 
#       or transmitted only in accordance with a valid Portal license 
#       or sublicense agreement.
#
#	Revision: 2005-07-18
#	Revision: 2005-01-16
#


require "getopts.pl";
use Math::BigInt lib => 'BitVect';
use File::Basename;

$USAGE = 
"Usage: inFile interimDir tablesStr startPoid endPoid incrPoid flags\n";

#
# Define debug flag
#
$debug = 0;

#
# Define all the constants required for CDR file
#
$deli = "\t";
$dtlRec = "020";
$balRec = "900";  		# event_t
$balImpRec = "600"; 		# event_bal_impacts_t
$subBalImpRec = "605"; 		# event_essentials_t
$subBalRec = "607"; 		# event_essentials_t
$gsmRec = "520";
$gprsRec = "540";
$wapRec = "570";
$suplServEvtRecType = "620";
$taxJurisRec = "615";
$monitor_balImpRec = "800"; 	# event_essentials_t
$monitor_subBalImpRec = "805"; 	# event_essentials_t
$monitor_subBalRec = "807";  	# event_essentials_t
$rumMapRec = "400";		# event_rum_map_t

#
# Script return values
# 0-99:    Portal reserved range
# 100-255: Customer reserved range
#
$PREPROCESS_SUCCESS = 0;
$USAGE_ERR = 1;
$CANT_OPEN_FILE = 2;
$MISSING_BAL_REC = 3;
$MISSING_DTL_REC = 4;
$UNSUPPORTED_TABLE = 5;
$INVALID_POID_INCREMENT_VALUE = 6;
$END_POID_NOT_MATCHED = 7;
$SERIALIZED_DATA_EXCEEDS_LIMIT = 11;

#
# Define constants for serializing sub balance impact data
#
$SER_RECORD_DELIMITER = "\n";
$SER_VERSION = "C1,1.0" . $SER_RECORD_DELIMITER;
$SER_DELIMITER = ":";
$SER_DB_NO_DELIMITER = ";";
$SER_FIELD_VALUE_DELIMITER = ",";
$SUB_BAL_IMPACTS_PREFIX = "1:7754";
$SUB_BALANCES_PREFIX = "2:7753";
$MON_SUB_BAL_IMPACTS_PREFIX = "1:9232";
$MON_SUB_BALANCES_PREFIX = "2:9233";
$ACCOUNT_TYPE_ID0 = "1000";
$BAL_GRP_MON_TYPE_ID0 = "1024";
$BAL_GRP_TYPE_ID0 = "1020";

$VARCHAR2_SIZE_LIMIT = 4000;
$CLOB_SIZE_LIMIT = 4294967296;
$BILLING_ACCOUNT_OBJ_POS = 2;          # from billing record
$SUB_BAL_IMP_REC_ID_POS = 1;           # from sub bal impacts record
$SUB_BAL_IMP_BAL_GRP_OBJ_POS = 2;      # from sub bal impacts record
$SUB_BAL_IMP_RESOURCE_ID_POS = 3;      # from sub bal impacts record
$SUB_BALANCES_REC_ID_POS = 1;          # from sub balances record
$SUB_BALANCES_AMOUNT_POS = 2;          # from sub balances record
$SUB_BALANCES_VALID_FROM_POS = 3;      # from sub balances record
$SUB_BALANCES_VALID_TO_POS = 4;        # from sub balances record
$SUB_BALANCES_CONTRIBUTOR_POS = 5;     # from sub balances record
$OBJ_DB_POS = 0;                       # from POID value
$OBJ_TYPE_POS = 1;                     # from POID value
$OBJ_ID0_POS = 2;                      # from POID value
$END_T_POS = 21;                       # from detailed record
$DEFAULT_ROLLOVER_DATA = 0;
$MON_BAL_REC_ID_POS = 1;               #monitor bal impact record
$MON_BAL_ACCOUNT_OBJ_POS = 2;
$MON_BAL_GRP_OBJ_POS = 3;
$MON_BAL_RESOURCE_ID_POS = 4;
$MON_BAL_AMOUNT_POS  = 5;

#
# Define other constants
#
$MAX_INCREMENT_BY = 10;  # maximum increment_by value for assertion purpose

#
# Parse command line flags.
#
($#ARGV < 6) && exit_err($USAGE_ERR, $USAGE);
$inFile = $ARGV[0];

#
# BigInt is used for the 64-bit poid_id0 since this
# Perl may not be the 64-bit version.
# Using BigInt for all arithmetic is too slow.
# So, given a starting poid_id0, it is split into two 
# ranges where there will be a rollover at the 7th place.
#

$interimDir    = $ARGV[1];  # interim directory
$tablesStr     = $ARGV[2];  # tables string separated by semicolons
$startPoid     = new Math::BigInt $ARGV[3]; # starting poid value, created by REL
$expEndPoid    = new Math::BigInt $ARGV[4]; # expected ending poid value, created by REL
$incrPoid      = $ARGV[5];  # POID increment value
$flags         = $ARGV[6];  # preprocess flags from Infranet.properties

print "Interim directory : $interimDir\n" if $debug;
print "Tables string : $tablesStr\n" if $debug;
print "Start poid value : $startPoid\n" if $debug;
print "Expected end poid value : $expEndPoid\n" if $debug;
print "Poid increment value : $incrPoid\n" if $debug;
print "Falgs : $flags\n" if $debug;

#
# Assert poid increment value
#
if ($incrPoid > $MAX_INCREMENT_BY) {
   exit_err( $INVALID_POID_INCREMENT_VALUE, "invalid poid increment value", $incrPoid);
}

#
# construct output file names
#
$file = basename($inFile);
@table = split(/;/, $tablesStr);
$interimDir =~ s/\/$//;   # trim last char if it's '/'
for ($i = 0; $i < @table; $i++) {
    $outFile = $interimDir . "/" . $file . "." . $table[$i] . ".blk";
    if ($table[$i] =~ /^event_t$/i) {
        $outFile1 = $outFile;
        print "Output file 1 : $outFile1\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_bal_impacts_t$/i) {
        $outFile2 = $outFile;
        print "Output file 2 : $outFile2\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_essentials_t$/i) {
        $outFile3 = $outFile;
        print "Output file 3 : $outFile3\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_delayed_session_gprs_t$/i ||
           $table[$i] =~ /^event_dlay_sess_tlcs_t$/i ||
           $table[$i] =~ /^event_delayed_act_wap_inter_t$/i) {
        $outFile4 = $outFile;
        print "Output file 4 : $outFile4\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_dlay_sess_tlcs_svc_cds_t$/i) {
        $outFile5 = $outFile;
        print "Output file 5 : $outFile4\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_dlyd_session_tlco_gsm_t$/i) {
        $outFile6 = $outFile;
        print "Output file 6 : $outFile6\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_tax_jurisdictions_t$/i) {
        $outFile7 = $outFile;
        print "Output file 7 : $outFile7\n" if $debug;
    }
    elsif ($table[$i] =~ /^event_rum_map_t$/i) {
        $outFile8 = $outFile;
        print "Output file 8 : $outFile8\n" if $debug;
    }
    else {
        exit_err( $UNSUPPORTED_TABLE, "Unsupported table",$table[$i]);
    }    
}

#
# Initialize some constants
#
$rec_id = 0;
$foundRecForFile1 = 0;
$foundRecForFile2 = 0;
$maxBalancesLargeLength = 0;
$elemId = -1;
$serializedData = $SER_VERSION;
init();   # initialize poid increment algorithm

#
# Open the input file
#

open(IN_FILE, $inFile) || exit_err( $CANT_OPEN_FILE, $inFile, $!);
open(OUT1_FILE, ">$outFile1") || exit_err( $CANT_OPEN_FILE, $outFile1, $!);
open(OUT2_FILE, ">$outFile2") || exit_err( $CANT_OPEN_FILE, $outFile2, $!);
open(OUT3_FILE, ">$outFile3") || exit_err( $CANT_OPEN_FILE, $outFile3, $!);
# for some cases, $outFile4 and $outFile5 may not be defined
# For example, discount file does not have $outFile4 and $outFile5 files
# and GPRS/WAP event file does not have $outFile5 file
if (defined $outFile4) {
   open(OUT4_FILE, ">$outFile4") || exit_err( $CANT_OPEN_FILE, $outFile4, $!);
}
if (defined $outFile5) {
   open(OUT5_FILE, ">$outFile5") || exit_err( $CANT_OPEN_FILE, $outFile5, $!);
}
if (defined $outFile6) {
   open(OUT6_FILE, ">$outFile6") || exit_err( $CANT_OPEN_FILE, $outFile6, $!);
}
# This is the file for event_tax_jurisdictions_t table
if (defined $outFile7) {
   open(OUT7_FILE, ">$outFile7") || exit_err( $CANT_OPEN_FILE, $outFile7, $!);
}
# This is the file for event_rum_map_t table
if (defined $outFile8) {
   open(OUT8_FILE, ">$outFile8") || exit_err( $CANT_OPEN_FILE, $outFile8, $!);
}
#
# Process each record in the file.
#

$line = <IN_FILE>;
while ( $line ) {
   chomp($line);

   if ($line =~ m/^$dtlRec/o) {

      print_serialize_sub_bal();
      
      #
      # When the rollover happens, increment high-order digits
      # and reset low-order digits.
      #

      $i += $incrPoid;
      if ($i >= $maxrecs) { # need to rollover
         $i -= $maxrecs;
         $high++;
      }
      $poid_id = sprintf("$high%07u",$i);
      $rec_id = 0;
      $sb_rec_id = 0;
      $mon_sb_rec_id = 0;
      $rum_rec_id = 0;

      #
      # Get END_T for event_essentials_t table
      #
   
      @dtlRecArray = split(/$deli/, $line);
      $end_t  = $dtlRecArray[$END_T_POS];
       
      if( $foundRecForFile1 == 1 && $balRecLine =~ m/^$balRec/o) {
         print OUT1_FILE "$balRecLine$deli\n";
         $foundRecForFile1 = 0;
         $balRecLine = "";
      }
      #
      # Found another detail record without finding a bal rec for previous dtl rec.
      #

      if( $foundRecForFile1 == 1 ) {
         exit_err( $MISSING_BAL_REC );
      }

      $foundRecForFile1 = 1;

      #
      # Found another detail record without finding a service record for the previous detail rec
      # This is OK since 0 or 1 service record is expected for each detail rec.
      #

      if( $foundRecForFile2 == 1) {
         print OUT4_FILE "\n";
         print OUT6_FILE "\n";
      }
      $foundRecForFile2 = 1;

      #
      # Print the high and low order bits. Note: Right-justify
      # the low-order bits and pad with zeros.
      #

      printf(OUT1_FILE "$line$deli$poid_id$deli");
      printf(OUT4_FILE "$line$deli$poid_id$deli");
      printf(OUT6_FILE "$line$deli$poid_id$deli");
	$line = <IN_FILE>;
   }
   elsif($line =~ m/^$rumMapRec/o) {
          printf OUT8_FILE ("$line$deli$poid_id$deli$rum_rec_id$deli\n");
          $rum_rec_id = $rum_rec_id + 1;
          $line = <IN_FILE>;
   }
   elsif($line =~ m/^$balRec/o) {
     $elemId = -1;
     $tempLine = <IN_FILE>;

     #
     # Concatenate the Infranet Billing Record (record type 900 usually)
     # and the balance impact record (record type 600) if present.
     # There could be multiple of the record type 600.
     #

     $balRecLine = $line;
     #
     # Get account_obj_id0 for later use to create serialized data 
     # for event_essentials_t
     # 
     @billingRec = split(/$deli/, $balRecLine);
     @accountObj = split(/ /, $billingRec[$BILLING_ACCOUNT_OBJ_POS]);
     $accountObjId0 = $accountObj[$OBJ_ID0_POS];

     while( $tempLine =~ m/^$balImpRec/o )
     {
       $elemId =  $elemId + 1;
       chomp( $tempLine );
	   
       printf(OUT2_FILE "$tempLine$deli$poid_id$deli$rec_id$deli\n");
	   $rec_id = $rec_id + 1;
	   $tempLine = <IN_FILE>;
     }
	 $line = $tempLine;

     while ($line =~ m/^$taxJurisRec/o) {
	  chomp( $line );
 	  printf OUT7_FILE ("$line$deli$poid_id$deli$rec_id$deli$elemId$deli\n");
  	  $line = <IN_FILE>;	
     }
     $tempLine = $line;
     while( $tempLine =~ m/^$balImpRec/o )
     {
       $elemId =  $elemId + 1;
       chomp( $tempLine );

       printf(OUT2_FILE "$tempLine$deli$poid_id$deli$rec_id$deli\n");
           $rec_id = $rec_id + 1;
           $tempLine = <IN_FILE>;
     }
     $line = $tempLine;
     serialize_sub_bal();
   }
   elsif(($line =~ m/^$gprsRec/o) || ($line =~ m/^$gsmRec/o) || ($line =~ m/^$wapRec/o)) {
      if( $foundRecForFile2 == 1) {
         $foundRecForFile2 = 0;
         print OUT4_FILE "$line$deli\n";
         print OUT6_FILE "$line$deli\n";
      }
      else {

         #
         # Found a service rec without first finding a detail record
         #

         exit_err( $MISSING_DTL_REC);
      }

	#
	# Handle GSM Supplementary Service Event records
	#

	if($line =~ m/^$gsmRec/o) {
		$gsm_rec_id = 0;

		$line = <IN_FILE>;

		while( $line =~ m/^$suplServEvtRecType/o )
		{
			chomp( $line );
			printf(OUT5_FILE "$line$deli$poid_id$deli$gsm_rec_id\n");
			$gsm_rec_id++;

			$line = <IN_FILE>;
		}
	} else {

		$line = <IN_FILE>;
	}
   }
   else{
     $line = <IN_FILE>;
   } 
}

#
# Print out any serialize sub-balances data if not yet printed
#
print_serialize_sub_bal();
       
if( $foundRecForFile1 == 1 && $balRecLine =~ m/^$balRec/o) {
   print OUT1_FILE "$balRecLine$deli\n";
   $foundRecForFile1 = 0;
   $balRecLine = "";
}

#
# If we are at end of file, without finding a balance rec for
# previously found detail rec.
#

if( $foundRecForFile1 == 1) {
   exit_err( $MISSING_BAL_REC);
}

close( IN_FILE);
close( OUT1_FILE);
close( OUT2_FILE);
close( OUT3_FILE);
if (defined $OUT4_FILE) {
   close( OUT4_FILE);
}
if (defined $OUT5_FILE) {
   close( OUT5_FILE);
}
if (defined $OUT6_FILE) {
   close( OUT6_FILE);
}
if (defined $OUT7_FILE) {
   close( OUT7_FILE);
}
if (defined $OUT8_FILE) {
   close( OUT8_FILE);
}

#
# Before exiting the program, verify if end poid calculated at the end 
# matches the expected end poid value passed from command line argument
#
$endPoid = new Math::BigInt $poid_id;
print "End poid is $endPoid and expected end poid is $expEndPoid\n" if $debug;
if ($endPoid != $expEndPoid) {
   exit_err($END_POID_NOT_MATCHED, "End poid after pre-processing does not match expected end poid", $poid_id);
}

updateControlFileForClobSize($maxBalancesLargeLength);

exit($PREPROCESS_SUCCESS);

#
# Initialize algorithm for poid increment in order to improve efficiency.
#
sub init {
   # Using BigInt for all arithmetic is too slow.
   # So, given a starting poid_id0, it is split into two 
   # ranges where there will be a rollover at the 7th place.
   $maxrecs = 10000000; # use 10 million as rollover point

   #
   # Use the modulo off $maxrecs to compute the rollover
   # point and the high-order digits needed before and after
   # the rollover. Copy into non-BigInt
   # vars to improve printing performance.
   #
	$high = 0;
	my $rem = 0;
	my $tmp = 0;
	my $high_tmp = 0 ;

	($high_tmp, $tmp) =  ($startPoid->bdiv($maxrecs));
	my $tmp1 =  Math::BigInt->bstr($tmp);
	$rem = $tmp1 ;
	$tmp1 =  Math::BigInt->bstr($high_tmp);
	$high = $tmp1 ;
	$i =   ($rem - $incrPoid);
}

#
# Function to exit program with error code and error messages.
#
sub exit_err {
   $errCode = shift;
   $msg1 = shift;
   $msg2 = shift;

   print "$errCode : $msg1 : $msg2";
    
   #
   # close all files before exiting.
   #
   close(IN_FILE);
   close(OUT1_FILE);
   close(OUT2_FILE);
   close(OUT3_FILE);
   if (defined $OUT4_FILE) {
      close(OUT4_FILE);
   }
   if (defined $OUT5_FILE) {
      close(OUT5_FILE);
   }
   if (defined $OUT6_FILE) {
      close( OUT6_FILE);
   }

   close(CTL_FILE);
   close(TMP_FILE);
   exit( $errCode);
}

#
# Function to serialize sub bal impacts and sub balances data
#
# The serialized format looks like the following:
# C1,<Version>
# <N>:<Level1Array>:<recid1>:<dbNo>:<FldValueList>
# <N>:<Level2Array>:<recid1>:<recid2>:<FldValueList>
#
# Where 
# Version ::= 1.0
# LevelNArray ::= field-id piece of the encoded field number
# N ::= Level N
# FldValueList ::= alphasort{fieldname}(FldValue,)*
# FldValue ::= PoidValue | string-rep of other fields
# PoidValue ::= <poid-id> with the assumption that db,type are implied and rev is not important
# dbNo ::= Infranet database number
#
sub serialize_sub_bal {

     while ($line =~ m/^$subBalImpRec/o || $line =~ m/^$monitor_subBalImpRec/o) {
         #
         # Record type 605, 805 has the following format:
         # RECORD_TYPE<tab>REC_ID<tab>BAL_GRP_OBJ<tab>RESOURCE_ID
         #
         chomp($line);
         @subBalImp = split(/$deli/, $line);
         @balGrpObj = split(/ /, $subBalImp[$SUB_BAL_IMP_BAL_GRP_OBJ_POS]);
         if ($line =~ m/^$subBalImpRec/o){
            $serializedData .= $SUB_BAL_IMPACTS_PREFIX;
            $serializedData .= $SER_DELIMITER . $sb_rec_id;
            $sb_rec_id++;
	 }
         if ($line =~ m/^$monitor_subBalImpRec/o){
            $serializedData .= $MON_SUB_BALANCES_PREFIX;
            $serializedData .= $SER_DELIMITER . $mon_sb_rec_id;
            $mon_sb_rec_id++;
	 }
         $serializedData .= $SER_DELIMITER . $balGrpObj[$OBJ_DB_POS];
         $serializedData .= $SER_DB_NO_DELIMITER . $balGrpObj[$OBJ_ID0_POS];
         if ($line =~ m/^$subBalImpRec/o){
             $serializedData .= $SER_DB_NO_DELIMITER . $BAL_GRP_TYPE_ID0;
         }
         if ($line =~ m/^$monitor_subBalImpRec/o){
             $serializedData .= $SER_DB_NO_DELIMITER . $BAL_GRP_MON_TYPE_ID0;
         }
         $serializedData .= $SER_FIELD_VALUE_DELIMITER . $subBalImp[$SUB_BAL_IMP_RESOURCE_ID_POS];
         $serializedData .= $SER_RECORD_DELIMITER;
         $tempLine = <IN_FILE>;
         while ($tempLine =~ m/^$subBalRec/o || $tempLine =~ m/^$monitor_subBalRec/o) {
             #
             # Record type 607, 807 has the following format:
             # RECORD_TYPE<tab>REC_ID<tab>AMOUNT<tab>VALID_FROM<tab>VALID_TO<tab>CONTRIBUTOR
             #
             chomp( $tempLine );
             @subBalances = split(/$deli/, $tempLine);
             $serializedData .= $SUB_BALANCES_PREFIX;
             $serializedData .= $SER_DELIMITER . $subBalances[$SUB_BALANCES_REC_ID_POS];
             $serializedData .= $SER_DELIMITER . $subBalImp[$SUB_BAL_IMP_REC_ID_POS];
             $serializedData .= $SER_DELIMITER . $subBalances[$SUB_BALANCES_AMOUNT_POS];
             $serializedData .= $SER_FIELD_VALUE_DELIMITER . "\"" . $subBalances[$SUB_BALANCES_CONTRIBUTOR_POS] . "\"";
             if ($tempLine =~ m/^$subBalRec/o) {
                $serializedData .= $SER_FIELD_VALUE_DELIMITER . $DEFAULT_ROLLOVER_DATA;
             }
             $serializedData .= $SER_FIELD_VALUE_DELIMITER . $subBalances[$SUB_BALANCES_VALID_FROM_POS];
             $serializedData .= $SER_FIELD_VALUE_DELIMITER . $subBalances[$SUB_BALANCES_VALID_TO_POS];
             $serializedData .= $SER_RECORD_DELIMITER;
	     $tempLine = <IN_FILE>;

         }
         while ( $tempLine =~ m/^$monitor_balImpRec/o ) {
             #
             # Record type 800 has the following format:
             # RECORD_TYPE<tab>REC_ID<tab>ACCOUNT_OBJ<tab>BAL_GRP_OBJ<tab>RESOURCE_ID<tab>AMOUNT
             #
             chomp($tempLine);
             @subBalImp = split(/$deli/, $tempLine);

             $serializedData .= $MON_SUB_BAL_IMPACTS_PREFIX;                                 
             $serializedData .= $SER_DELIMITER . $subBalImp[$MON_BAL_REC_ID_POS];    

             @monAccountObj = split(/ /, $subBalImp[$MON_BAL_ACCOUNT_OBJ_POS]);
             $serializedData .= $SER_DELIMITER . $monAccountObj[$OBJ_DB_POS];
             $serializedData .= $SER_DB_NO_DELIMITER . $monAccountObj[$OBJ_ID0_POS];
             $serializedData .= $SER_DB_NO_DELIMITER . $ACCOUNT_TYPE_ID0;

             $serializedData .= $SER_FIELD_VALUE_DELIMITER . $subBalImp[$MON_BAL_AMOUNT_POS];

             @monBalGrpObj = split(/ /, $subBalImp[$MON_BAL_GRP_OBJ_POS]);
             $serializedData .= $SER_FIELD_VALUE_DELIMITER . $monBalGrpObj[$OBJ_DB_POS];
             $serializedData .= $SER_DB_NO_DELIMITER . $monBalGrpObj[$OBJ_ID0_POS];
             $serializedData .= $SER_DB_NO_DELIMITER . $BAL_GRP_MON_TYPE_ID0;

             $serializedData .= $SER_FIELD_VALUE_DELIMITER . $subBalImp[$MON_BAL_RESOURCE_ID_POS];     

             $serializedData .= $SER_RECORD_DELIMITER;
             $tempLine = <IN_FILE>;
         }
         $line = $tempLine;
     }
}

#
# Print out serialized data if needed
#
sub print_serialize_sub_bal {
   my $dataLength = length($serializedData);
   if ($serializedData ne $SER_VERSION) {
      if ($dataLength < $VARCHAR2_SIZE_LIMIT) {
         $tempLine = sprintf("$poid_id$deli$serializedData$deli$deli$accountObjId0$deli$end_t");
      }
      elsif ($dataLength < $CLOB_SIZE_LIMIT) {
         $tempLine = sprintf("$poid_id$deli$deli$serializedData$deli$accountObjId0$deli$end_t");
         if ($dataLength > $maxBalancesLargeLength) {
            $maxBalancesLargeLength = $dataLength;
         }
      }
      else
      {
         exit_err($SERIALIZED_DATA_EXCEEDS_LIMIT, 
            "Serialized data exceeds CLOB size limitation", $dataLength);
      }

      my $length = length($tempLine);
      $tempLine = sprintf("%010u$tempLine", $length);
      print "sub_bal_impact serialization  aft lenght\n $tempLine\n" if $debug;
      print OUT3_FILE "$tempLine";
    
      #
      # Reset serialized string
      #
      $serializedData = $SER_VERSION;
   }
}

#
# Update data size for balances_large column in template control file only if required
# data size is greater than the one currently specified in the template control file
#
sub updateControlFileForClobSize {
    my $size = $_[0];

    if ($size == 0) {
        #
        # No balances_large record was generated so no need to continue
        #
        return;
    }

    my $needToUpdate = 0;
    my $controlFile = "event_essentials_t.ctl";
    my $tmpFile = $interimDir . "/" . $file . "." . $controlFile . ".tmp";
    open(CTL_FILE, "$controlFile") || exit_err($CANT_OPEN_FILE, $controlFile, $!);
    open(TMP_FILE, ">$tmpFile") || exit_err($CANT_OPEN_FILE, $tmpFile, $!);

    while ($line = <CTL_FILE>) {
        if ($line =~ /BALANCES_LARGE/i && $line =~ /CHAR\((\d+)\)/i) {
            #
            # update data size only if required size is greater than 
            # current size that is specified in template control file
            #
            if ($size > $1) {
                $line =~ s/CHAR\((\d+)\)/CHAR($size)/i;
                $needToUpdate = 1;
            }
        }
        print TMP_FILE $line;
    }
    close(CTL_FILE);
    close(TMP_FILE);

    if ($needToUpdate == 1) {
        #
        # rename temporary file to template control file
        #
        if ($^O =~ /win/i) {	# Windows
            system("copy $tmpFile $controlFile; del $tmpFile");
        }
        else {			# UNIX
            system("cp $tmpFile $controlFile; rm $tmpFile");
        }
        print "Update balances_large size to $size for template control file $controlFile.\n" if $debug;
    }
    else {
        # 
        # No need to update template control file - delete temporary file
        #
        if ($^O =~ /win/i) {	# Windows
            system("del $tmpFile");
        }
        else {			# UNIX
            system("rm $tmpFile");
        }
     }
}



