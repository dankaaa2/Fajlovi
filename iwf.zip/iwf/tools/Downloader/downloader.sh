#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Start files download
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Robert Frydrych
#
#  $RCSfile: downloader.sh,v $
#  $Revision: 1.3 $
#  $Author: pin09 $
#  $Date: 2006/03/02 09:58:53 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: downloader.sh,v 1.3 2006/03/02 09:58:53 pin09 Exp $
#  $Log: downloader.sh,v $
#  Revision 1.3  2006/03/02 09:58:53  pin09
#  MantisID: 1414
#  Committed by RBF
#  return downloader exit code
#
#  Revision 1.2  2006/01/11 18:01:37  pin27
#  MantisID: 460
#  Committed by waldek
#  added export of lib
#
#  Revision 1.1  2005/11/25 00:20:33  pin09
#  MantisID: 462
#  Committed by RBF
#  Initial release
#
# ==============================================================================

exec 2>&1

DATE_FORMAT="YYYYMMDDHH24MISS"

TIMESTAMP=`date +%Y%m%d%H%M%S`

#script name and directory
EXEC=${0}
PARAMS=${*}
PRG=${EXEC##*/}
BASE=${PRG%.*}
ORIG=${PWD}
DIR=${EXEC%/*}
if [[ "${DIR}" = "${EXEC}" || "${DIR}" = "" ]];
then
  DIR=.
fi

#variables for file names build
FILE_SUFFIX='_'${TIMESTAMP}

function UsageIs {
  echo "Usage is:" | tee -a ${LOG_FILE}
  echo "${PRG} <file with environment variable>" | tee -a ${LOG_FILE}
  echo "" | tee -a ${LOG_FILE}

  Exit 2
}

function Exit {
  EXIT=0

  if [ $# != 0 ];
  then
    EXIT=${1}
  fi

  case ${EXIT} in
    (0)
      echo 'I '`date` "${PRG} successfully finished" | tee -a ${LOG_FILE}
      ;;
    (1)
      echo 'I '`date` "${PRG} terminated by user" | tee -a ${LOG_FILE}
      ;;
    (2)
      echo 'I '`date` "${PRG} finished with configuration error" | tee -a ${LOG_FILE}
      ;;
    (3)
      echo 'I '`date` "${PRG} finished with database error: ${2}" | tee -a ${LOG_FILE}
      ;;
    (*)
      echo 'I '`date` "${PRG} finished with errors" | tee -a ${LOG_FILE}
      ;;
  esac

  exit ${EXIT}
}

trap "echo Exiting...; Exit 1" 1 2 15

# define config file
CONFIG_EXT="conf"
CONFIG_FILE="${DIR}/pin.${CONFIG_EXT}"
LOG_EXT="log"
DEFAULT_LOG_FILE="${DIR}/${BASE}.${LOG_EXT}"
LOG_FILE=${DEFAULT_LOG_FILE}

####################################################################
# Check and initialize parameters
####################################################################
#### Search for config file
if [ ! -r "${CONFIG_FILE}" ];
then
  echo 'E '`date` Cannot open file ${CONFIG_FILE}! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Log file
LOG=`awk '/^- pin_cdr_collector pin_cdr_collector_logfile/ {print $4}' ${CONFIG_FILE}`
if [ "${LOG}" = "" ]
then
  echo 'W '`date` "Configuration parameter logfile not set (use default)!" | tee -a ${LOG_FILE}
else
  LOG_NAME=${LOG##*/}
  LOG_BASE=${LOG_NAME%.*}
  LOG_DIR=${LOG%/*}
  LOG_FILE=${LOG_DIR}/${LOG_BASE}.${LOG_EXT}
fi

####################################################################
# Main program
####################################################################
#go to the script home directory
cd ${DIR}

TERM=vt100
export TERM

if [[ -f /etc/profile ]];
then
  . /etc/profile
fi

if [[ $# -ge 1 ]];
then
  . ${1}
else
  UsageIs
fi

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$IFW_HOME/custom/tools/FTP/lib

echo "####################################################################" >> ${LOG_FILE}
$BASE >> ${LOG_FILE} 2>&1
EXIT=$?
echo "####################################################################" >> ${LOG_FILE}

exit ${EXIT}

