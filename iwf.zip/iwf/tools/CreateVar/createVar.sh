#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Create necessary var directories
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible:
#
#  $RCSfile: createVar.sh,v $
#  $Revision: 1.24 $
#  $Author: pin09 $
#  $Date: 2012/08/20 10:49:12 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: createVar.sh,v 1.24 2012/08/20 10:49:12 pin09 Exp $
#  $Log: createVar.sh,v $
#  Revision 1.24  2012/08/20 10:49:12  pin09
#  0002490: MiO downloader
#
#  Revision 1.23  2010/11/23 08:42:08  pin09
#  0002453: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with SDP_PARSE pipeline
#
#  Revision 1.22  2010/11/15 10:36:46  pin09
#  0002451: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with CCN40_PARSE pipeline
#
#  Revision 1.21  2010/10/28 07:49:00  pin09
#  0002450: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with AIR_PARSE pipeline
#
#  Revision 1.20  2008/08/06 12:18:31  pin26
#  MantisID: 2343
#  Committed by RBF
#  added Starhome
#
#  Revision 1.19  2008/04/18 09:27:16  pin02
#  0002334: Modification of mediation due to DWH requests
#  Added command for creating log/INTCON_DWH/recycle directory
#
#  Revision 1.18  2008/04/18 08:11:51  pin02
#  0002334: Modification of mediation due to DWH requests
#
#  Revision 1.17  2006/03/09 13:39:20  pin09
#  MantisID: 1759
#  Committed by RBF
#  added listener
#
#  Revision 1.16  2006/02/20 10:39:13  pin09
#  MantisID: 1348
#  Committed by RBF
#  added tools
#
#  Revision 1.15  2005/09/15 18:28:21  pin09
#  RBF: added FTAM directory
#
#  Revision 1.14  2005/09/12 10:34:28  pin09
#  RBF: added FTP directory and input directory parameter
#
#  Revision 1.13  2005/08/25 16:10:48  pin
#  wkoko: production update
#
#  Revision 1.12  2005/08/19 14:28:14  pin09
#  RBF: added TAPout stream and MMS PreParser
#
#  Revision 1.11  2005/07/25 13:48:13  pin09
#  RBF: added recycle directories
#
#  Revision 1.10  2005/07/06 18:05:09  pin09
#  RBF: added TAPin stream
#
#  Revision 1.9  2005/07/05 15:45:10  pin27
#  wkokorzy - removed Infranet dirs
#
#  Revision 1.8  2005/07/05 10:19:17  pin27
#  wkokorzy - added dirs
#
#  Revision 1.7  2005/06/09 13:18:47  pin09
#  RBF: added billing time discounting
#
#  Revision 1.6  2005/06/09 12:44:37  pin32
#  rerate dirs
#
#  Revision 1.5  2005/06/08 14:00:05  pin32
#  rerate
#
#  Revision 1.4  2005/05/24 09:09:11  pin27
#  Corrected problem with interim directories.
#  Wkokorzy.
#
#  Revision 1.3  2005/05/17 17:30:58  pin09
#  RBF: New pipelines
#
#  Revision 1.2  2005/05/11 16:17:36  pin09
#  Rating pipelines renaming
#
#  Revision 1.1  2005/03/30 13:11:49  pin09
#  RBF: Initial release
#
# ==============================================================================

COUNTER=0

function CreateDir {
  DIR=${1}
  if [ ! -d ${DIR} ]; then
    mkdir -p ${DIR}
    ((COUNTER=${COUNTER}+1))
  fi
}

function CreateLink {
  DIR=${1}
  if [[ $# = 1 ]]; then
    LINK=${1##*/}
  else
    LINK=${2}
  fi
  if [ ! -L ${LINK} ]; then
    ln -s ${DIR} ${LINK}
    ((COUNTER=${COUNTER}+1))
  fi
}

if [ -d "${1}" ];
then
  cd ${1}
fi

CreateDir var
CreateDir var/balance
CreateDir var/info
CreateDir var/listener
CreateDir var/log
CreateDir var/log/mms_pre_parse
CreateDir var/log/FTAM
CreateDir var/log/FTP
CreateDir var/log/SFTP
CreateDir var/log/tools
CreateDir var/log/process
CreateDir var/log/MSC_PARSE
CreateDir var/log/MSC_PARSE/dump
CreateDir var/log/MSC_PARSE/stream
CreateDir var/log/MSC_VALIDATE
CreateDir var/log/MSC_VALIDATE/dump
CreateDir var/log/MSC_VALIDATE/stream
CreateDir var/log/MSC_VALIDATE/recycle
CreateDir var/log/MSC_ASSEMBLE
CreateDir var/log/MSC_ASSEMBLE/dump
CreateDir var/log/MSC_ASSEMBLE/stream
CreateDir var/log/MSC_ASSEMBLE/recycle
CreateDir var/log/CGSN_PARSE
CreateDir var/log/CGSN_PARSE/dump
CreateDir var/log/CGSN_PARSE/stream
CreateDir var/log/CGSN_VALIDATE
CreateDir var/log/CGSN_VALIDATE/dump
CreateDir var/log/CGSN_VALIDATE/stream
CreateDir var/log/CGSN_VALIDATE/recycle
CreateDir var/log/CGSN_ASSEMBLE
CreateDir var/log/CGSN_ASSEMBLE/dump
CreateDir var/log/CGSN_ASSEMBLE/stream
CreateDir var/log/CGSN_ASSEMBLE/recycle
CreateDir var/log/MMSC_PARSE
CreateDir var/log/MMSC_PARSE/dump
CreateDir var/log/MMSC_PARSE/stream
CreateDir var/log/MMSC_VALIDATE
CreateDir var/log/MMSC_VALIDATE/dump
CreateDir var/log/MMSC_VALIDATE/stream
CreateDir var/log/MMSC_VALIDATE/recycle
CreateDir var/log/INTCON
CreateDir var/log/INTCON/dump
CreateDir var/log/INTCON/stream
CreateDir var/log/INTCON/recycle
CreateDir var/log/CAMEL
CreateDir var/log/CAMEL/dump
CreateDir var/log/CAMEL/stream
CreateDir var/log/CAMEL/recycle
CreateDir var/log/USSD
CreateDir var/log/USSD/dump
CreateDir var/log/USSD/stream
CreateDir var/log/USSD/recycle
CreateDir var/log/STARHOME
CreateDir var/log/STARHOME/dump
CreateDir var/log/STARHOME/stream
CreateDir var/log/STARHOME/recycle
CreateDir var/log/GSM_RATE
CreateDir var/log/GSM_RATE/dump
CreateDir var/log/GSM_RATE/stream
CreateDir var/log/GSM_RATE/recycle
CreateDir var/log/GPRS_RATE
CreateDir var/log/GPRS_RATE/dump
CreateDir var/log/GPRS_RATE/stream
CreateDir var/log/GPRS_RATE/recycle
CreateDir var/log/RGSM_RATE
CreateDir var/log/RGSM_RATE/dump
CreateDir var/log/RGSM_RATE/stream
CreateDir var/log/RGSM_RATE/recycle
CreateDir var/log/RGPRS_RATE
CreateDir var/log/RGPRS_RATE/dump
CreateDir var/log/RGPRS_RATE/stream
CreateDir var/log/RGPRS_RATE/recycle
CreateDir var/log/TAP_OUT_EXTRACT
CreateDir var/log/TAP_OUT_EXTRACT/dump
CreateDir var/log/TAP_OUT_EXTRACT/stream
CreateDir var/log/TAP_OUT_PARSE
CreateDir var/log/TAP_OUT_PARSE/dump
CreateDir var/log/TAP_OUT_PARSE/stream
CreateDir var/log/TAP_IN_PARSE
CreateDir var/log/TAP_IN_PARSE/dump
CreateDir var/log/TAP_IN_PARSE/stream
CreateDir var/log/TAP_IN_VALIDATE
CreateDir var/log/TAP_IN_VALIDATE/dump
CreateDir var/log/TAP_IN_VALIDATE/stream
CreateDir var/log/TAP_IN_VALIDATE/recycle
CreateDir var/log/TAP_IN_ASSEMBLE
CreateDir var/log/TAP_IN_ASSEMBLE/dump
CreateDir var/log/TAP_IN_ASSEMBLE/stream
CreateDir var/log/TAP_IN_ASSEMBLE/recycle
CreateDir var/log/TAP_IN_UPMARK
CreateDir var/log/TAP_IN_UPMARK/dump
CreateDir var/log/TAP_IN_UPMARK/stream
CreateDir var/log/TAP_IN_UPMARK/recycle
CreateDir var/log/TAP_IN_RATE
CreateDir var/log/TAP_IN_RATE/dump
CreateDir var/log/TAP_IN_RATE/stream
CreateDir var/log/TAP_IN_RATE/recycle
CreateDir var/log/pin_rel
CreateDir var/log/BT_DISCOUNT
CreateDir var/log/BT_DISCOUNT/dump
CreateDir var/log/BT_DISCOUNT/stream
#mediationDWH framework
#CCN_PARSE pipeline
CreateDir var/log/CCN_PARSE
CreateDir var/log/CCN_PARSE/dump
CreateDir var/log/CCN_PARSE/stream
#SCP_PARSE pipeline
CreateDir var/log/SCP_PARSE
CreateDir var/log/SCP_PARSE/dump
CreateDir var/log/SCP_PARSE/stream
#INTCON_DWH pipeline
CreateDir var/log/INTCON_DWH
CreateDir var/log/INTCON_DWH/dump
CreateDir var/log/INTCON_DWH/stream
CreateDir var/log/INTCON_DWH/recycle
#End mediationDWH framework

#mediationDWH40 framework
#AIR_PARSE pipeline
CreateDir var/log/AIR_PARSE
CreateDir var/log/AIR_PARSE/dump
CreateDir var/log/AIR_PARSE/stream
#CCN40_PARSE pipeline
CreateDir var/log/CCN40_PARSE
CreateDir var/log/CCN40_PARSE/dump
CreateDir var/log/CCN40_PARSE/stream
#CCNV40_PARSE pipeline
CreateDir var/log/CCNV40_PARSE
CreateDir var/log/CCNV40_PARSE/dump
CreateDir var/log/CCNV40_PARSE/stream
#SDP_PARSE pipeline
CreateDir var/log/SDP_PARSE
CreateDir var/log/SDP_PARSE/dump
CreateDir var/log/SDP_PARSE/stream

#End mediationDWH40 framework
echo "`date`\nCreated ${COUNTER} directories"

