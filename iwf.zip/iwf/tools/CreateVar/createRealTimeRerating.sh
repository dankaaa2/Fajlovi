#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Create necessary var directories
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible:
#
#  $RCSfile: createRealTimeRerating.sh,v $
#  $Revision: 1.5 $
#  $Author: pin $
#  $Date: 2005/08/25 16:12:53 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: createRealTimeRerating.sh,v 1.5 2005/08/25 16:12:53 pin Exp $
#  $Log: createRealTimeRerating.sh,v $
#  Revision 1.5  2005/08/25 16:12:53  pin
#  wkoko: production update
#
#  Revision 1.4  2005/06/24 11:08:17  pin27
#  wkokorzy - Changed directory names
#
#  Revision 1.3  2005/06/09 12:44:37  pin32
#  rerate dirs
#
#  Revision 1.2  2005/05/24 09:09:11  pin27
#  Corrected problem with interim directories.
#  Wkokorzy.
#
#  Revision 1.1  2005/05/17 11:52:01  pin27
#  Initial
#
#  Revision 1.1  2005/03/30 13:11:49  pin09
#  RBF: Initial release
#
# ==============================================================================

COUNTER=0

function CreateDir {
  DIR=${1}
  if [ ! -d ${DIR} ]; then
    mkdir -p ${DIR}
    ((COUNTER=${COUNTER}+1))
  fi
}

function CreateLink {
  DIR=${1}
  LINK=${2}
  if [ ! -L ${LINK} ]; then
    ln -s ${DIR} ${LINK}
    ((COUNTER=${COUNTER}+1))
  fi
}

CreateDir $PIN_LOG
CreateDir $PIN_LOG/log/RT_GSM_RERATE
CreateDir $PIN_LOG/log/RT_GSM_RERATE/dump
CreateDir $PIN_LOG/log/RT_GSM_RERATE/stream
CreateDir $PIN_LOG/log/RT_GPRS_RERATE
CreateDir $PIN_LOG/log/RT_GPRS_RERATE/dump
CreateDir $PIN_LOG/log/RT_GPRS_RERATE/stream
CreateDir $PIN_LOG/log/rerate
CreateDir $PIN_LOG/log/rerate/stream

echo "`date`\nCreated ${COUNTER} directories"

