--==============================================================================
--
--          Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                            All rights reserved.
--               This material is the confidential property of
--       Portal Software Germany GmbH or its subsidiaries or licensors
--    and may be used, reproduced, stored or transmitted only in accordance
--            with a valid Portal license or sublicense agreement.
--
--------------------------------------------------------------------------------
-- Block: iScript
--------------------------------------------------------------------------------
-- Module Description:
--     load TAP3_VAL, disable 3 FKs and run the updates, enable 3 FKs
--
--
--
-- Open Points:
--   <open points>
--
-- Review Status:
--   in-work
--
--------------------------------------------------------------------------------
-- Responsible: Robert Bohdan Frydrych
--
-- $RCSfile: TAP3in_VAL.sql,v $
-- $Revision: 1.1 $
-- $Author: pin01 $
-- $Date: 2005/06/24 10:48:53 $
--------------------------------------------------------------------------------
-- $Id: TAP3in_VAL.sql,v 1.1 2005/06/24 10:48:53 pin01 Exp $
-- $Log: TAP3in_VAL.sql,v $
-- Revision 1.1  2005/06/24 10:48:53  pin01
-- *** empty log message ***
--
--==============================================================================

update ifw_ruleitem set rule = 'TAP3i.'||ltrim(rule,'TAP3.') where substr(rule,1,5) = 'TAP3.';
update ifw_rule set rule = 'TAP3i.'||ltrim(rule,'TAP3.') where substr(rule,1,5) = 'TAP3.';
update ifw_rulesetlist set rule = 'TAP3i.'||ltrim(rule,'TAP3.') where ruleset = 'TAP3_VAL';
update ifw_rulesetlist set ruleset = 'TAP3in_'||ltrim(ruleset,'TAP3_') where ruleset = 'TAP3_VAL';
update ifw_ruleset set ruleset = 'TAP3in_'||ltrim(ruleset,'TAP3_') where ruleset = 'TAP3_VAL';
commit;
quit;

