--==============================================================================
--
--          Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                            All rights reserved.
--               This material is the confidential property of
--       Portal Software Germany GmbH or its subsidiaries or licensors
--    and may be used, reproduced, stored or transmitted only in accordance
--            with a valid Portal license or sublicense agreement.
--
--------------------------------------------------------------------------------
-- Block: iScript
--------------------------------------------------------------------------------
-- Module Description:
--     Deleting rules from Integrate database
--    
--   
--
-- Open Points:
--   <open points>
--
-- Review Status:
--   in-work
--
--------------------------------------------------------------------------------
-- Responsible: Robert Bohdan Frydrych
--
-- $RCSfile: TAP3_VAL_del.sql,v $
-- $Revision: 1.1 $
-- $Author: pin01 $
-- $Date: 2005/06/24 10:48:53 $
--------------------------------------------------------------------------------
-- $Id: TAP3_VAL_del.sql,v 1.1 2005/06/24 10:48:53 pin01 Exp $
-- $Log: TAP3_VAL_del.sql,v $
-- Revision 1.1  2005/06/24 10:48:53  pin01
-- *** empty log message ***
--
--==============================================================================

delete from ifw_ruleitem;
delete from ifw_rulesetlist; 
delete from ifw_rule; 
delete from ifw_ruleset; 
commit;
quit
