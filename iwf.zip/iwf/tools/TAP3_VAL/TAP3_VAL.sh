#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#   Inserting and deleting Integrate rules
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Portal Software
#
#  $RCSfile: TAP3_VAL.sh,v $
#  $Revision: 1.2 $
#  $Author: pin27 $
#  $Date: 2006/01/04 17:21:10 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: TAP3_VAL.sh,v 1.2 2006/01/04 17:21:10 pin27 Exp $
#  $Log: TAP3_VAL.sh,v $
#  Revision 1.2  2006/01/04 17:21:10  pin27
#  MantisID: 1407
#  Committed by waldek
#  removed option for importing grants as well
#
#  Revision 1.1  2005/06/24 10:48:53  pin01
#  *** empty log message ***
#
# ==============================================================================

if [ $# -ne 4 ]
then
  echo "USAGE: $0 [-i|-d] USER PASSWORD DBALIAS"
  exit 2
fi

if [ "$1" = "-d" ]
then
  sqlplus $2/$3@$4 @TAP3_VAL_del.sql
elif [ "$1" = "-i" ]
then
  imp $2/$3@$4 fromuser=integrate touser=$2 ignore=y constraints=n file=TAP3_VAL.dmp grants=n
else
  echo "USAGE: $0 [-i|-d] USER PASSWORD DBALIAS"
  exit 2
fi

