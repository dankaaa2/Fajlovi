 /* Copyright (c) 1985, 1989, 1993, 1994, 2002
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#if 0
static char sccsid[] = "@(#)main.c	8.6 (Berkeley) 10/9/94";
#endif

/*
 * FTP User Program -- Command Interface.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/*#include <sys/ioctl.h>*/
#include <sys/types.h>
#include <sys/socket.h>

#include <arpa/ftp.h>

#include <ctype.h>
#include <err.h>
#include <errno.h>
#include <netdb.h>
/*#include <pwd.h>*/
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
/*#include <getopt.h>*/


/* Define macro to nothing so declarations in ftp_var.h become definitions. */
#define FTP_EXTERN
#include "ftp_var.h"
#include "pinlog.h"
#include "pin_conf.h"

/* basename (argv[0]).  NetBSD, linux, & gnu libc all define it.  */
extern char __progname[256];

#define DEFAULT_PROMPT "ftp> "
static char *prompt = 0;

extern char tmpfilename[512];

extern int code_success;
extern void write_audit_file(int , char *, app_connect_to_ftp );
int rename_file(char *filename, char *, app_connect_to_ftp connect_details);
int rename_file_old(char *filename, app_connect_to_ftp connect_details);
int command_connect(char *arg[], app_connect_to_ftp connect_details);
void check_connection(int ret_code,char **arg, app_connect_to_ftp connect_details);
void retry_again(char *arg[],app_connect_to_ftp cnt_details);


struct node{
	char name[100];
	struct node * next;
};
struct node * start = NULL;


/*********************************************************************************************
* Run shell command and capture the output in a array
* return value : nil
*********************************************************************************************/
void usepipe(char * cmd, char *buf)
{
             FILE *ptr;

             if ((ptr = popen(cmd, "r")) != NULL)
                        if (fgets(buf, BUFSIZ, ptr) != NULL)
                        {
                                buf[strlen(buf)-1]='\0';
                        }
                     (void) pclose(ptr);
}



/*********************************************************************************************
* Extract the parent directory for a file from its absolute path
* return value : 0 if '/' is found, othewise 1 
*********************************************************************************************/
int extractfilepath(char * filename, char * * extracted_file_path)
{
    #ifdef DEBUG
                printf("\nhello3\n");
    #endif

    char * position = strrchr(filename,'/');

    if (!position)
        return 1;

    #ifdef DEBUG
                printf("\nhello4\n");
        #endif


    int linecount = 0;

    while((filename+linecount)< position)
    {
                if(! linecount)
                {
                        #ifdef DEBUG
                                printf("\nhello5\n");
                        #endif

                        * extracted_file_path = (char *) malloc(1);
                }
                else
                {
            #ifdef DEBUG
                                printf("\nhello6\n");
                        #endif

                        * extracted_file_path = (char *) realloc(* extracted_file_path,linecount+1);
                }
            (* extracted_file_path)[linecount] = filename[linecount];
            linecount++;
        }

        #ifdef DEBUG
                printf("\nhello7\n");
    #endif
 if( linecount)
        {
                        #ifdef DEBUG
                                printf("\nhello8\n");
            #endif

                        * extracted_file_path = (char *) realloc(* extracted_file_path,linecount+1);

            (* extracted_file_path)[linecount]='\0';
        }
    else                    //if the file is at the root directory
        {
                        #ifdef DEBUG
                                printf("\nhello9\n");
            #endif

                        * extracted_file_path = (char *) malloc(2);

            (* extracted_file_path)[0]='/';
            (* extracted_file_path)[1]='\0';
    }

    #ifdef DEBUG
                printf("\nhello10\n");
        #endif
	
    return 0;
}


/*********************************************************************************************
* Check whether directory exists and is writable
* return value : 1 on success 2 or 3 on failure 
*********************************************************************************************/
int checkDirPerm(char * directory)
{
        char buf[BUFSIZ];
        memset(buf,BUFSIZ,0);
        char framecommand[30];

	sprintf(framecommand,"ls -ld %s;RC=$?; if [ $RC -ne 0 ] \n then \n echo DIRECTORY DOES NOT EXIST\n fi",directory);

        usepipe(framecommand,buf);


        if(strstr(buf,"DIRECTORY DOES NOT EXIST"))
        {
    		return 2;
        }

        if(buf[2]!='w')
        {
    		return 3;
        }
	return 1;


}

/*********************************************************************************************
* Remove the ':' from the string coming from ls -lrt so as to get the hour and minute
* return value : nil 
*********************************************************************************************/
void extract_hr_min(char * hrmin)
{
        if(strstr(hrmin,":"))
        {
                hrmin[2]=hrmin[3];
                hrmin[3]=hrmin[4];
                hrmin[4]='\0';
        }
        else    //If the file hasnt been modified for the last six months
        {
                strcpy(hrmin,"0000");
                hrmin[4]='\0';
        }
}

/*********************************************************************************************
* Map the month which is coming from output of ls -lrt command into integer
* return value : nil 
*********************************************************************************************/
void mapmonth(int month, char * month_i)
{
         if(!strcmp(month,"Jan"))
                        {
                                strcpy(month_i,"01");
                        }
                        else if(!strcmp(month,"Feb"))
                        {
                                strcpy(month_i,"02");
                        }
                        else if(!strcmp(month,"Mar"))
                        {
                                strcpy(month_i,"03");
                        }
                        else if(!strcmp(month,"Apr"))
                        {
                                strcpy(month_i,"04");
                        }
                        else if(!strcmp(month,"May"))
                        {
                                strcpy(month_i,"05");
                        }
                        else if(!strcmp(month,"Jun"))
                        {
                                strcpy(month_i,"06");
                        }
                        else if(!strcmp(month,"Jul"))
                        {
                                strcpy(month_i,"07");
                        }
                        else if(!strcmp(month,"Aug"))
                        {
                                strcpy(month_i,"08");
                        }
                        else if(!strcmp(month,"Sep"))
                        {
                                strcpy(month_i,"09");
                        }
                        else if(!strcmp(month,"Oct"))
                        {
                                strcpy(month_i,"10");
                        }
                        else if(!strcmp(month,"Nov"))
                        {
                                strcpy(month_i,"11");
                        }
                        else if(!strcmp(month,"Dec"))
                        {
                                strcpy(month_i,"12");
                        }
                        else
                        {
                                printf("\nError while mapping the month\n");
				                        pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
								"Error while mapping the month\n");
								exit(1);
                        }

}


/*********************************************************************************************
* Get the year from local server  
* return value : year value 
*********************************************************************************************/
int getYear(int month)
{
        char            timestamp[20];
        char            timestamp_month[20];
        char            timestamp_year[20];
        time_t          result;

        result = time(NULL);
        cftime(timestamp_month,"%m", &result);
        cftime(timestamp_year,"%Y", &result);

        int int_month= atoi(timestamp_month);
        int int_year= atoi(timestamp_year);

	
        if(month>int_month)
        {
		//year changed while the file was under transfer
                return(--int_year);
        }
        else
        {
                return int_year;
        }


}

char temporaryfilename[600];
int
ftp_main (app_connect_to_ftp *connect_details, char *prog_name)
{
	int ch, top,retry_cnt,ret_fun;
	int return_cmd;

	FILE *  fd1 = 0;

	char rm_file[512];
	
	memset(rm_file, 0, sizeof(rm_file));
	memset(tmpfilename, 0, sizeof(tmpfilename));
	sprintf(temporaryfilename,"%s",connect_details->tmp_file_path);
	
	#ifdef DEBUG
        printf("\ntmp_file_name***=%s***\n",connect_details->tmp_file_name);
    #endif

	sprintf(tmpfilename,"%s%s%s",temporaryfilename,"/",connect_details->tmp_file_name);

	#ifdef DEBUG
	printf("\ntmpfilename***=%s***\n",tmpfilename);
	#endif


/*
	fd = open("LOCKFILE",O_RDWR|O_CREAT,0640);

	if (fd<0){
                printf("\nError opening file\n");
                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                                "Error opening LOCKFILE");
                 exit(1);
        }
        if (lockf(fd,F_TLOCK,0)<0){

                        printf("FTP is already running\n");
                        pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                         "%s", "FTP is already running");
                 exit(0); 
        }
*/

	#ifndef HAVE___PROGNAME
		strcpy(__progname,prog_name);
	#endif

	#if HAVE_LIBREADLINE
		printf("LINE READ MODE \r\n");
	#else
		printf("NO LINE MODE \r\n");
	#endif
	doglob = 1;
	interactive = 1;


	fromatty = isatty (fileno (stdin));
	if (fromatty)
	{
		verbose++;
		if (! prompt)
			prompt = DEFAULT_PROMPT;
	}
	verbose = 1; //Added on 16th Nov 2005

	cpend = 0;	/* no pending replies */
	proxy = 0;	/* proxy not active */
	passivemode = 0; /* passive mode not active */
	crflag = 1;	/* strip c.r. on ascii gets */
	sendport = -1;	/* not using ports */
	/*
	* Set up the home directory in case we're globbing.
	*/

	if (setjmp (toplevel))
		exit (0);
	(void) signal(SIGINT, intr);
	(void) signal(SIGPIPE, lostpeer);

	retry_cnt = connect_details->retry_count;
	ret_fun = setpeer(connect_details);

	if(ret_fun == 7)
	{
		printf(" Incorrect login or password \n");
		return 1;
	} 

	while(ret_fun == 0 && retry_cnt != 0)
	{
		printf("Could not make connection to the Server. trying to re-connect....\n");
		retry_cnt = retry_cnt - 1;
		sleep(connect_details->sleep_time);
		connected = 0;
		ret_fun = setpeer(connect_details);
	}

	top = setjmp (toplevel) == 0;
	if (top)
	{
		(void) signal (SIGINT, intr);
		(void) signal (SIGPIPE, lostpeer);
	}

	if(ret_fun != 0)
		return_cmd = cmdscanner(top,connect_details);
	top = 1;


	if(return_cmd == 0)
	{
		return 1;
	}
}

void
intr (int sig)
{
	longjmp (toplevel, 1);
}

void
lostpeer (int sig)
{
	if (connected)
	{
		if (cout != NULL)
		{
			(void) shutdown (fileno (cout), 1+1);
			(void) fclose (cout);
			cout = NULL;
		}
		if (data >= 0)
		{
			(void) shutdown (data, 1+1);
			(void) close (data);
			data = -1;
		}
		connected = 0;
	}
	pswitch (1);
	if (connected)
	{
		if (cout != NULL)
		{
			(void) shutdown (fileno(cout), 1+1);
			(void) fclose (cout);
			cout = NULL;
		}
		connected = 0;
	}
	proxflag = 0;
	pswitch (0);
}


/*********************************************************************************************
* Check for temporary files on cnt_details.tmp_file_path and store the output in a linked list
* return value : non zero on sucess , zero on failure
*********************************************************************************************/

int check_temporary_file(app_connect_to_ftp cnt_details, char * tmp)
{
	struct node * ptr;
	#ifdef DEBUG
	printf("\nsizeof tmp =%d***\n",sizeof(tmp));
	#endif
	char command[200];
	sprintf(command,"%s%s%s","ls -1 ",cnt_details.tmp_file_path," > tempfile.tmp");

	#ifdef DEBUG
        printf("\nfirst command is =%s***\n",command);
	#endif

	int lscommand = system(command);

	if(lscommand)
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

	FILE * fp1=NULL;

	#ifdef DEBUG
	printf("\n123\n");
	#endif

	fp1 = fopen("tempfile.tmp","r");

	#ifdef DEBUG
	printf("\nsizeof tmp =%d***\n",sizeof(tmp));
	#endif

	//	fgets (tmp,200, fp1);

	int count = 0;

	while (fgets (tmp, 100,fp1) != NULL)
	{
		tmp[strlen(tmp)-1]='\0';
		#ifdef DEBUG
			printf("\nstrlen(tmp) =%d***\n",strlen(tmp));
			printf("\nBefore string compare tmp--------=%s***\n",tmp);
			printf("\nstrlen(cnt_details.tmp_file_name) =%d***\n",strlen(cnt_details.tmp_file_name));
			printf("\ncnt_details.tmp_file_name--------=%s***\n",cnt_details.tmp_file_name);
			
		#endif
		if(strcmp(tmp,cnt_details.tmp_file_name))
		{
			count++;

			if(count == 1)
			{
				ptr = (struct node *) malloc(sizeof(struct node));
				strcpy(ptr->name,tmp);

				#ifdef DEBUG
				printf("\n ptr->name=%s***\n",ptr->name);
				#endif

				start= ptr;
				ptr ->next = NULL;
			}
			else{
				ptr->next = (struct node *) malloc(sizeof(struct node));
				strcpy((ptr->next)->name,tmp);
				ptr=ptr->next;

				 #ifdef DEBUG
								printf("\n ptr->name=%s***\n",ptr->name);
								#endif


			}
		
		}
		#ifdef DEBUG
		else{
			printf("\nperfect match\n");
		}
		#endif
	}

	//	tmp[strlen(tmp)-1] = '\0';

	#ifdef DEBUG
	printf("In check_temporary_file after gets tmp =%s***\n",tmp);
	#endif

	fclose(fp1);

	sprintf(command,"%s","rm -f tempfile.tmp");
	#ifdef DEBUG
	printf("\nrm tempfile.tmp is =%s***\n",command);
	#endif

	int ret = system(command);

	if(ret)
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

	
	
	#ifdef DEBUG
	printf("In check_temporary_file tmp =%s***\n",tmp);
	printf("\nThe linked list contents are...\n");
	
	ptr = start;
	while(ptr)
	{
		printf("\n ptr->name =%s***\n",ptr->name);
		ptr = ptr -> next;
	}
	#endif

	if(count)
	{
			return 0;
	}
	else
	{
		#ifdef DEBUG
		printf("\ntmp is NULL\n");
		#endif

	return 1;
	}


}


/*********************************************************************************************
* For a linked list entry check for its presence in cnt_details.ftp_temp_file_path  
* return value : 0 if present , non zero on failure
*********************************************************************************************/

int check_temporary_dir(app_connect_to_ftp cnt_details, char * tmp)
{
	char command[200];
	#ifdef DEBUG
	printf("\nIn check_temporary_dir \n");	
	printf(" In check_temporary_dir tmp =%s***\n",tmp);
	#endif
	sprintf(command,"%s%s%s%s","ls ",cnt_details.ftp_temp_file_path,"/",tmp);

	#ifdef DEBUG
	 printf("\nin check_temporary_dir ls command is =%s***\n",command);
        printf("\nin check_temporary_dir tmp=%s***\n",tmp);
	#endif

	int status= system(command);

	#ifdef DEBUG
	printf("\nstatus=%d***\n",status);
	#endif
	return status;
}


/*
 * Command parser.
 */
int
cmdscanner (int top,app_connect_to_ftp cnt_details)
{
	struct cmd *c;
	int l,j;
	int i=0;
	int temp = 0;
	int oldintr;
	char filename[50];
	char tstamp[50];
	char logfile[256];
	char rm_file[512];
	char    auditfilename[50];
	FILE *fp2 = NULL;
	char * current_path = NULL;
	FILE  *fout = NULL;
	char	tmp[400];
	char	name[50];
	int	idx,ret_code;
	char *cmdarg[2]={0};
	char tempFile[600];
	char touchFile[610];
	char command[200];
	struct node * preptr;

	char hrmin[5];
	char day[5];
	char lineOfOutput[150];	
	char *r;
	char month[5];
	char date[15];
	char * outframe;
	char month_i[3];
	char * year_i;

	memset(rm_file, 0, sizeof(rm_file));
	cmdarg[0]=(char *)calloc(300,sizeof(char));
	cmdarg[1]=(char *)calloc(300,sizeof(char));

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                 "%s", "Entering into cmdscanner function");
	sprintf(rm_file,"%s %s","rm -f ",tmpfilename);

	if (!top)
		(void) putchar ('\n');

	#ifdef DEBUG
	printf("\nin cmdscanner size of tmp=%d***\n",sizeof(tmp));
	#endif


	/***            TRANSACTION SECURITY            ***/

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                 "%s", "Checking for left out files...");
	memset(tmp, 0, sizeof(tmp));
	if(!check_temporary_file(cnt_details,tmp))
	{
		#ifdef DEBUG
		printf("\nInside first if \n");
		int count = 0;
		printf("\ncount =%d***\n",count);
		#endif
	}
	
		struct node * ptr = start;
		int count = 0;


		while(ptr)
		{
		#ifdef DEBUG
		printf("\n!!!count =%d***\n",count);
		#endif

		//	if(!check_temporary_dir(cnt_details,tmp))

		if(strcmp(ptr->name,cnt_details.tmp_file_name))
		{
			#ifdef DEBUG
			printf("\nMATCH%s\n",ptr->name);
			#endif

			if(!check_temporary_dir(cnt_details,ptr->name))
			{
				#ifdef DEBUG
				printf("\nInside second if \n");
				#endif

				//**********************************
				//File is already downloaded but not processed, So delete the file from the server so as to prevent 				it from being downloaded again 

			        strcpy(cmdarg[0],"cd");
       			 	strcpy(cmdarg[1],cnt_details.ftp_remote_file_path);
			        ret_code = command_connect(cmdarg,cnt_details);
			        (void)check_connection(ret_code,cmdarg,cnt_details);


				strcpy(cmdarg[0],"del");
				strcpy(cmdarg[1],ptr->name);
		                c = getcmd(cmdarg[0]);

		               // pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
               		        // "File deleted is: %s ", cmdarg[1]);
		                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
               		         "The command is: %s %s", cmdarg[0],cmdarg[1]);

		                if(connected)
               		         (*c->c_handler) (2, cmdarg);

		                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
               		         "After delete command, connected=%d, code=%d:", connected,code);

		                if ((c->c_conn && !connected) )
               			{
					(void) retry_again(cmdarg,cnt_details);
                		}
				
				//**********************************

				//rename_file_old(ptr->name, cnt_details);
				int rename_ret = rename_file_old(ptr->name, cnt_details);

				sprintf(command,"%s%s%s%s","rm -f ",cnt_details.tmp_file_path,"/",ptr->name);

				#ifdef DEBUG
						printf("\nRemoving tmp file command is =%s***\n",command);
				#endif
				 pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
					 "%s%s", "Removing temporary file ",ptr->name);

				//(void)write_audit_file(226, ptr->name, cnt_details);    //get auditfilename form check_temporary_file

				if(! rename_ret)
				{
						(void)write_audit_file(226, ptr->name, cnt_details);
				}
				else
				{
						(void)write_audit_file(0, ptr->name, cnt_details);
						exit(1);
				}

                                int lscommand = system(command);
                                if(lscommand)
                                         pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

			}	
			else
			{
				sprintf(command,"%s%s%s%s","rm -f ",cnt_details.tmp_file_path,"/",ptr->name);

				#ifdef DEBUG
				printf("\nRemoving tmp file command is =%s***\n",command);
				#endif
				pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s%s", "Removing temporary file ",ptr->name);

				int lscommand = system(command);
				if(lscommand)
					 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

			}
		}
		preptr = ptr;
		ptr = ptr -> next;
		free(preptr);

		#ifdef DEBUG
		count++;
		#endif
		}
	
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                 "%s", "File check completed...");

	strcpy(cmdarg[0],"cd");
	strcpy(cmdarg[1],cnt_details.ftp_remote_file_path);
	ret_code = command_connect(cmdarg,cnt_details); 
	(void)check_connection(ret_code,cmdarg,cnt_details);

	memset(cmdarg[0],0,300);
	memset(cmdarg[1],0,300);
	
	strcpy(cmdarg[0],"lcd");
	strcpy(cmdarg[1],cnt_details.ftp_temp_file_path);


	ret_code = command_connect(cmdarg,cnt_details); 
	#ifdef DEBUG
	printf("IN CHECK FOR");
	#endif
	(void)check_connection(ret_code,cmdarg,cnt_details);

	memset(cmdarg[0],0,300);
	memset(cmdarg[1],0,300);

	strcpy(cmdarg[0],"ls");
	strcpy(cmdarg[1],"-lrt");

	//Romove the * from the pattern
	//cnt_details.ftp_file_pattern[strlen(cnt_details.ftp_file_pattern)-1]='\0';
	
	ret_code = command_connect(cmdarg,cnt_details); 
	(void)check_connection(ret_code,cmdarg,cnt_details);

	if (bell && c->c_bell)
		(void) putchar('\007');
  
	if (ret_code == 10){
		if ((fout =fopen(tmpfilename,"r"))==NULL){
				printf("Not able to open %s file \n",tmpfilename);
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
						"Unable to open %s file", tmpfilename);
		}
	 if (strcmp(cnt_details.mode,"BINARY")==0){
		   setbinary();
	 }
	 else {
		setascii();
	 }



	int linecount =0;

	while (fgets (lineOfOutput, sizeof(lineOfOutput),fout) != NULL){

		//If there is no file it will show a message like "chsLog*: No such file or directory"
		if(strstr(lineOfOutput,"*:"))
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
							"%s", "File or directory not found ..exiting");
			//system(rm_file);
			//    exit(-1);
			return 0;			//There are no files to be downloaded
		}


		lineOfOutput[strlen(lineOfOutput)-1]='\0';

		r= (char *) malloc(strlen(lineOfOutput)+1);
		strcpy(r,lineOfOutput);


		//The first line is not required	
		if(!linecount)
		{
				linecount++;
				continue;
		}


		//counter is used to keep track of the date field in the command output
		int counter = 0;

		while(r!= NULL && counter<=7){
			 if  (outframe = (char *) strtok_r (r, " ", &r))
			 {
					 //exit(1);
			 }

			switch(counter)
			{
					case 5:
							strcpy(month,outframe);
							break;
					case 6:
							strcpy(day,outframe);
							break;
					case 7:
							strcpy(hrmin,outframe);
							break;
			}
			counter++;
		}


		if(r)
		{
				//tmp will have the name of the file to be downloaded
				strcpy(tmp,r);

		}
		else
		{
				printf("Error encountered while reading the output of ls command\n");
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
								"Error encountered while reading the output of ls command\n");
				exit(1);
		}	

		mapmonth(month,month_i);


		if(strlen(day) == 1)
		{
				day[1]=day[0];
				day[0]='0';
		}



		int year = getYear(month);

		char abcd[10];
		year_i = lltostr(year,abcd);
		year_i[4]='\0';				//because lltostr doesnt append null


		extract_hr_min(hrmin);

		sprintf(date,"%s%s%s%s",year_i,month_i,day,hrmin);


		//Check whether pin_cdr_collector_ftp_download_file exists for each download
		int return_value = checkDirPerm(cnt_details.ftp_current_file_path);

		if(return_value == 2)
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"%s does not exist \n",cnt_details.ftp_current_file_path);
			exit(1);
		}
		else if ( return_value == 3)
		{
								pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			 "%s does not have write permission\n",cnt_details.ftp_current_file_path);
			 exit(1);
		}
			

			
		//Skip the files not matching with the pattern

		if(tmp != strstr(tmp,cnt_details.ftp_file_pattern))
                {
                        continue;
                }



		sprintf(line,"get %s",tmp);

		makeargv();
		c = getcmd (margv[0]);

		memset(cmdarg[0],0,300);
		memset(cmdarg[1],0,300);

		strcpy(cmdarg[0],margv[0]);
		strcpy(cmdarg[1],margv[1]);	

		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"The command is: %s %s", margv[0],margv[1]);

		if(strstr(cmdarg[1],"*:"))
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
					"%s", "File or directory not found ..exiting");
			//system(rm_file); 
			exit(-1);
		} 

		if(connected)
			(*c->c_handler) (2, cmdarg);



		if ((c->c_conn && !connected) || (code != 226))
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
					"%s : retrying", "Unable to connect  or get failed");
			/***calling function here ***/
			(void)retry_again(cmdarg,cnt_details);
		}
		
		
		tmp[sizeof(tmp)-1]='\0';


		sprintf(tempFile,"%s%s%s",temporaryfilename,"/",tmp);	


		sprintf(touchFile,"%s%s","touch ",tempFile);

		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
		"%s%s", "Creating temporary file ",tempFile);


		int lscommand = system(touchFile);
		if(lscommand)
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", touchFile);


		strcpy(cmdarg[0],"del");
		c = getcmd(cmdarg[0]);

		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"File deleted is: %s ", margv[1]);
//		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
//			"The command is: %s %s", margv[0],margv[1]);
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"The command is: %s %s", cmdarg[0],cmdarg[1]);

		if(connected)
			(*c->c_handler) (2, cmdarg);

		if ((c->c_conn && !connected) || (code != 250))
		{
			(void) retry_again(cmdarg,cnt_details);
		}

		sprintf(filename, "%s", margv[1]);


		int rename_ret = rename_file(filename, date, cnt_details);
		

		sprintf(touchFile,"%s%s","rm -f ",tempFile);
					pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			 "%s%s", "Removing temporary file ",touchFile);



		if (bell && c->c_bell)
			(void) putchar('\007');

		/****************************************************
		 *  Audit file 
		 **************************************************/
		sprintf(auditfilename, "%s", cmdarg[1]);



		//(void)write_audit_file(code_success, auditfilename, cnt_details);

		if(! rename_ret)
		{
			(void)write_audit_file(226, auditfilename, cnt_details);
		}
		else
		{
			(void)write_audit_file(0, auditfilename, cnt_details);
			exit(1);
		}

                lscommand = system(touchFile);
                if(lscommand)
                                 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", touchFile);

	} /* End of while */

	memset(tmp,0,sizeof(tmp));

	} /*end of if condition*/
		
	/* Commenting the following as per Piotr's request , mail dated 8th march 2006. The new requirement is this file should be deleted only in the begining
	if(tmpfilename != NULL)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"The Command is rm: %s", rm_file);
		int lscommand = system(rm_file);

		if(lscommand)
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", rm_file);
	}
	*/

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning cmdscanner function");
	free(cmdarg[0]);
	free(cmdarg[1]);
	fclose(fp2);
	(void) signal (SIGINT, intr);
	(void) signal (SIGPIPE, lostpeer);
}

struct cmd *
getcmd (char *name)
{
	char *p, *q;
	struct cmd *c, *found;
	int nmatches, longest;

	longest = 0;
	nmatches = 0;
	found = 0;

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
		"%s", "Entering into getcmd function");
	for (c = cmdtab; (p = c->c_name); c++)
	{
		for (q = name; *q == *p++; q++)
			if (*q == 0)		/* exact match? */
				return (c);
		if (!*q)
		{			/* the name was a prefix */
			if (q - name > longest)
			{
				longest = q - name;
				nmatches = 1;
				found = c;
			}
			else if (q - name == longest)
				nmatches++;
		}
	}

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from getcmd function");
	if (nmatches > 1)
		return ((struct cmd *)-1);
	return (found);
}

/*
 * Slice a string up into argc/argv.
 */

int slrflag;

void
makeargv ()
{
	char **argp;

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Entering into  makeargv function");
	margc = 0;
	argp = margv;
	stringbase = line;		/* scan from first of buffer */
	argbase = argbuf;		/* store from first of buffer */
	slrflag = 0;
	while ((*argp++ = slurpstring ()))
		margc++;
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from makeargv function");
}

/*
 * Parse string into argbuf;
 * implemented with FSM to
 * handle quoting and strings
 */
char *
slurpstring ()
{
	int got_one = 0;
	char *sb = stringbase;
	char *ap = argbase;
	char *tmp = argbase;		/* will return this if token found */

	if (*sb == '!' || *sb == '$') {	/* recognize ! as a token for shell */
		switch (slrflag)	/* and $ as token for macro invoke */
		{
			case 0:
				slrflag++;
				stringbase++;
				return ((*sb == '!') ? "!" : "$");
				/* NOTREACHED */
			case 1:
				slrflag++;
				altarg = stringbase;
				break;
  
			default:
				break;
		}
	}

	S0:
		switch (*sb)
		{
			case '\0':
				goto OUT;
			case ' ':
			case '\t':
				sb++; goto S0;

			default:
				switch (slrflag)
				{
					case 0:
						slrflag++;
						break;
					case 1:
						slrflag++;
						altarg = sb;
						break;
					default:
						break;
				}
				goto S1;
		}

	S1:
		switch (*sb)
		{
			case ' ':
			case '\t':
			case '\0':
				goto OUT;	/* end of token */
			case '\\':
				sb++; goto S2;	/* slurp next character */
			case '"':
				sb++; goto S3;	/* slurp quoted string */
			default:
				*ap++ = *sb++;	/* add character to token */
				got_one = 1;
				goto S1;
		}

	S2:
		switch (*sb)
		{
			case '\0':
				goto OUT;
			default:
				*ap++ = *sb++;
				got_one = 1;
				goto S1;
		}

	S3:
		switch (*sb)
		{
			case '\0':
				goto OUT; 
			case '"':
				sb++; goto S1;
			default:
				*ap++ = *sb++;
				got_one = 1;
				goto S3;
		}

	OUT:
		if (got_one)
			*ap++ = '\0';
		argbase = ap;			/* update storage pointer */
		stringbase = sb;		/* update scan pointer */
		
		if (got_one)
			return (tmp);
		switch (slrflag)
		{
			case 0:
				slrflag++;
				break;
			case 1:
				slrflag++;
				altarg = (char *) 0;
				break;
			default:
				break;
		}
	return ((char *) 0);
}


int
rename_file_old(char *filename, app_connect_to_ftp connect_details){
	char            file_name[1024];
	time_t          result;
	char            timestamp[20];
	char            mv_file[1024];
	char            orgfile[1024];
	int32		err;

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "entering into rename_file function");
	memset(file_name, 0, sizeof(file_name));
	memset(orgfile, 0, sizeof(orgfile));
	memset(mv_file, 0, sizeof(mv_file));


	if(!strcmp(connect_details.suffix_timestamp, "Enable"))
       {
	
	 memset(timestamp, 0, sizeof(timestamp));
        result = time(NULL);	

	  cftime(timestamp,"%Y%m%d%H%M%S", &result);
        sprintf(file_name, "%s%s%s%s%s", connect_details.ftp_current_file_path, "/", filename,"_", timestamp);
	#ifdef DEBUG
	printf("\nfile_name if timestamp is enabled=%s***\n",file_name);
	#endif
       }
	else{

	sprintf(file_name, "%s%s%s", connect_details.ftp_current_file_path, "/", filename);

	#ifdef DEBUG
        printf("\nfile_name if timestamp is not enabled=%s***\n",file_name);
        #endif
	}


	
	#ifdef DEBUG
	printf("\nconnect_details.suffix=%s***\n",connect_details.suffix);
	printf("\nold file name=%s***\n",filename);
	#endif

	if( connect_details.suffix[0]!='\0')
	{
		#ifdef DEBUG
		printf("\nIn rename function file_name=%s***\n",file_name);
		#endif
		strcat(file_name, connect_details.suffix);
		#ifdef DEBUG
		printf("\nIn rename function file_name=%s***\n",file_name);
		#endif
	}

	#ifdef DEBUG
	printf("\nFinally file_name=%s***\n",file_name);
	#endif

	sprintf(orgfile, "%s%s%s", connect_details.ftp_temp_file_path, "/", filename);
	#ifdef DEBUG
	printf("orgfile=%s***\n",orgfile);
	#endif
	sprintf(mv_file, "%s %s %s", "mv ", orgfile, file_name);
	#ifdef DEBUG
	printf("mv_file=%s***\n",mv_file);
	#endif
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"The Command is: %s", mv_file);
	int ret_move = system(mv_file);
	if(ret_move)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "Move command failed with exit code %d\n",ret_move);

		return 1;
	}
	else
	{
		return 0;
	}
			
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from rename_file function");

}


int
rename_file(char *filename, char * timestamp, app_connect_to_ftp connect_details){
        char            file_name[1024];
        time_t          result;
        char            mv_file[1024];
        char            orgfile[1024];
        int32           err;

        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "%s", "entering into rename_file function");
        memset(file_name, 0, sizeof(file_name));
        memset(orgfile, 0, sizeof(orgfile));
        memset(mv_file, 0, sizeof(mv_file));


        if(!strcmp(connect_details.suffix_timestamp, "Enable"))
       {

        sprintf(file_name, "%s%s%s%s%s", connect_details.ftp_current_file_path, "/", filename,"_", timestamp);
       }
        else{

        sprintf(file_name, "%s%s%s", connect_details.ftp_current_file_path, "/", filename);

        }


		if( connect_details.suffix[0]!='\0')
		{
				strcat(file_name, connect_details.suffix);
		}


        sprintf(orgfile, "%s%s%s", connect_details.ftp_temp_file_path, "/", filename);
        sprintf(mv_file, "%s %s %s", "mv ", orgfile, file_name);
        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "The Command is: %s", mv_file);

        int ret_move = system(mv_file);
        if(ret_move)
        {
                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "Move command failed with exit code %d\n",ret_move);
		return 1;
         //       exit(1);
        }
        else
        {
                return 0;
        }
        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "%s", "Returning from rename_file function");

}

int
command_connect(char *arg[],app_connect_to_ftp cnt_details)
{
	struct cmd *c;

	c = getcmd (arg[0]);

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Entering into command_connect function");
	if (c == (struct cmd *) -1)
	{
		printf ("?Ambiguous command\n");
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from command_connect function");
		return(2);
	}

	if (c == 0)
	{
		printf ("?Invalid command\n");
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from command_connect function");
		return(2);
	}

	if (c->c_conn && !connected)
	{
		printf ("Not connected.\n");
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from command_connect function");
		return(5);
	}
         
	(*c->c_handler) (2, arg);

	if(code == 550 || code == -1)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Please check the Path of the Remote directory or local working directory");
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from command_connect function");
		return(2);
	}

	if (strcmp(c->c_name,"ls")==0)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from command_connect function");
		return(10);
	}
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from command_connect function");

	return 0;
}

void
check_connection(int ret_code,char **arg,app_connect_to_ftp cnt_details)
{
	int i;

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Entering into check_connection function");
	if(ret_code == 5)
	{
		for(i = 0 ; i < cnt_details.retry_count ; i++)
		{
			setpeer(cnt_details);
			if(connected)
			{
				i = cnt_details.retry_count + 2;
				ret_code = command_connect(arg,cnt_details);
			}
		}

		if(i == cnt_details.retry_count)
		{
			printf(" Unable to connect to the server ..exiting \n");
			exit(1);
		}
	}
	else if(ret_code == 2)
	{
		exit(1);
	}
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from check_connection function");
}

void
retry_again(char  *cmdarg_local[],app_connect_to_ftp cnt_details)
{
	struct cmd *c;
	int i,ret_code;
	char tmp[50];
	char tmp1[50];
	char *lr_arg[2];
   
	lr_arg[0] = (char *)calloc(300,sizeof(char));
	lr_arg[1] = (char *)calloc(300,sizeof(char));
 
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Entering into retry_again function");

	memset(tmp, 0, sizeof(tmp));
	memset(tmp1, 0, sizeof(tmp1));

	strcpy(tmp,cmdarg_local[0]); 
	strcpy(tmp1,cmdarg_local[1]); 

//	sleep(cnt_details.sleep_time);

	for(i=0; i < cnt_details.retry_count;i++)
	{
		if(!connected)
		{
//			sleep(cnt_details.sleep_time);
			setpeer(cnt_details);
			strcpy(lr_arg[0],"cd");
			strcpy(lr_arg[1],cnt_details.ftp_remote_file_path);
			ret_code = command_connect(lr_arg,cnt_details);
			(void)check_connection(ret_code,lr_arg,cnt_details);

			memset(lr_arg[0],0,300);
			memset(lr_arg[1],0,300);

			strcpy(lr_arg[0],"lcd");
			/*START: Sreenivasa*/
			if(!strcmp(cnt_details.suffix_timestamp, "Enable")){
      			strcpy(lr_arg[1],cnt_details.ftp_temp_file_path);
			}/*END: Sreenivasa*/
			else
			{
				strcpy(lr_arg[1],cnt_details.ftp_current_file_path);
			}

			ret_code = command_connect(lr_arg,cnt_details);
			(void)check_connection(ret_code,lr_arg,cnt_details);
                                  
		}

		if(connected)
		{
			c = getcmd (tmp);

			memset(lr_arg[0],0,300);
			memset(lr_arg[1],0,300);

			strcpy(lr_arg[0],tmp);
			strcpy(lr_arg[1],tmp1);

			(*c->c_handler) (2, lr_arg);

			if(code != 226 && code != 250)
			{
				pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
						"Getting files failed..retrying for %d times", cnt_details.retry_count);
			}
			else
			{ 
				i = cnt_details.retry_count + 2;
			}
		}
	}

	if(i == cnt_details.retry_count)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
				"%s", "Unable to connect..exiting");
		exit(1);
	}
	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Returning from retry_again function");

	free(lr_arg[0]);
	free(lr_arg[1]);
}
