#include "pin_conf.h"
/* For PIN Functions */
#include "pinlog.h"
#include "pin_errs.h"
#include "pcm.h"

void
get_pin_conf_str(
	char	*keyword,
	char	*valp,
	pin_errbuf_t    *ebufp)
{
	int32	err = PIN_ERR_NONE;
	char		*charp = NULL;
	
	/***********************************************************
	* Clear the error buffer.
	***********************************************************/

	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERRBUF_CLEAR(ebufp);

	pin_conf("pin_cdr_collector", keyword,
		PIN_FLDT_STR, (caddr_t *)&charp, &err);

	if (err == PIN_ERR_NONE) {
		if (charp != (char *)NULL) {
			strcpy(valp,charp);
			free(charp);
		}
	}
	else {
		ebufp->pin_err = err;
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"%s is %d", keyword, *valp);
                return;
        }
	return;
}

void
get_pin_conf_int(
	char		*keyword,
	int32		*valp,
	pin_errbuf_t    *ebufp)
{

	int32	err = PIN_ERR_NONE;
	int32	*intp = NULL;
	
	/***********************************************************
	* Clear the error buffer.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERRBUF_CLEAR(ebufp);

	pin_conf("pin_cdr_collector", keyword,
		PIN_FLDT_INT, (caddr_t *)&intp, &err);

	if (err == PIN_ERR_NONE) {
		if (intp != (int *)NULL) {
			*valp = *intp;
			free(intp);
		}
	}
	else {
		ebufp->pin_err = err;
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"%s is %d", keyword, *valp);
		return;
     }
	return;
}

void
sample_read_pin_conf(app_connect_to_ftp *connect_detailsp,
	pin_errbuf_t	*ebufp)
{
	/***********************************************************
	* Clear the error buffer.
	**********************************************************/
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Get the loglevel 
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_loglevel",
		&connect_detailsp->log_level, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
        	PIN_ERR_SET_LEVEL(PIN_ERR_LEVEL_ERROR);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_loglevel from pin.conf file", ebufp);
		return;
	}
	else{
		switch (connect_detailsp->log_level) 
		{
			case PIN_ERR_LEVEL_NONE:
			case PIN_ERR_LEVEL_ERROR:
			case PIN_ERR_LEVEL_WARNING:
			case PIN_ERR_LEVEL_DEBUG:
				PIN_ERR_SET_LEVEL(connect_detailsp->log_level);
				break;
			default:
				PIN_ERR_SET_LEVEL(PIN_ERR_LEVEL_ERROR);
		}
	}

	/***********************************************************
	* Get the logfile path 
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_logfile",
		connect_detailsp->logfile_path, ebufp); 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_logfile from pin.conf file", ebufp);
		return;
	}
	else{


		char * extracted_file_path;

		(void ) extractfilepath(connect_detailsp->logfile_path, & extracted_file_path);
	
		int return_value = checkDirPerm(extracted_file_path);

		if(return_value == 2)
		{
			                        pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",extracted_file_path);
			exit(1);
		}
		else if ( return_value == 3)
		{
			                        pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",extracted_file_path);
			exit(1);
		}
		else
		{
			PIN_ERR_SET_LOGFILE(connect_detailsp->logfile_path);

	                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_logfile is: %s\n",connect_detailsp->logfile_path);
		}





		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_loglevel is: %d\n",connect_detailsp->log_level);

	}

	/***********************************************************
	* Get the IP address
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_name",
		connect_detailsp->host_name, ebufp); 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_name from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_name is: %s\n",connect_detailsp->host_name);
	}


	 /***********************************************************
	* Get the Port number
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_port",
		&connect_detailsp->port, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
        	PIN_ERR_SET_LEVEL(PIN_ERR_LEVEL_ERROR);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_port from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_port is: %d\n",connect_detailsp->port);
	}

	/***********************************************************
	* Get the Username
	***********************************************************/

	get_pin_conf_str("pin_cdr_collector_username",
		connect_detailsp->username, ebufp); 

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_username from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_username is: %s\n",connect_detailsp->username);
	}

	/***********************************************************
	* Get the password
	***********************************************************/
	 get_pin_conf_str("pin_cdr_collector_password",
		connect_detailsp->passwd, ebufp); 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_password from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_password is: %s\n",connect_detailsp->passwd);
	}

	/***********************************************************
	* Get the FTP Remote Server file
	* 
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftp_command_file",
		connect_detailsp->ftp_remote_file_path, ebufp); 

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftp_command_file from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_ftp_command_file is: %s\n",
			connect_detailsp->ftp_remote_file_path);
	}

	/***********************************************************
	* Get the FTP local Server file path
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftp_download_file",
		connect_detailsp->ftp_current_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftp_download_file from pin.conf file",
			ebufp);
		return;
	}
	else{
//		char * extracted_file_path;

//                (void ) extractfilepath(connect_detailsp->ftp_current_file_path, extracted_file_path);

                int return_value = checkDirPerm(connect_detailsp->ftp_current_file_path);

                if(return_value == 2)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",connect_detailsp->ftp_current_file_path);
			exit(1);
                }
                else if ( return_value == 3)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",connect_detailsp->ftp_current_file_path);
			exit(1);
                }
                else
                {
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_ftp_download_file is: %s\n",
			connect_detailsp->ftp_current_file_path);
		}
	}

	/***********************************************************
	* Get the FTP file patterns
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_file_pattern",
		connect_detailsp->ftp_file_pattern, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_file_pattern from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
		"pin_cdr_collector_file_pattern is: %s\n",
		connect_detailsp->ftp_file_pattern);
	}


	/***********************************************************
	* Get the mode
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_mode",
		connect_detailsp->mode, ebufp); 
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_mode from pin.conf file", \
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_mode is: %s\n",connect_detailsp->mode);
	
		if (!((strcmp(connect_detailsp->mode,"BINARY") == 0) 
			|| (strcmp(connect_detailsp->mode,"ASCII") ==0)))	{
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
				"Invalid entry for pin_cdr_collector_mode in pin.conf file. It should be either ASCII / BINARY.");
			return;
		}
	}
	
	/***********************************************************
	* Get the transfer
	***********************************************************/
	/*
	get_pin_conf_str("pin_cdr_collector_transfer",
	connect_detailsp->transfer, ebufp); 
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_transfer from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_transfer is: %s\n",connect_detailsp->transfer);

		if (!((strcmp(connect_detailsp->transfer,"FTP") != 0) ||
			(strcmp(connect_detailsp->transfer,"FTAM") !=0))){
	
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
				"Invalid entry for pin_cdr_collector_transfer in pin.conf file. It should be either FTP / FTAM.");

			return;
		}

	}
	*/

	strcpy(connect_detailsp->transfer,"FTP");
        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_transfer is: %s\n",connect_detailsp->transfer);
	

	/***********************************************************
	* Get the FTP local Server temp file path
	*
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftp_temp_file",
		connect_detailsp->ftp_temp_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftp_temp_file from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_ftp_temp_file is: %s\n",
		connect_detailsp->ftp_temp_file_path);
	}

	/***********************************************************
	* Get the FTP local Server audit file path
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftp_audit_file",
		connect_detailsp->ftp_audit_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftp_audit_file from pin.conf file",
			ebufp);
		return;
	}
	else{

                int return_value = checkDirPerm(connect_detailsp->ftp_audit_file_path);

                if(return_value == 2)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",connect_detailsp->ftp_audit_file_path);
                        exit(1);
                }
                else if ( return_value == 3)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",connect_detailsp->ftp_audit_file_path);
                        exit(1);
                }
                else
                {
                        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftp_audit_file is: %s\n",
                        connect_detailsp->ftp_audit_file_path);
                }
	}


	/***********************************************************
	* Get the Audit filename
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_audit_file",
		connect_detailsp->audit_file_name, ebufp);
			
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_audit_file from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_audit_file is: %s\n",
			connect_detailsp->audit_file_name);
	}


	/***********************************************************
	* Get the Audit filename Suffix
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_audit_file_suffix",
		connect_detailsp->audit_file_name_suffix, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_audit_file_suffix from pin.conf file",
		ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_audit_file is: %s\n",
			connect_detailsp->audit_file_name_suffix);
	}


	/***********************************************************
	* Get the Retry Count
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_retry_count",
		&connect_detailsp->retry_count, ebufp);
	 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_retry_count from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_retry_count is: %d\n",connect_detailsp->retry_count);
	}


	/***********************************************************
	* Get the Retry Count
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_sleep_time",
		&connect_detailsp->sleep_time, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_sleep_time from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_sleep_time is: %d\n",connect_detailsp->sleep_time);
	}
	
        /***********************************************************
        * Get the Temporary file path 
        *
        ***********************************************************/
        get_pin_conf_str("pin_cdr_collector_ftp_tmp_file",
                connect_detailsp->tmp_file_path, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_ftp_tmp_file from pin.conf file",
                        ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftp_tmp_file is: %s\n",
                        connect_detailsp->tmp_file_path);
        }
	

	 /***********************************************************
        * Get the Temporary file name
        *
        ***********************************************************/
        get_pin_conf_str("pin_cdr_collector_ftp_tmp_file_name",
                connect_detailsp->tmp_file_name, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_ftp_tmp_file_name from pin.conf file",
                        ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftp_tmp_file_name is: %s\n",
                        connect_detailsp->tmp_file_name);
        }


        /***********************************************************
        * Get the timestamp paramter
        ***********************************************************/

        get_pin_conf_str("pin_cdr_collector_suffix_timestamp",
                connect_detailsp->suffix_timestamp, ebufp);
        
	if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_suffix_timestamp from pin.conf file", ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_suffix_timestamp is: %s\n",connect_detailsp->suffix_timestamp);
        }


        /***********************************************************
        * Get the mms suffix
        ***********************************************************/

        get_pin_conf_str("pin_cdr_collector_suffix",
                connect_detailsp->suffix, ebufp);


        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_suffix from pin.conf file", ebufp);
		if(ebufp->pin_err == PIN_ERR_NOT_FOUND)
		{
			connect_detailsp->suffix [0]= '\0';
			PIN_ERRBUF_CLEAR(ebufp);
			
		}
		else
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_suffix is: %s\n",connect_detailsp->suffix);
        }


	
	return;
}
