
/* For PIN Functions */
#include "pinlog.h"
#include "pin_errs.h"
#include "pcm.h"
#include "pin_conf.h"

#include<stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include<time.h>

char * 
	local_time()
{
  char *lcl_time= NULL;
  time_t tm=time(0);
  lcl_time = asctime(localtime(&tm));
  return lcl_time;
}

void main(
	int argc,
	char **argv)
{
	pin_errbuf_t		ebufp;

	int							top = 0;
	app_connect_to_ftp connect_details;
	pid_t	  				curr_process_id;

	FILE *  fd = 0;
	char str[150];
	char rm_file[150];
	char command[150];
	char lockfile[150];

	// Need to find out the present working directory so as to create LOCKFILE on that.

        sprintf(command,"%s","pwd");
        usepipe(command,str);

        sprintf(lockfile,"%s/%s",str,"LOCKFILE");
        sprintf(rm_file,"rm -f %s",lockfile);


	fd = open(lockfile,O_RDWR|O_CREAT,0640);

	if (fd<0){
			printf("\nError opening LOCKFILE\n");
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
					"Error opening LOCKFILE");
			exit(1); /* can not open */
	}

	if (lockf(fd,F_TLOCK,0)<0){
		printf("FTP is already running\n");
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
		"%s", "FTP is already running");
		exit(0); /* can not lock */
	}

	/* only first instance continues */


	memset(&connect_details, 0, sizeof(connect_details));


	curr_process_id = getpid();

	fprintf(stdout, "%s started with process_id %d at %s\n",
	argv[0], curr_process_id,local_time());

	
	//Store the process id in the LOCKFILE
	//sprintf(str,"%d\n",curr_process_id);
	//write(fd,str,strlen(str)); /* record pid to lockfile */
	//close(fd);

	sample_read_pin_conf(&connect_details, &ebufp); 


	if (PIN_ERR_IS_ERR(&ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the pin.conf file",
			&ebufp);
		return;
	}

	fprintf(stdout,"Calling FTP subroutines.\n");

	ftp_main(&connect_details,argv[0]);

	sprintf(command,"rm -f %s",rm_file);


	
	int ret = system(command);	

	if(ret)
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"command failed: %s", command);


	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
							"*** %s STOPPED ***",argv[0]);

}
