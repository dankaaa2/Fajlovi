#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Start HUR files creation
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Robert Frydrych
#
#  $RCSfile: tap_report.sh,v $
#  $Revision: 1.1 $
#  $Author: pin09 $
#  $Date: 2006/03/10 15:43:07 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: tap_report.sh,v 1.1 2006/03/10 15:43:07 pin09 Exp $
#  $Log: tap_report.sh,v $
#  Revision 1.1  2006/03/10 15:43:07  pin09
#  MantisID: 1759
#  Committed by RBF
#  Initial release
#
# ==============================================================================

exec 2>&1

DATE_FORMAT="YYYYMMDDHH24MISS"

TIMESTAMP=`date +%Y%m%d%H%M%S`

#script name and directory
EXEC=${0}
PARAMS=${*}
PRG=${EXEC##*/}
BASE=${PRG%.*}
ORIG=${PWD}
DIR=${EXEC%/*}
if [[ "${DIR}" = "${EXEC}" || "${DIR}" = "" ]];
then
  DIR=.
fi

#variables for file names build
FILE_SUFFIX='_'${TIMESTAMP}

LOGIN_DENIED="ORA-01017"
FILE_ERROR="ORA-200"
ORA_ERROR="ORA-"
CONNECT="Connected."
SQLOUT=""

function UsageIs {
  echo "Usage is:" | tee -a ${LOG_FILE}
  echo "${PRG} -d date | -t | -y "| tee -a ${LOG_FILE}
  echo "" | tee -a ${LOG_FILE}
  echo "Note: Only one option can be used at a time" | tee -a ${LOG_FILE}
  echo "      Reports can be created for given Date, Today or Yesterday" | tee -a ${LOG_FILE}
  echo "Date format required: ${DATE_FORMAT}" | tee -a ${LOG_FILE}
  if [ "${DATE_FORMAT}" = "YYYYMMDDHH24MISS" ];
  then
    echo "[Time]/[mins and secs]/[secs] can be cut if not needed" | tee -a ${LOG_FILE}
  fi
  echo "" | tee -a ${LOG_FILE}

  Exit 0
}

function Exit {
  EXIT=0

  if [ $# != 0 ];
  then
    EXIT=${1}
  fi

  case ${EXIT} in
    (0)
      echo 'I '`date` "${PRG} successfully finished" | tee -a ${LOG_FILE}
      ;;
    (1)
      echo 'I '`date` "${PRG} terminated by user" | tee -a ${LOG_FILE}
      ;;
    (2)
      echo 'I '`date` "${PRG} finished with configuration error" | tee -a ${LOG_FILE}
      ;;
    (3)
      echo 'I '`date` "${PRG} finished with database error: ${2}" | tee -a ${LOG_FILE}
      ;;
    (*)
      echo 'I '`date` "${PRG} finished with errors" | tee -a ${LOG_FILE}
      ;;
  esac

  exit ${EXIT}
}

trap "echo Exiting...; Exit 1" 1 2 15

function RunSQL {
  SQLOUT=`echo "
CONNECT ${ORACLE_USER}/${ORACLE_PASSWD}@${ORACLE_SID}
--SET HEADING OFF
--SET FEEDBACK OFF
--SET PAGES 0
VAR exit_code VARCHAR2(256)
BEGIN
  :exit_code := '';
  ${1};
EXCEPTION
  WHEN OTHERS THEN
  :exit_code := SQLERRM;
END;
/
SET TERMOUT ON
PRINT exit_code" | sqlplus -S /nolog`
  SQLOUT=`echo "${SQLOUT}" | grep -v ${CONNECT}`
}

function RunSQLSelect {
  SQLOUT=`echo "
CONNECT ${ORACLE_USER}/${ORACLE_PASSWD}@${ORACLE_SID}
--SET HEADING OFF
--SET FEEDBACK OFF
--SET PAGES 0
${1};" | sqlplus -S /nolog`
  SQLOUT=`echo "${SQLOUT}" | grep -v ${CONNECT}`
}

# define config file
CONFIG_EXT="conf"
CONFIG_FILE="${DIR}/${BASE}.${CONFIG_EXT}"
LOG_EXT="log"
DEFAULT_LOG_FILE="${DIR}/${BASE}.${LOG_EXT}"
LOG_FILE=${DEFAULT_LOG_FILE}
DATA_EXT="dat"

####################################################################
# Check and initialize parameters
####################################################################
#### Search for config file
if [ ! -r "${CONFIG_FILE}" ];
then
  echo 'E '`date` Cannot open file ${CONFIG_FILE}! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Log file
LOG_FILE=`awk '/^LOG_FILE/ {print $2}' ${CONFIG_FILE}`
if [ "${LOG_FILE}" = "" ]
then
  echo 'W '`date` "Configuration parameter LOG_FILE not set (use default)!" | tee -a ${LOG_FILE}
fi

#### Get Oracle user
ORACLE_USER=`awk '/^ORACLE_USER/ {print $2}' ${CONFIG_FILE}`
if [ "${ORACLE_USER}" = "" ]
then
  echo 'E '`date` Variable ORACLE_USER not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_USER
fi

#### Get Oracle password
ORACLE_PASSWD=`awk '/^ORACLE_PASSWD/ {print $2}' ${CONFIG_FILE}`
if [ "${ORACLE_PASSWD}" = "" ]
then
  echo 'E '`date` Variable ORACLE_PASSWD not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_PASSWD
fi

#### Get Oracle SID
ORACLE_SID=`awk '/^ORACLE_SID/ {print $2}' ${CONFIG_FILE}`
if [ "${ORACLE_SID}" = "" ]
then
  echo 'E '`date` Variable ORACLE_SID not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_SID
fi

#### Get OUTPUT DIR
OUTPUT_DIR=`awk '/^OUTPUT_DIR/ {print $2}' ${CONFIG_FILE}`
if [ "${OUTPUT_DIR}" = "" ]
then
  echo 'E '`date` Variable OUTPUT_DIR not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get DB DIR
DB_DIR=`awk '/^DB_DIR/ {print $2}' ${CONFIG_FILE}`
if [ "${DB_DIR}" = "" ]
then
  echo 'E '`date` Variable DB_DIR not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#variables for file_name build
### Get FILE PREFIX
FILE_PREFIX=`awk '/^FILE_PREFIX/ {print $2}' ${CONFIG_FILE}`
if [ "${FILE_PREFIX}" = "" ]
then
  echo 'E '`date` Variable FILE_PREFIX not set! | tee -a ${LOG_FILE}
  Exit 2
fi

####################################################################
# Main program
####################################################################
cd ${DIR}
echo "" >> $LOG_FILE
PID=$$
echo 'I '`date` "${PRG} started with PID ${PID}" | tee -a  ${LOG_FILE}
echo 'I '`date` "executed as ${EXEC} ${PARAMS}" >> ${LOG_FILE}
echo 'I '`date` "from ${ORIG}" >> ${LOG_FILE}

FILE_NAME=${FILE_PREFIX}${FILE_SUFFIX}.${DATA_EXT}

#create the report file
touch ${OUTPUT_DIR}/${FILE_NAME}
#set the rights
chmod 666 ${OUTPUT_DIR}/${FILE_NAME}

case ${1} in
  (-d)
  if [ -z "${2}" ];
  then
    UsageIs
  else
    DATE=${2}
  fi
  PROC="tap_report.run_report('${DB_DIR}','${FILE_NAME}',TO_DATE('${DATE}','${DATE_FORMAT}'))"
  ;;
  (-t)
  PROC="tap_report.run_report_today('${DB_DIR}','${FILE_NAME}')"
  ;;
  (-y)
  PROC="tap_report.run_report_yesterday('${DB_DIR}','${FILE_NAME}')"
  ;;
  (*)
    UsageIs
  ;;
esac

#run SQL
RunSQL ${PROC}

#check SQL error code and run parser
if [[  `echo "${SQLOUT}" | grep ${ORA_ERROR}` = "" ]];
then
  #run parser/formatter
  create_report.sh ${OUTPUT_DIR}/${FILE_NAME} ${OUTPUT_DIR} >> ${LOG_FILE}

  if [ $? != 0 ];
  then
    echo 'E '`date` "Error while creating reports" | tee -a ${LOG_FILE}
  else
    rm -f ${OUTPUT_DIR}/${FILE_NAME}
  fi
else
  if [[  `echo "${SQLOUT}" | grep ${LOGIN_DENIED}` != "" ]];
  then
    echo 'E '`date` "Login denied - check database connection" | tee -a ${LOG_FILE}
  elif [[  `echo "${SQLOUT}" | grep ${FILE_ERROR}` != "" ]];
  then
    echo 'E '`date` "Cannot extract to file ${FILE_NAME} - check configuration" | tee -a ${LOG_FILE}
  else
    echo 'E '`date` "Error while extracting to file ${FILE_NAME}" | tee -a ${LOG_FILE}
  fi
  Exit 3 "${SQLOUT}"
fi

Exit 0

