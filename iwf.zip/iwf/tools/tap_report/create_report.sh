#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Generate the actual report for high usage limit
#    from input data file and directory name
#    First version by STY
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Robert Frydrych
#
#  $RCSfile: create_report.sh,v $
#  $Revision: 1.1 $
#  $Author: pin09 $
#  $Date: 2006/03/10 15:43:08 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: create_report.sh,v 1.1 2006/03/10 15:43:08 pin09 Exp $
#  $Log: create_report.sh,v $
#  Revision 1.1  2006/03/10 15:43:08  pin09
#  MantisID: 1759
#  Committed by RBF
#  Initial release
#
# ==============================================================================

exec 2>&1

#script name and directory
EXEC=${0}
PARAMS=${*}
PRG=${EXEC##*/}
BASE=${PRG%.*}
ORIG=${PWD}
DIR=${EXEC%/*}
if [[ "${DIR}" = "${EXEC}" || "${DIR}" = "" ]];
then
  DIR=.
fi

trap "echo Exiting...; exit 1" 1 2 15

COMPANY_NAME="Monet Montenegro"
REPORT_TITLE="REPORT ON SUSPECTED FRAUD"
USAGETEXT="usage: genreport <data_file> <valid destination directory>"

#current_path=$PWD

####################################################################
# Main program
####################################################################
if [[ $1 == "--h" || $1 == "-h" || $1 == "" ]] then
  echo $USAGETEXT
  exit 0;
else
  if [[ -r $1 ]] then
    REPORT_DATA_NAME=$1
#    LOG_FILENAME=$REPORT_DATA_NAME.log
#    `:> $LOG_FILENAME`
  else
    echo "$1 is not a valid file"
    echo $USAGETEXT
    exit 1;
  fi
fi

if [[ $2 == "" ]] then
  DIRECTORY_NAME=""
#  echo "Result Directory Name : local"
else
  if [[ -d $2 ]] then
    DIRECTORY_NAME=$2"/"
#    echo "Result Directory Name : $current_path/$2"
  else
    echo "Input a valid directory name"
    echo ""
    exit 1;
  fi
fi

echo ""
echo "$COMPANY_NAME"
echo "$REPORT_TITLE"
echo "Input data file : $REPORT_DATA_NAME"

set -A wordx
IFS="|"

while read Line
do
  counter=0
  
  IFS="|"

  for word in $Line
  do
    wordx[counter]=$word
    counter=`expr $counter + 1`
  done

  case ${wordx[0]} in
  "010")
        IFS=" "

        networkcode=${wordx[1]}
        DEST=$networkcode
        echo ${wordx[8]} | read YYYY MM DD HH24 MI SS
        wordx[8]="${DD}|${MM}|${YYYY}"
        DEST=${DEST}_${YYYY}${MM}${DD}
        echo "${wordx[7]}" | read YYYY MM DD HH24 MI SS
        wordx[7]="${DD}|${MM}|${YYYY}|${HH24}|${MI}"
        DEST=${DEST}_${YYYY}${MM}${DD}${HH24}${MI}${SS}
        DEST=$DIRECTORY_NAME$DEST

        IFS="|"

        printf "%40s\n" "$COMPANY_NAME"  > $DEST
        printf "\n" >> $DEST
        printf "%45s\n" "$REPORT_TITLE" >> $DEST
        printf "\n\n\n" >> $DEST
        echo   "Network : ${wordx[1]} ${wordx[2]}" >> $DEST
        echo   "Contact : ${wordx[3]}" >> $DEST
        echo   "Fax     : ${wordx[4]}" >> $DEST
        echo   "Tel     : ${wordx[5]}" >> $DEST
        echo   "Email   : ${wordx[6]}" >> $DEST
        echo   "" >> $DEST
        printf "Report Generation Date : %2s/%2s/%4s %2s:%2s\n" ${wordx[7]} >> $DEST
        printf "For Observation Date   : %2s/%2s/%4s\n" ${wordx[8]} >> $DEST
        printf "Spend Limit (SDRs)     : %9.3f\n" ${wordx[9]} >> $DEST
        echo   "" >> $DEST
        echo   "" >> $DEST
        echo   "IMSI No              No of Calls     Total      Total Charge     Amount Exceeded" >> $DEST
        echo   "                                    Duration       (SDRs)            (SDRs)" >> $DEST
        echo   "--------------------------------------------------------------------------------" >> $DEST
        ;;
  "020")
        printf "%10s\t%10d\t%12s\t%9.3f\t%9.3f\n" ${wordx[1]} ${wordx[2]} ${wordx[3]} \
               ${wordx[4]} ${wordx[5]} >> $DEST
        ;;
  "090")
        echo   "--------------------------------------------------------------------------------" >> $DEST
        printf "Totals\t\t%10d\t%12s\t%9.3f\t%9.3f\n" ${wordx[1]} ${wordx[2]} ${wordx[3]} \
               ${wordx[3]} >> $DEST
#        printf "."
#        printf "%s\t%d\n" ${networkcode} ${wordx[1]} >> $LOG_FILENAME
        ;;
  esac

done < ${REPORT_DATA_NAME}

#echo ""
#echo "Done"
exit 0;

