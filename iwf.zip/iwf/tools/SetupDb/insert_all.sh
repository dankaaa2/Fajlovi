#!/bin/sh
## =============================================================================
##
##          Copyright (c) 1998 - 2002 Portal Software (Hamburg) GmbH.
##                            All rights reserved.
##               This material is the confidential property of
##       Portal Software (Hamburg) GmbH or its subsidiaries or licensors
##    and may be used, reproduced, stored or transmitted only in accordance
##            with a valid Portal license or sublicense agreement.
##
## -----------------------------------------------------------------------------
## Module Description:
##    Shell script to populate all values
##
## -----------------------------------------------------------------------------
## Responsible: Armin Schmid, Portal Software
##
## $RCSfile: insert_all.sh,v $
## $Revision: 1.2 $
## $Author: pin03 $
## $Date: 2005/03/30 13:57:53 $
## -----------------------------------------------------------------------------
## $Id: insert_all.sh,v 1.2 2005/03/30 13:57:53 pin03 Exp $
## $Log: insert_all.sh,v $
## Revision 1.2  2005/03/30 13:57:53  pin03
## ASc: The script now supports arguments, can be run in batch mode
##
## Revision 1.1  2005/03/30 12:47:47  pin03
## ASc: Copied from custom/setup to this directory
##
## Revision 1.1  2005/03/09 14:25:18  pin03
## Initial release
##
## =============================================================================

## -----------------------------------------------------------------------------
## Usage: insert_all.sh [instance] [user] [password]
##        will try to find the db instance, db user and db password in the
##        arguments instance, user and password. 
##        If they are not found there, the environment variables 
##        IFW_DBINSTANCE, IFW_DBUSER and IFW_DBPASSWD are looked up.
##        If they are not found there, they are prompted for interactively.
## -----------------------------------------------------------------------------

LOGFILE=insert_all.log

# Get DB instance, user and password from arguments, if they were not specified
# assume they are already in the environment variables.
if [ "$1" != "" ]; then
   IFW_DBINSTANCE=$1
fi
if [ "$2" != "" ]; then
   IFW_DBUSER=$2
fi
if [ "$3" != "" ]; then
   IFW_DBPASSWD=$3
fi

# If instance and user were not given as argument or variable,
# read them interactively. Password will be read interactively later on
# by sqlplus WITHOUT echo on stdout
if [ "$IFW_DBINSTANCE" = "" ]; then
   echo "Please enter the instance name of the Infranet Wireless database \c"
   read IFW_DBINSTANCE
fi
if [ "$IFW_DBUSER" = "" ]; then
   echo "Please enter the database user name for that instance \c"
   read IFW_DBUSER
fi

# Create login string
IFW_LOGIN=$IFW_DBUSER@$IFW_DBINSTANCE
if [ "$IFW_DBPASSWD" != "" ]; then
IFW_LOGIN=$IFW_LOGIN/$IFW_DBPASSWD
fi

sqlplus $IFW_LOGIN @insert_all.sql $LOGFILE
