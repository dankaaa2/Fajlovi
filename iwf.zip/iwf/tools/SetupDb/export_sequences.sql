-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software Germany GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to create a SQL statement file that recreates all IFW
--    sequences. This can be used to export/import sequences from one environment
--    to another.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Kornel Szymanski
-- 
--  $RCSfile: export_sequences.sql,v $
--  $Revision: 1.2 $
--  $Author: pin03 $
--  $Date: 2005/09/14 20:19:21 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: export_sequences.sql,v 1.2 2005/09/14 20:19:21 pin03 Exp $
--  $Log: export_sequences.sql,v $
--  Revision 1.2  2005/09/14 20:19:21  pin03
--  ASc: The generated file is now called import_sequences.sql
--
--  Revision 1.1  2005/09/14 20:13:50  pin03
--  ASc: Initial release.
--
-- ==============================================================================
    
spool import_sequences.sql 
SET NEWPAGE 0
SET SPACE 0
SET LINESIZE 180
SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING OFF
SET MARKUP HTML OFF
SET ESCAPE \
select 'drop sequence ' || sequence_name || ';' from user_sequences where sequence_name in 
(
'IFW_SEQ_AGGREGATION',
'IFW_SEQ_CALENDAR',
'IFW_SEQ_CHANGESET',
'IFW_SEQ_CLASS',
'IFW_SEQ_CLASSCON',
'IFW_SEQ_CLASSITEM',
'IFW_SEQ_CONDITION',
'IFW_SEQ_CONTENTPROVIDER',
'IFW_SEQ_CSAUDIT',
'IFW_SEQ_DAYCODE',
'IFW_SEQ_DISCOUNTBALIMPACT',
'IFW_SEQ_DISCOUNTCONDITION',
'IFW_SEQ_DISCOUNTCONFIG',
'IFW_SEQ_DISCOUNTMASTER',
'IFW_SEQ_DISCOUNTMODEL',
'IFW_SEQ_DISCOUNTRULE',
'IFW_SEQ_DISCOUNTSTEP',
'IFW_SEQ_DISCOUNTTRIGGER',
'IFW_SEQ_FIELD_ID',
'IFW_SEQ_GENERIC',
'IFW_SEQ_GEOMODEL',
'IFW_SEQ_GRANTED_DISCOUNT',
'IFW_SEQ_GROUPING',
'IFW_SEQ_GROUPING_CNF',
'IFW_SEQ_NETWORKMODEL',
'IFW_SEQ_NO',
'IFW_SEQ_PRICEMODEL',
'IFW_SEQ_RATEPLAN',
'IFW_SEQ_SCENARIO',
'IFW_SEQ_SEMAPHORE',
'IFW_SEQ_SPECIALDAYRATE',
'IFW_SEQ_SYSTEMBRAND',
'IFW_SEQ_TIMEINTERVAL',
'IFW_SEQ_TIMEMODEL',
'IFW_SEQ_TIMEZONE',
'IFW_SEQ_ZONEMODEL'
);
select 'create sequence ' || sequence_name ||' increment by ' || increment_by || ' start with ' || last_number  || ' minvalue ' || min_value ||  ' maxvalue ' || max_value || ' nocycle noorder cache ' || cache_size || ';' from user_sequences where sequence_name in (
'IFW_SEQ_AGGREGATION',
'IFW_SEQ_CALENDAR',
'IFW_SEQ_CHANGESET',
'IFW_SEQ_CLASS',
'IFW_SEQ_CLASSCON',
'IFW_SEQ_CLASSITEM',
'IFW_SEQ_CONDITION',
'IFW_SEQ_CONTENTPROVIDER',
'IFW_SEQ_CSAUDIT',
'IFW_SEQ_DAYCODE',
'IFW_SEQ_DISCOUNTBALIMPACT',
'IFW_SEQ_DISCOUNTCONDITION',
'IFW_SEQ_DISCOUNTCONFIG',
'IFW_SEQ_DISCOUNTMASTER',
'IFW_SEQ_DISCOUNTMODEL',
'IFW_SEQ_DISCOUNTRULE',
'IFW_SEQ_DISCOUNTSTEP',
'IFW_SEQ_DISCOUNTTRIGGER',
'IFW_SEQ_FIELD_ID',
'IFW_SEQ_GENERIC',
'IFW_SEQ_GEOMODEL',
'IFW_SEQ_GRANTED_DISCOUNT',
'IFW_SEQ_GROUPING',
'IFW_SEQ_GROUPING_CNF',
'IFW_SEQ_NETWORKMODEL',
'IFW_SEQ_NO',
'IFW_SEQ_PRICEMODEL',
'IFW_SEQ_RATEPLAN',
'IFW_SEQ_SCENARIO',
'IFW_SEQ_SEMAPHORE',
'IFW_SEQ_SPECIALDAYRATE',
'IFW_SEQ_SYSTEMBRAND',
'IFW_SEQ_TIMEINTERVAL',
'IFW_SEQ_TIMEMODEL',
'IFW_SEQ_TIMEZONE',
'IFW_SEQ_ZONEMODEL'
);
spool off
quit
