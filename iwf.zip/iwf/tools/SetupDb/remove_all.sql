-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software Germany GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to clean all necessary tables.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid
-- 
--  $RCSfile: remove_all.sql,v $
--  $Revision: 1.8 $
--  $Author: pin03 $
--  $Date: 2005/09/28 09:16:10 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: remove_all.sql,v 1.8 2005/09/28 09:16:10 pin03 Exp $
--  $Log: remove_all.sql,v $
--  Revision 1.8  2005/09/28 09:16:10  pin03
--  ASC: Mantis 0000466: See previous revision.
--
--  Revision 1.7  2005/09/28 09:05:05  pin03
--  ASc: iRule tables are populated in a separate script using a dump file.
--
--  Revision 1.6  2005/09/14 20:15:44  pin03
--  ASc: Readded, insert_all.sql uses now the ifw_*.sql files. remove_all.sql
--       now deletes all entries instead of only the customized entries.
--
--  Revision 1.4  2005/09/14 18:39:45  pin03
--  ASc: Resources are now deleted as well.
--
--  Revision 1.3  2005/08/22 17:58:27  pin03
--  ASc: Added insert_destindesc.sql and remove_destindesc.sql
--
--  Revision 1.2  2005/07/01 15:00:45  pin03
--  ASc: Added sequence scripts.
--
--  Revision 1.1  2005/03/30 12:47:47  pin03
--  ASc: Copied from custom/setup to this directory
--
--  Revision 1.2  2005/03/15 17:31:47  pin03
--  ASc: Corrected order of zones and apn map
--
--  Revision 1.1  2005/03/09 14:24:31  pin03
--  Initial release
--
-- ==============================================================================
    
PROMPT Deleting Discount Models Configurations for split billing (charge sharing)
DELETE FROM ifw_dscmdl_cnf;
PROMPT ==========================================================================
PROMPT Deleting Discount Conditions for split billing (charge sharing)
DELETE FROM ifw_dsccondition;
PROMPT ==========================================================================
PROMPT Deleting Discount Triggers for Split Billing
DELETE FROM ifw_dsctrigger;
PROMPT ==========================================================================
PROMPT Deleting Discount Models Versions for splti billing
DELETE FROM ifw_dscmdl_ver;
PROMPT ==========================================================================
PROMPT Deleting Discount Models for charge share (split billing)
DELETE FROM ifw_Discountmodel;
PROMPT ==========================================================================
PROMPT Deleting Discount Balance Impacts for charge sharing
DELETE FROM ifw_dscbalimpact;
PROMPT ==========================================================================
PROMPT Deleting Discount Step
DELETE FROM ifw_discountstep;
PROMPT ==========================================================================
PROMPT Deleting Discount Details
DELETE FROM ifw_discountdetail;
PROMPT ==========================================================================
PROMPT Deleting Discount Rules for split billing (charge sharing groups)
DELETE FROM ifw_discountrule;
PROMPT ==========================================================================
PROMPT Deleting Discount Masters for charge sharing groups (Split billing)
DELETE FROM ifw_discountmaster;
PROMPT ==========================================================================
PROMPT Deleting IFW_LERG_DATA
DELETE FROM IFW_LERG_DATA;
PROMPT ==========================================================================
PROMPT Deleting IFW_GEO_ZONE
DELETE FROM IFW_GEO_ZONE;
PROMPT ==========================================================================
PROMPT Deleting IFW_GEOAREA_LNK
DELETE FROM IFW_GEOAREA_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_SLA
DELETE FROM IFW_SLA;
PROMPT ==========================================================================
PROMPT Deleting IFW_USC_MAP
DELETE FROM IFW_USC_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_USC_GROUP
DELETE FROM IFW_USC_GROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_USAGETYPE;
DELETE FROM IFW_USAGETYPE; 
PROMPT ==========================================================================
PROMPT Deleting IFW_USAGECLASS_MAP
DELETE FROM IFW_USAGECLASS_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_USAGECLASS
DELETE FROM IFW_USAGECLASS;
PROMPT ==========================================================================
PROMPT Deleting IFW_SPLITTING_TYPE
DELETE FROM IFW_SPLITTING_TYPE;
PROMPT ==========================================================================
PROMPT Deleting IFW_SOCIALNUMBER
DELETE FROM IFW_SOCIALNUMBER;
PROMPT ==========================================================================
PROMPT Deleting IFW_SPECIALDAY_LNK
DELETE FROM IFW_SPECIALDAY_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_SPECIALDAYRATE
DELETE FROM IFW_SPECIALDAYRATE;
PROMPT ==========================================================================
PROMPT Deleting IFW_SEGRATE_LNK
DELETE FROM IFW_SEGRATE_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_SEGZONE_LNK
DELETE FROM IFW_SEGZONE_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_SEGMENT
DELETE FROM IFW_SEGMENT;
PROMPT ==========================================================================
PROMPT Deleting IFW_RSC_MAP
DELETE FROM IFW_RSC_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_RSC_GROUP
DELETE FROM IFW_RSC_GROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_NOSP
DELETE FROM IFW_NOSP;
PROMPT ==========================================================================
PROMPT Deleting IFW_POIAREA_LNK
DELETE FROM IFW_POIAREA_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_NO_BILLRUN
DELETE FROM IFW_NO_BILLRUN;
PROMPT ==========================================================================
PROMPT Deleting IFW_ISCRIPT
DELETE FROM IFW_ISCRIPT;
PROMPT ==========================================================================
PROMPT Deleting IFW_NOPRODUCT_CNF
DELETE FROM IFW_NOPRODUCT_CNF;
PROMPT ==========================================================================
PROMPT Deleting IFW_NOPRODUCT
DELETE FROM IFW_NOPRODUCT;
PROMPT ==========================================================================
PROMPT Deleting IFW_TRUNK_CNF
DELETE FROM IFW_TRUNK_CNF;
PROMPT ==========================================================================
PROMPT Deleting IFW_TRUNK
DELETE FROM IFW_TRUNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_ICPRODUCT_CNF
DELETE FROM IFW_ICPRODUCT_CNF;
PROMPT ==========================================================================
PROMPT Deleting IFW_ICPRODUCT_GRP
DELETE FROM IFW_ICPRODUCT_GRP;
PROMPT ==========================================================================
PROMPT Deleting IFW_ICPRODUCT_RATE
DELETE FROM IFW_ICPRODUCT_RATE;
PROMPT ==========================================================================
PROMPT Deleting IFW_NO_BILLRUN
DELETE FROM IFW_NO_BILLRUN;
PROMPT ==========================================================================
PROMPT Deleting IFW_NETWORKMODEL
DELETE FROM IFW_NETWORKMODEL;
PROMPT ==========================================================================
PROMPT Deleting IFW_POI
DELETE FROM IFW_POI;
PROMPT ==========================================================================
PROMPT Deleting IFW_SWITCH
DELETE FROM IFW_SWITCH;
PROMPT ==========================================================================
PROMPT Deleting IFW_RATEADJUST
DELETE FROM IFW_RATEADJUST;
PROMPT ==========================================================================
PROMPT Deleting IFW_ICPRODUCT
DELETE FROM IFW_ICPRODUCT;
PROMPT ==========================================================================
PROMPT Deleting IFW_DICTIONARY
DELETE FROM IFW_DICTIONARY;
PROMPT ==========================================================================
PROMPT Deleting IFW_DISCARDING
DELETE FROM IFW_DISCARDING;
PROMPT ==========================================================================
PROMPT Deleting IFW_DBVERSION
DELETE FROM IFW_DBVERSION;
PROMPT ==========================================================================
PROMPT Deleting IFW_CONDITION
DELETE FROM IFW_CONDITION;
PROMPT ==========================================================================
PROMPT Deleting IFW_CLASSCON_LNK
DELETE FROM IFW_CLASSCON_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_CLASS_LNK
DELETE FROM IFW_CLASS_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_CLASSITEM
DELETE FROM IFW_CLASSITEM;
PROMPT ==========================================================================
PROMPT Deleting IFW_CLASSCON
DELETE FROM IFW_CLASSCON;
PROMPT ==========================================================================
PROMPT Deleting IFW_CIBER_OCC
DELETE FROM IFW_CIBER_OCC;
PROMPT ==========================================================================
PROMPT Deleting IFW_NETWORKOPER
DELETE FROM IFW_NETWORKOPER;
PROMPT ==========================================================================
PROMPT Deleting IFW_GROUPING_CNF
DELETE FROM IFW_GROUPING_CNF;
PROMPT ==========================================================================
PROMPT Deleting IFW_CLASS
DELETE FROM IFW_CLASS;
PROMPT ==========================================================================
PROMPT Deleting IFW_GROUPING
DELETE FROM IFW_GROUPING;
PROMPT ==========================================================================
PROMPT Deleting IFW_QUEUE
DELETE FROM IFW_QUEUE;
PROMPT ==========================================================================
PROMPT Deleting IFW_UOM_MAP
DELETE FROM IFW_UOM_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_AGGREGATION
DELETE FROM IFW_AGGREGATION;
PROMPT ==========================================================================
PROMPT Deleting IFW_SCENARIO
DELETE FROM IFW_SCENARIO;
PROMPT ==========================================================================
PROMPT Deleting IFW_DESTINDESC
DELETE FROM IFW_DESTINDESC;
PROMPT ==========================================================================
PROMPT Deleting IFW_RATEPLAN_CNF
DELETE FROM IFW_RATEPLAN_CNF;
PROMPT ==========================================================================
PROMPT Deleting IFW_RATEPLAN_VER
DELETE FROM IFW_RATEPLAN_VER;
PROMPT ==========================================================================
PROMPT Deleting IFW_RATEPLAN
DELETE FROM IFW_RATEPLAN;
PROMPT ==========================================================================
PROMPT Deleting IFW_PRICEMDL_STEP
DELETE FROM IFW_PRICEMDL_STEP;
PROMPT ==========================================================================
PROMPT Deleting IFW_PRICEMODEL
DELETE FROM IFW_PRICEMODEL;
PROMPT ==========================================================================
PROMPT Deleting IFW_TIMEMODEL_LNK
DELETE FROM IFW_TIMEMODEL_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_TIMEMODEL
DELETE FROM IFW_TIMEMODEL;
PROMPT ==========================================================================
PROMPT Deleting IFW_TIMEZONE
DELETE FROM IFW_TIMEZONE;
PROMPT ==========================================================================
PROMPT Deleting IFW_TIMEINTERVAL
DELETE FROM IFW_TIMEINTERVAL;
PROMPT ==========================================================================
PROMPT Deleting IFW_STANDARD_ZONE
DELETE FROM IFW_STANDARD_ZONE;
PROMPT ==========================================================================
PROMPT Deleting IFW_ZONEMODEL
DELETE FROM IFW_ZONEMODEL;
PROMPT ==========================================================================
PROMPT Deleting IFW_APN_MAP
DELETE FROM IFW_APN_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_APN_GROUP
DELETE FROM IFW_APN_GROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_IMPACT_CAT
DELETE FROM IFW_IMPACT_CAT;
PROMPT ==========================================================================
PROMPT Deleting IFW_ALIAS_MAP
DELETE FROM IFW_ALIAS_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_REF_MAP
DELETE FROM IFW_REF_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_SERVICE_MAP
DELETE FROM IFW_SERVICE_MAP;
PROMPT ==========================================================================
PROMPT Deleting IFW_SERVICECLASS
DELETE FROM IFW_SERVICECLASS;
PROMPT ==========================================================================
PROMPT Deleting IFW_SERVICE
DELETE FROM IFW_SERVICE;
PROMPT ==========================================================================
PROMPT Deleting IFW_REVENUEGROUP
DELETE FROM IFW_REVENUEGROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_GLACCOUNT
DELETE FROM IFW_GLACCOUNT;
PROMPT ==========================================================================
PROMPT Deleting IFW_MAP_GROUP
DELETE FROM IFW_MAP_GROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_RESOURCE
DELETE FROM IFW_RESOURCE;
PROMPT ==========================================================================
PROMPT Deleting IFW_RUMGROUP_LNK
DELETE FROM IFW_RUMGROUP_LNK;
PROMPT ==========================================================================
PROMPT Deleting IFW_RUMGROUP
DELETE FROM IFW_RUMGROUP;
PROMPT ==========================================================================
PROMPT Deleting IFW_RUM
DELETE FROM IFW_RUM;
PROMPT ==========================================================================
PROMPT Deleting IFW_UOM
DELETE FROM IFW_UOM;
PROMPT ==========================================================================
PROMPT Deleting IFW_EXCHANGE_RATE
DELETE FROM IFW_EXCHANGE_RATE;
PROMPT ==========================================================================
PROMPT Deleting IFW_RESOURCE
DELETE FROM IFW_RESOURCE;
PROMPT ==========================================================================
PROMPT Deleting IFW_CURRENCY
DELETE FROM IFW_CURRENCY;
PROMPT ==========================================================================
PROMPT Deleting IFW_HOLIDAY
DELETE FROM IFW_HOLIDAY;
PROMPT ==========================================================================
PROMPT Deleting IFW_DAYCODE
DELETE FROM IFW_DAYCODE;
PROMPT ==========================================================================
PROMPT Deleting IFW_CALENDAR
DELETE FROM IFW_CALENDAR;
PROMPT ==========================================================================
PROMPT Deleting IFW_PIPELINE
DELETE FROM IFW_PIPELINE;
PROMPT ==========================================================================
PROMPT Deleting IFW_EDRC_FIELD
DELETE FROM IFW_EDRC_FIELD;
PROMPT ==========================================================================
PROMPT Deleting IFW_EDRC_DESC
DELETE FROM IFW_EDRC_DESC;
PROMPT ==========================================================================
PROMPT Deleting IFW_GEO_MODEL
DELETE FROM IFW_GEO_MODEL;
-- PROMPT ==========================================================================
-- PROMPT Deleting IFW_RULESETLIST
-- DELETE FROM IFW_RULESETLIST;
-- PROMPT ==========================================================================
-- PROMPT Deleting IFW_RULEITEM
-- DELETE FROM IFW_RULEITEM;
-- PROMPT ==========================================================================
-- PROMPT Deleting IFW_RULE
-- DELETE FROM IFW_RULE;
-- PROMPT ==========================================================================
-- PROMPT Deleting IFW_RULESET
-- DELETE FROM IFW_RULESET;
PROMPT ==========================================================================
PROMPT Deleting IFW_SYSTEM_BRAND
DELETE FROM IFW_SYSTEM_BRAND;
PROMPT ==========================================================================
PROMPT Deleting IFW_TAX
DELETE FROM IFW_TAX;
PROMPT ==========================================================================
PROMPT Deleting IFW_TAXCODE
DELETE FROM IFW_TAXCODE;
PROMPT ==========================================================================
PROMPT Deleting IFW_TAXGROUP
DELETE FROM IFW_TAXGROUP;
PROMPT ==========================================================================
