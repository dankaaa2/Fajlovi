-- ==============================================================================
-- 
--           Copyright (c) 1998 - 2003 Portal Software Germany GmbH.
--                             All rights reserved.
--                This material is the confidential property of
--        Portal Software Germany GmbH or its subsidiaries or licensors
--     and may be used, reproduced, stored or transmitted only in accordance
--             with a valid Portal license or sublicense agreement.
-- 
-- ------------------------------------------------------------------------------
--  Module Description:
--    SQL statement file to populate all necessary tables.
-- 
--  Open Points:
--    none
-- 
--  Review Status:
--    review
-- 
-- ------------------------------------------------------------------------------
--  Responsible: Armin Schmid
-- 
--  $RCSfile: insert_all.sql,v $
--  $Revision: 1.9 $
--  $Author: pin03 $
--  $Date: 2005/10/17 20:19:09 $
-- ------------------------------------------------------------------------------
--  History:
--  $Id: insert_all.sql,v 1.9 2005/10/17 20:19:09 pin03 Exp $
--  $Log: insert_all.sql,v $
--  Revision 1.9  2005/10/17 20:19:09  pin03
--  MantisID: 761
--  Committed by Armin
--  ifw_seqcheck.sql was missing
--
--  Revision 1.8  2005/09/28 09:16:10  pin03
--  ASC: Mantis 0000466: See previous revision.
--
--  Revision 1.7  2005/09/28 09:05:05  pin03
--  ASc: iRule tables are populated in a separate script using a dump file.
--
--  Revision 1.6  2005/09/14 20:15:44  pin03
--  ASc: Readded, insert_all.sql uses now the ifw_*.sql files. remove_all.sql
--       now deletes all entries instead of only the customized entries.
--
--  Revision 1.4  2005/08/22 17:58:27  pin03
--  ASc: Added insert_destindesc.sql and remove_destindesc.sql
--
--  Revision 1.3  2005/07/01 15:00:45  pin03
--  ASc: Added sequence scripts.
--
--  Revision 1.2  2005/05/17 20:29:04  pin18
--  Added insert_resources here as price model step needs it
--
--  Revision 1.1  2005/03/30 12:47:47  pin03
--  ASc: Copied from custom/setup to this directory
--
--  Revision 1.2  2005/03/15 17:31:47  pin03
--  ASc: Corrected order of zones and apn map
--
--  Revision 1.1  2005/03/09 14:24:31  pin03
--  Initial release
--
-- ==============================================================================
    
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

SPOOL &1

@remove_all.sql

PROMPT Inserting IFW_TAXGROUP
@ifw_taxgroup.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TAXCODE
@ifw_taxcode.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TAX
@ifw_tax.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SYSTEM_BRAND
@ifw_system_brand.sql
-- PROMPT ==========================================================================
-- PROMPT Inserting IFW_RULESET
-- @ifw_ruleset.sql
-- PROMPT ==========================================================================
-- PROMPT Inserting IFW_RULE
-- @ifw_rule.sql
-- PROMPT ==========================================================================
-- PROMPT Inserting IFW_RULEITEM
-- @ifw_ruleitem.sql
-- PROMPT ==========================================================================
-- PROMPT Inserting IFW_RULESETLIST
-- @ifw_rulesetlist.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GEO_MODEL
@ifw_geo_model.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_EDRC_DESC
@ifw_edrc_desc.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_EDRC_FIELD
@ifw_edrc_field.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_PIPELINE
@ifw_pipeline.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CALENDAR
@ifw_calendar.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_DAYCODE
@ifw_daycode.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_HOLIDAY
@ifw_holiday.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CURRENCY
@ifw_currency.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RESOURCE
@ifw_resource.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_EXCHANGE_RATE
@ifw_exchange_rate.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_UOM
@ifw_uom.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RUM
@ifw_rum.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RUMGROUP
@ifw_rumgroup.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RUMGROUP_LNK
@ifw_rumgroup_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_MAP_GROUP
@ifw_map_group.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GLACCOUNT
@ifw_glaccount.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_REVENUEGROUP
@ifw_revenuegroup.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SERVICE
@ifw_service.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SERVICECLASS
@ifw_serviceclass.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SERVICE_MAP
@ifw_service_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_REF_MAP
@ifw_ref_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ALIAS_MAP
@ifw_alias_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_IMPACT_CAT
@ifw_impact_cat.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_APN_GROUP
@ifw_apn_group.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_APN_MAP
@ifw_apn_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ZONEMODEL
@ifw_zonemodel.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_STANDARD_ZONE
@ifw_standard_zone.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TIMEINTERVAL
@ifw_timeinterval.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TIMEZONE
@ifw_timezone.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TIMEMODEL
@ifw_timemodel.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TIMEMODEL_LNK
@ifw_timemodel_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_PRICEMODEL
@ifw_pricemodel.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_PRICEMDL_STEP
@ifw_pricemdl_step.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RATEPLAN
@ifw_rateplan.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RATEPLAN_VER
@ifw_rateplan_ver.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RATEPLAN_CNF
@ifw_rateplan_cnf.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_DESTINDESC
@ifw_destindesc.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SCENARIO
@ifw_scenario.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_AGGREGATION
@ifw_aggregation.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_UOM_MAP
@ifw_uom_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_QUEUE
@ifw_queue.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GROUPING
@ifw_grouping.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CLASS
@ifw_class.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GROUPING_CNF
@ifw_grouping_cnf.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NETWORKOPER
@ifw_networkoper.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CIBER_OCC
@ifw_ciber_occ.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CLASSCON
@ifw_classcon.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CLASSITEM
@ifw_classitem.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CLASS_LNK
@ifw_class_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CLASSCON_LNK
@ifw_classcon_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_CONDITION
@ifw_condition.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_DBVERSION
@ifw_dbversion.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_DISCARDING
@ifw_discarding.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_DICTIONARY
@ifw_dictionary.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ICPRODUCT
@ifw_icproduct.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RATEADJUST
@ifw_rateadjust.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SWITCH
@ifw_switch.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_POI
@ifw_poi.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NETWORKMODEL
@ifw_networkmodel.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NO_BILLRUN
@ifw_no_billrun.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ICPRODUCT_RATE
@ifw_icproduct_rate.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ICPRODUCT_GRP
@ifw_icproduct_grp.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ICPRODUCT_CNF
@ifw_icproduct_cnf.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TRUNK
@ifw_trunk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_TRUNK_CNF
@ifw_trunk_cnf.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NOPRODUCT
@ifw_noproduct.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NOPRODUCT_CNF
@ifw_noproduct_cnf.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_ISCRIPT
@ifw_iscript.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NO_BILLRUN
@ifw_no_billrun.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_POIAREA_LNK
@ifw_poiarea_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_NOSP
@ifw_nosp.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RSC_GROUP
@ifw_rsc_group.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_RSC_MAP
@ifw_rsc_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SEGMENT
@ifw_segment.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SEGZONE_LNK
@ifw_segzone_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SEGRATE_LNK
@ifw_segrate_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SPECIALDAYRATE
@ifw_specialdayrate.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SPECIALDAY_LNK
@ifw_specialday_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SOCIALNUMBER
@ifw_socialnumber.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SPLITTING_TYPE
@ifw_splitting_type.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_USAGECLASS
@ifw_usageclass.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_USAGECLASS_MAP
@ifw_usageclass_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_USAGETYPE;
@ifw_usagetype.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_USC_GROUP
@ifw_usc_group.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_USC_MAP
@ifw_usc_map.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_SLA
@ifw_sla.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GEOAREA_LNK
@ifw_geoarea_lnk.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_GEO_ZONE
@ifw_geo_zone.sql
PROMPT ==========================================================================
PROMPT Inserting IFW_LERG_DATA
@ifw_lerg_data.sql
PROMPT ==========================================================================
PROMPT Inserting discount models
@ifw_discountmodel.sql
PROMPT ==========================================================================
PROMPT Inserting discount model versions
@ifw_dscmdl_ver.sql
PROMPT ==========================================================================
PROMPT Inserting discount masters
@ifw_discountmaster.sql
PROMPT ==========================================================================
PROMPT Inserting discount details
@ifw_discountdetail.sql
PROMPT ==========================================================================
PROMPT Inserting discount triggers
@ifw_dsctrigger.sql
PROMPT ==========================================================================
PROMPT Inserting discount conditions
@ifw_dsccondition.sql
PROMPT ==========================================================================
PROMPT Inserting discount rules
@ifw_discountrule.sql
PROMPT ==========================================================================
PROMPT Inserting discount steps
@ifw_discountstep.sql
PROMPT ==========================================================================
PROMPT Inserting discount balance impacts
@ifw_dscbalimpact.sql
PROMPT ==========================================================================
PROMPT Inserting discount model configurations
@ifw_dscmdl_cnf.sql
PROMPT ==========================================================================
PROMPT Recreating sequences
@import_sequences.sql
PROMPT ==========================================================================
PROMPT Inserting sequence checks
PROMPT Error messages can be ignored
WHENEVER SQLERROR CONTINUE NONE
@ifw_seqcheck.sql
PROMPT ==========================================================================

COMMIT;

SPOOL OFF

EXIT
