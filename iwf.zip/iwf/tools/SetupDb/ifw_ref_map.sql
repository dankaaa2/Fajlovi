INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gsm/telephony', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gsm/sms', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gsm/fax', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gsm/asf', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gsm/data', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/gprs', NULL, '/event/delayed/session/gprs', 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/mms', NULL, '/event/delayed/session/gprs', 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/telco/roam/gsm/telephony', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/gsm/sms', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/gsm/fax', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/gsm/asf', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/gsm/data', NULL, '/event/delayed/session/telco/gsm'
, 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/gprs', NULL, '/event/delayed/session/gprs', 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 0); 
INSERT INTO IFW_REF_MAP ( ID, REF_OBJ, REF_COL, REF_PARAM, ENTRYBY, ENTRYDATE, MODIFIED, MODIFBY,
MODIFDATE, RECVER ) VALUES ( 
'CustomerData', '/service/roam/mms', NULL, '/event/delayed/session/gprs', 0,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 1, NULL,  TO_Date( '09/01/2005 09:30:36 PM', 'MM/DD/YYYY HH:MI:SS AM'), 0); 
commit;
 
