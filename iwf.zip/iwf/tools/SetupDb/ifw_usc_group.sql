INSERT INTO IFW_USC_GROUP ( USC_GROUP, NAME, ENTRYBY, ENTRYDATE, MODIFBY, MODIFDATE, MODIFIED,
RECVER ) VALUES ( 
'ALL_RATE', 'Wireless Sample Usage Scenario Mapping (combining UsageClasses and Zones to all ImpactCategories)'
, 0,  TO_Date( '07/25/2005 12:15:04 PM', 'MM/DD/YYYY HH:MI:SS AM'), NULL,  TO_Date( '07/25/2005 12:15:04 PM', 'MM/DD/YYYY HH:MI:SS AM')
, 1, 0); 
commit;
 
