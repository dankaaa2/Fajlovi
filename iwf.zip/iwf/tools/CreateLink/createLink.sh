#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Create necessary links
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Robert Frydrych
#
#  $RCSfile: createLink.sh,v $
#  $Revision: 1.7 $
#  $Author: pin03 $
#  $Date: 2007/09/25 12:41:37 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: createLink.sh,v 1.7 2007/09/25 12:41:37 pin03 Exp $
#  $Log: createLink.sh,v $
#  Revision 1.7  2007/09/25 12:41:37  pin03
#  0002310: Configuration of SGSN3G and GGSN3G downloaders
#
#  Revision 1.6  2007/04/26 11:03:36  pin23
#  Mantis case 0002283: Configuration of Trial SGSN and Trial GGSN downloaders
#
#  Revision 1.5  2006/02/20 10:50:41  pin09
#  MantisID: 1348
#  Committed by RBF
#  added MoveHandler
#
#  Revision 1.4  2005/12/08 14:01:52  pin09
#  MantisID: 1265
#  Committed by RBF
#  added new parameters
#
#  Revision 1.3  2005/11/25 00:38:08  pin09
#  MantisID: 462
#  Committed by RBF
#  added links for downloaders
#
#  Revision 1.2  2005/09/12 11:29:14  pin09
#  RBF: mkdir -p
#
#  Revision 1.1  2005/09/12 11:16:02  pin09
#  RBF: Initial release
#
# ==============================================================================

COUNTER=0

function CreateDir {
  DIR=${1}
  if [ ! -d ${DIR} ]; then
    mkdir -p ${DIR}
    ((COUNTER=${COUNTER}+1))
  fi
}

function CreateLink {
  DIR=${1}
  if [[ $# = 1 ]]; then
    LINK=${1##*/}
  else
    LINK=${2}
  fi
  if [ ! -L ${LINK} ]; then
    ln -s ${DIR} ${LINK}
    ((COUNTER=${COUNTER}+1))
  fi
}

if [ -d "${1}" ];
then
  cd ${1}
fi

#Link data and var
if [ -d "${2}" ];
then
  CreateLink ${2} var
else
  CreateLink ../var var
fi
if [ -d "${3}" ];
then
  CreateLink ${3} data
else
  CreateLink ../data data
fi

#Link etc
cd custom/etc
for xfile in `ls -1 ${IFW_HOME}/etc/*msg`
do
  CreateLink $xfile;
done
cd ../..

#Link InfranetAccount
cd custom/formatDesc/Formats
CreateLink ${IFW_HOME}/formatDesc/Formats/InfranetAccount InfranetAccount
cd ../../..

#Link FTP
cd custom/tools/FTP/CGSN
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..
cd custom/tools/FTP/MMSC
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..
#Added for new FTP downloader SGSNT3G
cd custom/tools/FTP/SGSNT3G
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..
#Added for new FTP downloader GGSNT3G
cd custom/tools/FTP/GGSNT3G
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..
#Added for new FTP downloader SGSN3G
cd custom/tools/FTP/SGSN3G
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..
#Added for new FTP downloader GGSN3G
cd custom/tools/FTP/GGSN3G
CreateLink ../pin_cdr_collector/pin_cdr_collector pin_cdr_collector
cd ../../../..

#Link Downloader
cd custom/tools/FTP/CGSN
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..
cd custom/tools/FTP/MMSC
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..
cd custom/tools/FTAM
CreateLink ../Downloader/downloader.sh gsm_downloader.sh
cd ../../..
#Added for new FTP downloader SGSNT3G
cd custom/tools/FTP/SGSNT3G
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..
#Added for new FTP downloader GGSNT3G
cd custom/tools/FTP/GGSNT3G
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..
#Added for new FTP downloader SGSN3G
cd custom/tools/FTP/SGSN3G
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..
#Added for new FTP downloader GGSN3G
cd custom/tools/FTP/GGSN3G
CreateLink ../../Downloader/downloader.sh pin_cdr_collector.sh
cd ../../../..


#Link MoveHandler
cd custom/tools/Move
CreateLink MoveHandler.pl move_GSM_RATE.pl
CreateLink MoveHandler.pl move_GPRS_RATE.pl
CreateLink MoveHandler.pl move_RGSM_RATE.pl
CreateLink MoveHandler.pl move_RGPRS_RATE.pl
cd ../../..

echo "`date`\nCreated ${COUNTER} links"

