#!/bin/ksh
#Skripta za brisanje CDR-ova iz /flash/home/billing/transferred na EPG nodu
#
#Konfiguracijske konstante
SOURCEHOST=10.240.92.102
SFTPUSER=billing
SOURCEDIR=/flash/home/billing/transferred/archive
PIN_LOG=/var/portal/7.0
LOGFILE=$PIN_LOG/log/SFTP/DelOldEPG_files.log
FILEPATTERN=E


echo "DELETE START "`date` >>$LOGFILE
/usr/local/bin/ssh billing@10.240.92.102 "find $SOURCEDIR/${FILEPATTERN}* -mtime +7 -exec rm {} \;" >> LOGFILE
