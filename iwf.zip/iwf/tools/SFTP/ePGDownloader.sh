#!/bin/ksh
# Skripta za prebacivanje ePG CDR fajlova
# na medijaciju
# 
#
#KONFIGURACIONE KONSTANTE

SOURCEHOST=10.240.92.102
SFTPUSER=billing
SOURCEDIR=/var/opt/services/epg/cdr
#SOURCEXFERDIR=/var/opt/services/epg/cdr/transferred
SOURCEXFERDIR=/flash/home/billing/transferred
IFW_HOME=/opt/portal/ifw
PIN_LOG=/var/portal/7.0
WKDIR=$IFW_HOME/custom/tools/SFTP/
LOGFILE=$PIN_LOG/log/SFTP/ePGDownloader.log
AUDITFILE=$PIN_LOG/log/SFTP/audit_ePG.log
FILELIST=$PIN_LOG/log/SFTP/ePG.list
FILEPATTERN=E
TRANSFERTYPE=
SLEEPTIME=5
DESTINATION=$IFW_HOME/data/FTP/GGSN_ePC
TEMPDEST=$DESTINATION/tmp
READYDEST=$DESTINATION/ready


get_filelist()
{
	AUTH=$1
	SDIR=$2
	/usr/local/bin/sftp $AUTH<<EOB
	cd $SDIR
	ls -l ${FILEPATTERN}*
	quit
EOB
}

sftp_file()
{
        AUTH=$1
        REMOTESOURCEDIR=$2
        SOURCEFILE=$3
        DESTDIR=$4
        XFERDFILEDIR=$5

        /usr/local/bin/sftp $AUTH<<EOT
        lcd $DESTDIR
        cd $REMOTESOURCEDIR
        get -P $SOURCEFILE $SOURCEFILE.tmp
        quit
EOT
}

main()
{
	echo "GET FILE LIST START "`date` >>$LOGFILE
	get_filelist $SFTPUSER@$SOURCEHOST $SOURCEDIR >$FILELIST 2>>$LOGFILE

	echo "TRANSFER START "`date` >>$LOGFILE
	for FILE in `awk '{print $9}' $FILELIST`
	do
		#Transfer na medjacju
        	sftp_file $SFTPUSER@$SOURCEHOST $SOURCEDIR $FILE $TEMPDEST $SOURCEXFERDIR >>$LOGFILE 2>>$LOGFILE
        	if [ $? -eq 0 ] ; then
        	        echo $FILE" transferred" >>$LOGFILE
        	else
        	        echo $FILE" transfer ERROR" >>$LOGFILE
        	fi
		#Prebacanje u ready dir
		mv $TEMPDEST/$FILE.tmp $READYDEST/$FILE 2>>$LOGFILE
		#Backup-uj fajl na ePG
                /usr/local/bin/ssh $SFTPUSER@$SOURCEHOST mv $SOURCEDIR/$FILE $SOURCEXFERDIR 2>>$LOGFILE
		#Kraj backupa
		#sleep 30
	done
	echo "TRANSFER END "`date` >>$LOGFILE
}

echo "*************************************************************************" >>$LOGFILE
main
echo "*************************************************************************" >>$LOGFILE
echo "*************************************************************************" >>$AUDITFILE
date>>$AUDITFILE
cat $FILELIST>>$AUDITFILE
echo "*************************************************************************" >>$AUDITFILE

