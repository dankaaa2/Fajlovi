#!/bin/ksh
# Skripta za prebacivanje MMS CDR fajlova generisanih na MiO platformi
# na medijaciju
# 
# Boris Vucinic, novembar 2011.
#
#KONFIGURACIONE KONSTANTE

SOURCEHOST=192.168.9.45
SFTPUSER=billing
SOURCEDIR=/mms/asn1berRep
SOURCEXFERDIR=/mms/asn1berRep/transferred
IFW_HOME=/opt/portal/ifw
PIN_LOG=/var/portal/7.0
WKDIR=$IFW_HOME/custom/tools/SFTP/MiO
LOGFILE=$PIN_LOG/log/SFTP/MiODownloader.log
AUDITFILE=$PIN_LOG/log/SFTP/audit_MiO.log
FILELIST=$PIN_LOG/log/SFTP/MiO.list
FILEPATTERN=F
TRANSFERTYPE=
SLEEPTIME=5
DESTINATION=$IFW_HOME/data/FTP/MiO
TEMPDEST=$DESTINATION/tmp
READYDEST=$DESTINATION/ready


get_filelist()
{
	AUTH=$1
	SDIR=$2
	/usr/local/bin/sftp $AUTH<<EOB
	cd $SDIR
	ls -l ${FILEPATTERN}*
	quit
EOB
}

sftp_file()
{
        AUTH=$1
        REMOTESOURCEDIR=$2
        SOURCEFILE=$3
        DESTDIR=$4
        XFERDFILEDIR=$5

        /usr/local/bin/sftp $AUTH<<EOT
        lcd $DESTDIR
        cd $REMOTESOURCEDIR
        get -P $SOURCEFILE $SOURCEFILE.tmp
        rename $SOURCEFILE $XFERDFILEDIR/$SOURCEFILE
        quit
EOT
}

main()
{
	echo "GET FILE LIST START "`date` >>$LOGFILE
	get_filelist $SFTPUSER@$SOURCEHOST $SOURCEDIR >$FILELIST 2>>$LOGFILE

	echo "TRANSFER START "`date` >>$LOGFILE
	for FILE in `awk '{print $9}' $FILELIST`
	do
		#Transfer na medjacju
        	sftp_file $SFTPUSER@$SOURCEHOST $SOURCEDIR $FILE $TEMPDEST $SOURCEXFERDIR >>$LOGFILE 2>>$LOGFILE
        	if [ $? -eq 0 ] ; then
        	        echo $FILE" transferred" >>$LOGFILE
        	else
        	        echo $FILE" transfer ERROR" >>$LOGFILE
        	fi
		#Prebacanje u ready dir
		mv $TEMPDEST/$FILE.tmp $READYDEST/$FILE 2>>$LOGFILE
		#sleep 30
	done
	echo "TRANSFER END "`date` >>$LOGFILE
}

echo "*************************************************************************" >>$LOGFILE
main
echo "*************************************************************************" >>$LOGFILE
echo "*************************************************************************" >>$AUDITFILE
date>>$AUDITFILE
cat $FILELIST>>$AUDITFILE
echo "*************************************************************************" >>$AUDITFILE

