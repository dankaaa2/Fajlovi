#!/bin/ksh
# Skripta za prebacivanje ePG CDR fajlova
# na medijaciju
# 
#
#KONFIGURACIONE KONSTANTE

SOURCEHOST=10.240.92.56
SFTPUSER=billing
SOURCEDIR=/tmp/OMS_CHARGING/chsLog/ready
SOURCEXFERDIR=/tmp/OMS_CHARGING/chsLog/ready/transferred
IFW_HOME=/opt/portal/ifw
PIN_LOG=/var/portal/7.0
WKDIR=$IFW_HOME/custom/tools/SFTP/SGSN_ePC
LOGFILE=$PIN_LOG/log/SFTP/SGSNDownloader.log
AUDITFILE=$PIN_LOG/log/SFTP/audit_SGSN.log
FILELIST=$PIN_LOG/log/SFTP/SGSN.list
FILEPATTERN=c
TRANSFERTYPE=
SLEEPTIME=5
DESTINATION=$IFW_HOME/data/FTP/SGSN_ePC
TEMPDEST=$DESTINATION/tmp
READYDEST=$DESTINATION/ready


get_filelist()
{
	AUTH=$1
	SDIR=$2
	/usr/local/bin/sftp $AUTH<<EOB
	cd $SDIR
	ls -l ${FILEPATTERN}*
	quit
EOB
}

sftp_file()
{
        AUTH=$1
        REMOTESOURCEDIR=$2
        SOURCEFILE=$3
        DESTDIR=$4
        XFERDFILEDIR=$5

        /usr/local/bin/sftp $AUTH<<EOT
        lcd $DESTDIR
        cd $REMOTESOURCEDIR
        get -P $SOURCEFILE $SOURCEFILE.tmp
        rename $SOURCEFILE $XFERDFILEDIR/$SOURCEFILE
        quit
EOT
}

main()
{
	echo "GET FILE LIST START "`date` >>$LOGFILE
	get_filelist $SFTPUSER@$SOURCEHOST $SOURCEDIR >$FILELIST 2>>$LOGFILE

	echo "TRANSFER START "`date` >>$LOGFILE
	for FILE in `awk '{print $9}' $FILELIST`
	do
		#Transfer na medjacju
        	sftp_file $SFTPUSER@$SOURCEHOST $SOURCEDIR $FILE $TEMPDEST $SOURCEXFERDIR >>$LOGFILE 2>>$LOGFILE
        	if [ $? -eq 0 ] ; then
        	        echo $FILE" transferred" >>$LOGFILE
        	else
        	        echo $FILE" transfer ERROR" >>$LOGFILE
        	fi
		#Prebacanje u ready dir
		FTSAMP=`/usr/local/bin/stat -c %y $TEMPDEST/$FILE.tmp|awk '{print substr($1,1,4)substr($1,6,2)substr($1,9,2)substr($2,1,2)substr($2,4,2)substr($2,7,2)}'`
		mv $TEMPDEST/$FILE.tmp $READYDEST/$FILE"_"$FTSAMP 2>>$LOGFILE
		#sleep 30
	done
	echo "TRANSFER END "`date` >>$LOGFILE
}

echo "*************************************************************************" >>$LOGFILE
main
echo "*************************************************************************" >>$LOGFILE
echo "*************************************************************************" >>$AUDITFILE
date>>$AUDITFILE
cat $FILELIST>>$AUDITFILE
echo "*************************************************************************" >>$AUDITFILE

