#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Start files parsing
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Piotr Skarpetowski
#
#  $RCSfile: parse_controller.sh.tpl,v $
#  $Revision: 1.2 $
#  $Author: pin09 $
#  $Date: 2006/04/11 12:11:51 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: parse_controller.sh.tpl,v 1.2 2006/04/11 12:11:51 pin09 Exp $
#  $Log: parse_controller.sh.tpl,v $
#  Revision 1.2  2006/04/11 12:11:51  pin09
#  MantisID: 1878
#  Committed by RBF
#  added environment variables reading
#
# ==============================================================================

exec 2>&1

TERM=vt100
export TERM

if [[ -f /etc/profile ]];
then
  . /etc/profile
fi

if [[ $# -ge 1 ]];
then
  . ${1}
else
  echo "Please specify file with environment variables"
  exit 2
fi

DATE1=`date +"%Y%m%d"`
CO_ILE_SEKUND='1'
USER=`/usr/xpg4/bin/id -u -nr`
FROM_DIR='/data/pin01/ifw/data/mms_pre_parse/mmsc'
PREPARSER='/data/pin01/ifw/custom/tools/Parse'
DATE=`date +"%Y.%m.%d %H:%M:%S"`
LOG="/data/pin01/var/log/mms_pre_parse/parse_controller_${DATE1}.log"
cd $FROM_DIR
ILE_PLIKOW=`ls F*.edr | wc -l`
if [[ $ILE_PLIKOW -ge "1" ]];
then
   for i in `ls F*`
   do
      cd $FROM_DIR
      mv $i $i.ok
      echo "Parsing $i.ok " >> ${LOG}
      cd $PREPARSER
      $PREPARSER/parse_handler.pl -p $$
      sleep $CO_ILE_SEKUND
      CZY=`ps -fu $USER | grep "parse_cdr" | wc -l`
      while [[ $CZY -ge "2" ]];  # do not run more then one process at the same time
      do
         CZY=`ps -fu $USER | grep "parse_cdr" | wc -l`
         CZY=`expr $CZY`
         echo "Waiting 5 sec to finsh pre_parser" >> ${LOG}
         sleep 5
      done
   done
else
   sleep $CO_ILE_SEKUND
   cd $FROM_DIR
fi

