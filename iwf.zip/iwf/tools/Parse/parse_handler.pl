#!/opt/portal/7.0/bin/perl
#	Copyright (c) 2000-2003 Portal Software, Inc.  All rights reserved.
#
#	This material is the confidential property of Portal Software, Inc.
#	or its subsidiaries or licensors and may be used, reproduced,
#	stored or transmitted only in accordance with a valid Portal
#	license or sublicense agreement.
#
#=============================================================
#
# File:  parse_handler.pl
# Title: CRM Interface batch handler script
#
# Description:
#	This script is responsible for:
#	- calling the batch application to process the input files, and
#	- moving the input and output files to the appropriate
#	  directories based on the return value of the batch application.
#
# $Log: parse_handler.pl,v $
# Revision 1.2  2006/01/12 18:22:24  pin01
# MantisID: 1357
# Committed by PSEI
# Removed DB connection
#
# Revision 1.1  2005/08/19 15:09:39  pin01
# PSEI: Initial release
#
# Revision 1.2  2005/03/21 06:58:13  bsathyam
# 1786:Fix added by Anshuman for not processing 0 size files
#
# Revision 1.1.1.1  2005/01/25 18:35:04  rnarayan
# New repository
#
# Revision 1.1  2005/01/19 10:27:54  csnair
# CO NO 1114
#
# Revision 1.3  2005/01/17 12:40:22  rnarayan
# updated code -CO NO 1114
# 
#=============================================================


require "parse_config.values";
require "getopts.pl";
use pcmif;
use Sys::Hostname;
use File::Copy;
use File::Basename;
use File::Path;


#
# Define the Sample Handler status variables that return
# to the database.
$HANDLER_STARTED = 1;			# Handler started properly.
$COMPLETED_NO_ERROR = 19;		# The file was processed by the batch
					# application with no error.
$DEAD_STATUS = 100;			# Status of a previously failed handler.
$WITH_ERROR = 101;			# The file was processed by the batch
					# application with error.
$REJECTED = 102;			# The file was rejected by the batch
					# application.
$PILOT_ERROR = 103;			# Batch application failed with
					# pilot error.
$NO_FILE_TYPE = 104;			# File does not exist.
$FAIL_TO_MOVE_FILE = 105;		# Failed to move the file to the
					# processing directory.
$NO_CRM_EXEC = 106;			# Batch application executable does
					# not exit.
$FAIL_TO_START_CRM = 107;		# Failed to start batch application.

#
# Value to massage negative batch application exit codes under Unix.
$UNIX_SHIFT = 8;


#
# Define the batch application exit code values.
$NO_ERROR = 0;
$FILE_CHECK_ERROR = -1;
$MEMORY_ERROR = -2;
$DISK_SPACE_ERROR = -3;
$TEMPLATE_ERROR = -4;
$BAD_INF_CONNECTION = -100;
$FIELD_PARSE_ERROR = 1;
$ACCT_FORMAT_ERROR = 2;
$LOAD_FORMAT_ERROR = 3;
$PREV_PARSE_ERROR = 4;
$TOO_MANY_LOAD_ERROR = 5;
$COMMAND_LINE_ARG_ERROR = 10;
$FILE_NOT_FOUND_ERROR = 11;
$ACCT_OPCODE_ERROR = 100 ;
$LOAD_OPCODE_ERROR = 101;


#
# Get the current time.
$localtime = localtime();


#
# Command line argument.
&Getopts('p:d:') || &usage;

if (!defined $opt_p) {
	&usage;
}
$current_poid = $opt_p;


#
# Check if there is a log file associated with the handler
open(LOG, ">>$LOGFILE");
print("\n log file opened\n");

#
# Get the current handler process id (PID)
$PID = $$;


#
# Log a debugging message in the handler log file
if ($DEBUG_2) {
	print LOG "$PID: $localtime: STARTING: Handler associated with '$current_poid' started\n";
}



#
# Create the input Flist to update object status to STARTED.
$T_time = pcmif::pin_perl_time();
$hostname = hostname();


$localtime = localtime();
#
# Get the list of files in the staging directory; skip all beginning with '.'
opendir STAGING_DIR, "$STAGING" or die "$PID: $localtime: Cannot open directory $STAGING";
@allfiles = grep !/^$STAGING\/\./, map "$STAGING/$_", readdir(STAGING_DIR);
closedir(STAGING_DIR);

#
# Ensure the user is not passing the directory path name
# within the file type.
$FILETYPE = basename ($FILETYPE);

$localtime = localtime();
#
# Find files matching specified pattern in the staging dir.
$FILETYPE =~ s/\./\\\./g;
$FILETYPE =~ s/\*/\.*/g;
@file_type = grep /^$STAGING.$FILETYPE$/, @allfiles;
$numelements = @file_type;
if ($numelements <= 0) {
	if ($DEBUG_2) {
		print LOG "$PID: $localtime: FILES: No files match specified pattern, exiting.\n";
	}
	&HandlerDie($NO_FILE_TYPE, $current_poid);
}


#
# Sort matching files based on creation date.
foreach $file(@file_type){
	$age{$file} = -M$file;
}
@sorted_allfiles = sort byage @file_type;

#
# Reformat directory path name based on operating system type.
if ($pinMMSCDir =~ /\\/) {
	$pinMMSCDir =~ s/\\/\//g;
}

#
# Which operating system are we on?
if ($^O =~/win/i) {
	$pinMMSCDir =~ s/\//\\/g;
}

#
# Prepare input files for processing.
$num_files = 0;
$moved_a_file = 0; # Set to 1 when a file is successfully moved.
$total_files = @sorted_allfiles;
print LOG "$PID: $localtime: FILES: Total of files in the staging directory: $total_files.\n";
@copy_sorted_allfile = @sorted_allfiles;
foreach $file_print(@copy_sorted_allfile){
	$num_files++;
	print LOG "$PID: $localtime: FILES: Listintg file  [$num_files] basename ($file_print).\n";
}
$num_files = 0;
foreach $file(@sorted_allfiles) {
	$num_files++;
	# Uncompress file if necessary,
	# reset variable to uncompressed file name.
	if ($file =~ /.Z$/) {
		# foo.Z -> foo
		system "uncompress $file";
		$file =~ s/\.Z$//;
	}
	if ($file =~ /.gz$/) {
		# foo.gz -> foo
		system "gunzip $file";
		$file =~ s/\.gz$//;
	}

	$localtime = localtime();
	print LOG "$PID: $localtime: FILES: ($file) being processed - file number: $num_files.\n";
	#
	# Check for the file size. If file is of size 0, then move it to Reject directory
	# 
	$size = -s $file;
	if ($size == 0) {
		print LOG "$PID: $localtime: The file $file is empty\n";
		&callTheMoveToReject($file);
	} else {
	# Move file from the staging directory to the processing directory.
	$retval = &callTheMoveToProcessing($file);
	$localtime = localtime();
	if (!$retval) {
		# The directory does not exist or some other error.
		&HandlerDie($FAIL_TO_MOVE_FILE, $current_poid);
	} elsif ($retval == -1) {
		if ($DEBUG) {
			print LOG "$PID: $localtime: FILES: ". basename ($file)." was "
			. "not found by the handler at "
			. "$localtime \n";
		}
		# If the move failed on a 'file not found' error, it means
		# another parallel handler took that file.  This handler
		# will try to get another file.
		next;
	}
	$moved_a_file = 1;
	#if ($DEBUG) {
		print LOG "$PID: $localtime: FILES: $file moved to the "
			. "processing directory at $localtime.\n";
	#}


	#
	# Check to see if the batch executable exists.
	if (! -e $pinMMSC) {
		print LOG "$PID: $localtime: ERROR: Executable for batch application does "
			. "not exist\n";
		&HandlerDie($NO_CRM_EXEC, $current_poid);
	}

	#
	# Start the batch application.
	#

	$localtime = localtime();
	#
	# Use the base filename.
	$just_name_file = basename ($file);
	$basefile = $PROCESSING."/".$just_name_file;
	if ($DEBUG) {
		print LOG "$PID: $localtime: FILES: $basefile\n";
	}
	#
	# If running under MSWindows...
	if ($^O =~ /win/i) {
		require Win32::Process;
		$cmd = $ENV{"COMSPEC"};
		$args = "$cmd /c \"cd $pinMMSCDir && $cmd /c "
			. basename($pinMMSC) . " -t " . $template
			. " " . $basefile . "\"";
		my $process;
		Win32::Process::Create($process,
			$cmd,
			$args,
			0,
			DETACHED_PROCESS,
			'.') || die "$$: Unable to start batch application.";

		# Record PID of batch application in the database.
#		&UpdatePIDBatchApplication(0, $current_poid);

		# Wait for the batch application to finish.
		$process->Wait(INFINITE);

		# Get the exit code and convert to a signed number.
		$process->GetExitCode($exitcode);
		my ($crmstatus) = &convertUnsignedToSignedInt($exitcode);
	}

	#
	# Else if running under some other operating system like Unix...
	else {
		$originalfile = $basefile;
		print LOG "originalfile : $originalfile \n";	
		$crmCmd = $pinMMSC . " " . $basefile;
                print LOG "command formed is : $crmCmd \n";
		$localtime = localtime();
		print LOG "$PID: $localtime: EXEC: $crmCmd \n";

		my $crmpid;
		if (!defined($crmpid = fork())) {
			die "$$: Cannot start batch application: $!";
		} elsif ($crmpid == 0) {
			$Command = "cd $pinMMSCDir; $crmCmd";
                	print LOG "exec command is : $Command \n";
			exec($Command);
			die "$$: Cannot execute batch application: $!";
		} else {
			# Record PID of batch application in the database.
	#		&UpdatePIDBatchApplication($crmpid, $current_poid);

			# Wait for the batch application to finish.
			waitpid($crmpid,0);

			# Get the exit code and convert to a signed number.
			$exitcode = ($? >> $UNIX_SHIFT);
			my ($crmstatus) = &convertUnsignedToSignedInt($exitcode);
		}
	}


	#
	# Log a debugging message in the handler log file.
	$localtime = localtime();
	$basefile = $just_name_file;
	#
	# Move files based on the return status.
	#

	# Form full pathname of file to be moved.
	$procfile = $PROCESSING . "/" . $basefile;
	print LOG "$PID: $localtime: FILES_OUT: ". basename ($procfile)." "
				. "processed with result $crmstatus \n";
	$localtime = localtime();
	if ($crmstatus == $NO_ERROR) {
		if ($DEBUG) {
			print LOG "$PID: $localtime: FILES_OUT: ". basename ($procfile)." "
				. "processed successfully by the "
				. "batch application at $localtime.\n";
		}
		&callTheMoveToArchive($procfile);
		&HandlerDie($COMPLETED_NO_ERROR, $current_poid);
	}

	elsif ($crmstatus == $FILE_CHECK_ERROR) {
		print LOG "$PID: $localtime: FILES_OUT: ". basename ($procfile)." was rejected "
			. "by the batch application at $localtime.\n";
		&callTheMoveToReject($procfile);
		&HandlerDie($REJECTED, $current_poid);
	}

	elsif ($crmstatus == $FIELD_PARSE_ERROR
		|| $crmstatus == $ACCT_FORMAT_ERROR
		|| $crmstatus == $LOAD_FORMAT_ERROR
		|| $crmstatus == $PREV_PARSE_ERROR
		|| $crmstatus == $TOO_MANY_LOAD_ERROR
		|| $crmstatus == $ACCT_OPCODE_ERROR
		|| $crmstatus == $LOAD_OPCODE_ERROR) {
		if ($DEBUG) {
			print LOG "$PID: $localtime: FILES_OUT: ". basename ($procfile)." was "
				. "processed by the batch application at "
				. "$localtime with errors.\n";
		}
		&callTheMoveToReject($procfile);
		&HandlerDie($WITH_ERROR, $current_poid);
	}

	elsif ($crmstatus == $MEMORY_ERROR
		|| $crmstatus == $DISK_SPACE_ERROR
		|| $crmstatus == $TEMPLATE_ERROR
		|| $crmstatus == $COMMAND_LINE_ARG_ERROR
		|| $crmstatus == $FILE_NOT_FOUND_ERROR
		|| $crmstatus == $BAD_INF_CONNECTION) {
		print LOG "$PID: $localtime: FILES_OUT: ". basename ($procfile)." was "
			. "not processed by the batch application at "
			. "$localtime.\n";
		&callTheMoveToReject($procfile);
		&HandlerDie($PILOT_ERROR, $current_poid);
	}

	else {
		print LOG "$PID: $localtime: Failed to start the batch application "
			. "at $localtime\n";
		print LOG "$PID: $localtime: ERROR:  Unexpected crm exit code: $crmstatus.\n";
		&callTheMoveToReject($procfile);
		&HandlerDie($FAIL_TO_START_CRM, $current_poid);
	}

	$localtime = localtime();
	print LOG "$PID: $localtime: FILES: ($file) Finished - file number: $num_files.\n";
	#
	# Break the foreach loop
	last;
	#next;
	}
}

# Make sure a file was moved.
if ($moved_a_file != 1)
{
	&HandlerDie($FAIL_TO_MOVE_FILE, $current_poid);
}

#
# This point should not be reached...
exit;



#
#------------------------------------------------------------------
# callTheMoveToProcessing - move the file from the staging directory to
# the processing directory.
#
# Parameter: the file name in the staging directory
#
# Returns: file not found or move failed = -1, any other failure = 0, success = 1
#
sub callTheMoveToProcessing {
	local($processingFile) = @_;
	if (! -e $processingFile) {
		print LOG "$PID: $localtime: MOVE: $processingFile does not exist.\n";
		return (-1);
	}
	if (! -d $PROCESSING) {
		print LOG "$PID: $localtime: MOVE: Processing directory $PROCESSING does "
			. "not exist.\n";
		return (0);
	}

	$ret = system("mv $processingFile $PROCESSING/$_"); 
	if ($ret != $NO_ERROR ) { 
		print LOG "$PID: $localtime: MOVE: Failed to move $processingFile to "
			. "$PROCESSING.\n"; 
		return (-1); # Could have been moved by another handler 
			# since these ops are non-atomic; 
			# this would not occur with other move subroutines                                                 
			# since they have a known file in use.
	} 
	if ($DEBUG) {
		print LOG "$PID: $localtime: MOVE1: $processingFile to $PROCESSING.\n";
	}
	return (1);
}


#
#------------------------------------------------------------------
# callTheMoveToArchive - move the file from the processing directory to
# the archive directory.
#
# Parameter: the file name in the processing directory
#
# Returns: failure = 0 and success = 1
#
sub callTheMoveToArchive {
	local($archiveFile) = @_;
	if (! -e $archiveFile) {
		print LOG "$PID: $localtime: $archiveFile does not exist.\n";
		return (0);
	}
	if (! -d $ARCHIVE) {
		if (!createPath($ARCHIVE, 0, 0755)) {
			print LOG "$PID: $localtime: MOVE: Failed to create archive directory "
				. "$ARCHIVE: $!\n";
			return (0);
		}
	}
	$ret = move "$archiveFile", "$ARCHIVE/$_";
	if ($ret != 1){
		print LOG "$PID: $localtime: MOVE: Failed to move $archiveFile to $ARCHIVE.\n";
		return (0);
	}
	if ($DEBUG){
		print LOG "$PID: $localtime: MOVE2: $archiveFile to $ARCHIVE.\n";
	}
	return (1);
}


#
#------------------------------------------------------------------
# callTheMoveToReject - move the file from the processing directory to
# the reject directory.
#
# Parameter: the file name in the processing directory
#
# Returns: failure = 0 and success = 1
#
sub callTheMoveToReject {
	local($rejectFile) = @_;
	if (! -e $rejectFile) {
		print LOG "$PID: $localtime: $rejectFile does not exist.\n";
		return (0);
	}
	if (! -d $REJECT) {
		if (!createPath($REJECT, 0, 0755)) {
			print LOG "$PID: $localtime: MOVE: Failed to create reject directory "
				. "$REJECT: $!\n";
			return (0);
		}
	}
	$ret = move "$rejectFile", "$REJECT/$_";
	if ($ret != 1) {
		print LOG "$PID: $localtime: MOVE: Failed to move $rejectFile to $REJECT.\n";
		return (0);
	}
	if ($DEBUG) {
		print LOG "$PID: $localtime: MOVE3: $rejectFile to $REJECT.\n";
	}
	return (1);
}

#
#------------------------------------------------------------------
# callTheMoveToStaging - move the file from the processing directory to
# the staging directory.
#
# Parameter: the file name in the processing directory
#
# Returns: failure = 0 and success = 1
#
sub callTheMoveToStaging {
	local($stagingFile) = @_;
	if (! -e $stagingFile) {
		print LOG "$PID: $localtime: MOVE: $stagingFile does not exist.\n";
		return (0);
	}
	if (! -d $STAGING) {
		print LOG "$PID: $localtime: MOVE: $STAGING does not exist.\n";
		return (0);
	}
	if (! -d $PROCESSING) {
		print LOG "$PID: $localtime: MOVE: $PROCESSING does not exist.\n";
		return (0);
	}
	if (!copy ($stagingFile, "$STAGING/$_")) {
		print LOG "$PID: $localtime: MOVE: Failed to copy $stagingFile to "
			. "the staging directory: $!\n";
		&HandlerDie($PILOT_ERROR, $current_poid);
	}
	if (!unlink($stagingFile, "$PROCESSING/$_")) {
		print LOG "$PID: $localtime: MOVE: Failed to unlink $stagingFile from "
			. "the processing directory: $!\n";
		&HandlerDie($PILOT_ERROR, $current_poid);
	}
	if ($DEBUG) {
		print LOG "$PID: $localtime: MOVE: Moved $stagingFile to $STAGING.\n";
	}
	return (1);
}

#
#
#------------------------------------------------------------------
# createPath - create the directory specified by the path arg, including
#	       all intermediate directories.
#
# Parameters:
#	$paths   -- either a path string or ref to list of paths
#	$verbose -- optional print "mkdir $path" for each directory created
#	$mode    -- optional permissions, defaults to 0777
#
# Returns: failure = 0 and success = 1
#
sub createPath {
	my($paths, $verbose, $mode) = @_;
	local($")="/";
	$mode = 0777 unless defined($mode);
	$paths = [$paths] unless ref $paths;
	my(@created,$path);
	foreach $path (@$paths) {
		next if -d $path;
		# Logic wants Unix paths, so go with the flow.
		$path = VMS::Filespec::unixify($path) if $Is_VMS;
		my $parent = File::Basename::dirname($path);
		push(@created, createPath($parent, $verbose, $mode))
			unless (-d $parent);
		print "mkdir $path\n" if $verbose;
		mkdir($path,$mode) || return 0;
		push(@created, $path);
	}
	@created;
}

#
#------------------------------------------------------------------
# HandlerDie - update the status object and exit.
#
sub HandlerDie() {
	$T_time = pcmif::pin_perl_time();
	local($status, $POID) = @_;

	# These are the SampleHandler exit codes.
	if ($status == $COMPLETED_NO_ERROR) {
		$exitval = 0;
	}
	elsif ($status == $WITH_ERROR) {
		$exitval = 2;
	}
	elsif ($status == $REJECTED) {
		$exitval = 3;
	}
	elsif ($status == $PILOT_ERROR) {
		$exitval = 4;
	}
	elsif ($status == $NO_FILE_TYPE) {
		$exitval = 5;
	}
	elsif ($status == $FAIL_TO_MOVE_FILE) {
		$exitval = 6;
	}
	elsif ($status == $NO_CRM_EXEC) {
		$exitval = 7;
	}



	# Terminate this handler application.
	if ($DEBUG_2) {
		print LOG "$PID: $localtime: EXIT: Handler completed operations, exiting...\n";
	}
	exit($exitval);



#
#------------------------------------------------------------------
# Usage: Print usage message and exit.
sub usage {
	print STDERR "Usage: $0 -p <hander_poid> { -d <dead_handler_poid> }\n";
	exit(-1);
}


#
#------------------------------------------------------------------
# Find the oldest file.
#
sub byage {
	$age{$b}<=>$age{$a}
}

#
#------------------------------------------------------------------
# Convert the unsigned int to signed value.
#
sub convertUnsignedToSignedInt {
	local($exitcode) = @_;

	if ($^O =~/win/i) {
		# Number of bits in NT other than the sign bit
		$valueBitLength = 31;
		# Decimal for binary 1 followed by 31 zeroes
		$decrementValue = 4294967296;
	}
	else {
		# Number of bits in Unix other than the sign bit
		$valueBitLength = 7;
		# Decimal for binary 1 followed by 7 zeroes
		$decrementValue = 256;
	}

	$lastBit = $exitcode >> $valueBitLength;
	if ($lastBit == 1) {
		$crmstatus = ($exitcode - $decrementValue);
	}
	else {
		$crmstatus = $exitcode;
	}
	return ($crmstatus);
}
}