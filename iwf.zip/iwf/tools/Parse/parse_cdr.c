#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include "pin_errs.h"
#include "pcm.h"
#include "pinlog.h"

#define FILE_PATH               "file_path"
#define FILE_NAME               "file_name"
char                    *default_value_string;
	char 			  * default_value_number;

void cdr_analyze(char *data, FILE *cdrFp)
{
	char	*r;
        char    *r1;
        char	*frame;
        char	*in_frame;
        char	cdr_data1[2048];
        char	cdr_data[2048];
        char	temp[10];
	char    *tempDi;

	char    preTemp[10];
        char	record[20];
        char	delimit[10];
	int     flag=0;
	
	memset( cdr_data, 0, sizeof(cdr_data) );
	memset( record, 0, sizeof(record) );
	memset( temp, 0, sizeof(temp) );
	memset( delimit, 0, sizeof(delimit) );

	/*******************************************************************
        *
	* Check the record is Orecord or Rrecord.
	* If The record is Orecord append ORECORD to the cdr_data
	* else append RRECORD to the cdr_data
	*
	********************************************************************/
	if((strstr(data, "Orecord")) != NULL)
	{
		strncpy(record, "ORECORD", strlen("ORECORD"));
		strncpy(delimit, ":", strlen(":"));
	}
	else{
		strncpy(record, "RRECORD", strlen("RRECORD"));
		strncpy(delimit, "%", strlen("%"));
	}
	strcat(cdr_data, record);
	strcat(cdr_data, delimit);

	/*******************************************************************
        *
	* Tokenize the input data with = sign. Then Tokenize input with / 
	* which will gets the original data
	*
	********************************************************************/
	if ( (frame = (char *) strtok_r (data, "=", &r)) != NULL )
        {
		if( (in_frame = (char *) strtok_r (r, "/", &r)) != NULL )
		{
			strcat(cdr_data, in_frame);
		}
	}

	/*******************************************************************
        *
	* While input string not equals to null, Tokenize the input data 
	* with = sign. Then Tokenize input with /  which will gets the 
	* original data.
	*
	********************************************************************/
	while(r!= NULL){
		if ( (frame = (char *) strtok_r (r, "=", &r)) != NULL )
		{
			strncpy(preTemp,frame,8);
			preTemp[8]='\0';

			if(r!=NULL)
			{	
				if(*r == '/')
				{
					r1= malloc(strlen(r)+1);
					*r1=' ';
					strcpy(r1+1,r);
					r=malloc(strlen(r1)+1);
					strcpy(r,r1);
				}
			}
			if( (in_frame = (char *) strtok_r (r, "/", &r)) != NULL )
			{
				//The following two if conditions will capture multiple "di"s in tempDi delimited by '-'
				if(((strstr(frame,")di"))!= NULL) && flag==1)
                                {
					tempDi=realloc(tempDi,strlen(tempDi)+2);	
                                        strcat(tempDi,"-");
				
					tempDi=realloc(tempDi,strlen(in_frame)+strlen(tempDi)+1);	
                                        strcat(tempDi,in_frame);
                                }
				if(((strstr(frame,")di"))!= NULL)  && flag==0)
				{
					tempDi=malloc(strlen(in_frame)+1);
					//strcat(tempDi,in_frame);	
					strcpy(tempDi,in_frame);	
					flag=1;
				}
				if( strstr(frame,")di") == NULL)
				{
					strcat(cdr_data, delimit);
					strcat(cdr_data, in_frame);

				}
				
				if(r!=NULL)
				{
					strncpy(temp, r, 6);
					temp[6]='\0';
				}

	

				/*******************************************************************
				*
				* Check the tokenized string contains ")mo or not.
				* If contains,  Tokenize the input data with = sign. Then Tokenize 
				* input with ( which will gets the original data. This is because 
				* mo(message contects) some spaces and equal sign as part of data.
				*
				********************************************************************/
				if((strstr(temp, ")mo")) != NULL)
				{
					if( (in_frame = (char *) strtok_r (r, "=", &r)) != NULL )
					{
						if( (in_frame = (char *) strtok_r (r, "(", &r)) != NULL )
						{
							strcat(cdr_data, delimit);
							strncat(cdr_data, in_frame, strlen(in_frame)-1);
						}
					}
				}
				if((strstr(temp,")di"))  != NULL )
				{
					if(((strstr(preTemp ,")ri")) == NULL) && flag==0)
					{
					    strcat(cdr_data, delimit);
					    strcat(cdr_data, default_value_string);
					}


				}
				 if((strstr(temp,")in"))  != NULL  && strstr(delimit,"%")!=NULL)
                                {
                                        if((strstr(preTemp ,"nn")) == NULL)
                                        {
                                            strcat(cdr_data, delimit);
				            strcat(cdr_data,default_value_number); 
                                        }


                                }
				if((strstr(temp,")li"))  != NULL) 
                                {
                                        if((strstr(preTemp ,")or")) == NULL)
                                        {
                                            strcat(cdr_data, delimit);
				            strcat(cdr_data, default_value_string);
                                        }


                                }

				
				if((strstr(temp,")go"))  != NULL )
                                {
                                        if((strstr(preTemp ,")di")) == NULL)
                                        {
						if((strstr(preTemp ,")ri")) == NULL)
						{
							    strcat(cdr_data, delimit);
							    strcat(cdr_data, default_value_string);
						}
                                        strcat(cdr_data, delimit);
					strcat(cdr_data, default_value_string);
                                        }
					else
					{
					    strcat(cdr_data, delimit);
					    strcat(cdr_data, tempDi);
					    free(tempDi);
	
					}


                                }
			}
			

			if(r!=NULL)
			{
			if( strlen(r) == 0 )
			{
				r = NULL;
			}
			}
		}
	}
	
        sprintf(cdr_data1, "%s\n",cdr_data);

	if( fwrite( cdr_data1, strlen(cdr_data1), 1, cdrFp) == 0 ){
                fprintf(stdout,"\nUnable to write to file\n");
                exit(-1);
	}
}

int
main(argc, argv)
        int                     argc;
        char                    *argv[];
{
	FILE 			*fp;
	FILE 			*cdrFp;
	char			data[2048];
	char			filename[200];
	char			outfile[250];
	char			ch;
	char			*r;
        char			*outframe;
	char                    *out_file = NULL;
        char                    filepath[200];
//	char                    suffix[10];
	char			prefix[10];
	char            	mv_file[1024];
	char            	targetfile[1024];
        int32                   err = PIN_ERR_NONE;
	int			i = 0;
	pin_errbuf_t    	ebufp;

	char                    logfile[256];
	int32                   level;

	

	if(argc != 2)
	{
		fprintf(stdout,"\nUsage: \n\t%s %s \n\n","parse_cdr","Inputfile");
		exit(-1);
	}
	strcpy(logfile, "default.pinlog");
	level = PIN_ERR_LEVEL_DEBUG;

	PIN_ERR_SET_LOGFILE(logfile);
        PIN_ERR_SET_LEVEL(level);

	/************************************************************
        * Read the file path value from pin.conf
        *************************************************************/
        memset(filepath, 0, sizeof(filepath));
        pin_conf( (char*)FILE_PATH, (char *)"outfile", PIN_FLDT_STR,
                (caddr_t*)&out_file, &err);
         if (out_file != (char *) NULL) {
                strcpy(filepath, out_file);
                free(out_file);
         } else{
                strcpy(filepath, ".");
        }

	/************************************************************
        * Read default_value_string from pin.conf
        *************************************************************/
        PIN_ERRBUF_CLEAR(& ebufp);

        pin_conf( (char*)FILE_PATH, (char *)"default_value_string", PIN_FLDT_STR,
                (caddr_t*)&default_value_string, &err);

	
	if (err != PIN_ERR_NONE) {
                ebufp.pin_err = err;
        }
	

        if (PIN_ERR_IS_ERR( & ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_DEBUG,
                        "default_value_string is set to the default value",  & ebufp);
                if(ebufp.pin_err == PIN_ERR_NOT_FOUND)
                {
			
			default_value_string = malloc(2);
                      strcpy(default_value_string," ");
                        
                      PIN_ERRBUF_CLEAR(& ebufp);

                }
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "default_value_string is: %s\n",default_value_string);
        }


        /************************************************************
        * Read default_value_number from pin.conf
        *************************************************************/
	err = PIN_ERR_NONE;
        PIN_ERRBUF_CLEAR(& ebufp);

        pin_conf( (char*)FILE_PATH, (char *)"default_value_number", PIN_FLDT_STR,
                (caddr_t*)& default_value_number, &err);

	
        if (err != PIN_ERR_NONE) {
                ebufp.pin_err = err;
        }
	

        if (PIN_ERR_IS_ERR( & ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_DEBUG,
                        "default_value_number is set to the default value",  & ebufp);
                if(ebufp.pin_err == PIN_ERR_NOT_FOUND)
                {

			 default_value_number = malloc(2);
                      strcpy(default_value_number,"0");

                      PIN_ERRBUF_CLEAR(& ebufp)

                }
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "default_value_number is: %s\n", default_value_number);
        }

	/************************************************************
        * Read the file suffix value from pin.conf
        *************************************************************/
       /* memset(suffix, 0, sizeof(suffix));
        pin_conf( (char*)FILE_NAME, (char *)"suffix", PIN_FLDT_STR,
                (caddr_t*)&out_file, &err);
         if (out_file != (char *) NULL) {
                strcpy(suffix, out_file);
                free(out_file);
         } else{
                strcpy(suffix, ".edr");
        }*/

	/************************************************************
        * Read the file temporary prefix value from pin.conf
        *************************************************************/
	//memset(prefix, 0, sizeof(prefix));
        pin_conf( (char*)FILE_PATH, (char *)"temporaryprefix", PIN_FLDT_STR,
                (caddr_t*)&out_file, &err);
         if (out_file != (char *) NULL){
		strcpy(prefix,out_file);	
	 }
	 else {
                strcpy(prefix, "tmp");
       	 } 

	memset(data, 0, sizeof(data));
	memset(filename, 0, sizeof(filename));
	if(argv[1] != NULL)
	{
		strncpy(filename, argv[1], strlen(argv[1]));
	}

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,filename);

	fp = fopen(filename, "r");
        if (fp == NULL) {
                fprintf(stdout,"\nUnable to open file\n");
                fprintf(stdout,"\nExiting... \n\n");
                exit(-1);
        }

	if ( (outframe = (char *) strtok_r (filename, "/", &r)) != NULL )
	{
		;
	}
	while(r!= NULL){
		if ( (outframe = (char *) strtok_r (r, "/", &r)) != NULL )
		{
			;
		}
	}
/*	if ( (outframe = (char *) strtok_r (outframe, ".", &r)) != NULL )
	{
		;
	}*/

	
//	sprintf(outfile, "%s%s%s%s", filepath, "/",outframe, suffix);
	memset(outfile,0,sizeof(outfile));
	sprintf(outfile, "%s%s%s%s", filepath,"/",prefix,outframe);
	sprintf(targetfile, "%s%s%s", filepath, "/", outframe);

	cdrFp = fopen(outfile, "a+");
        if (cdrFp == NULL) 
	{
                fprintf(stdout,"\nUnable to open file\n");
                fprintf(stdout,"\nExiting... \n\n");
                exit(-1);
        }
	while(( ch = getc(fp) ) != EOF )
	{
		if( ch != '\n' )
		{
		 data[i++] = ch;
		}
		else
		{
		 	data[i++] = '\0';
			cdr_analyze(data, cdrFp);
			memset(data, 0, sizeof(data));
			i = 0;
		}
	}
	fclose(fp);
	fclose(cdrFp);
        sprintf(mv_file, "%s %s %s", "mv ", outfile, targetfile);
        system(mv_file);
	return 0;
}
