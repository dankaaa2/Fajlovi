#!/bin/ksh
# Script starts tap scheduler for all Roaming Partners
#

ORACLE_HOME=/opt/oracle/product/9.2.0
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

echo "Staring tap scheduler for all commercial Roaming Partners (YUGTM) ... "
date

cp /opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler.conf.YUGTM /opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler.conf

/opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler_YUGTM.sh

echo "Staring tap scheduler for all commercial Roaming Partners (MNETM) ... "
date

cp /opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler.conf.MNETM /opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler.conf

/opt/portal/ifw/custom/tools/tap_scheduler/tap_scheduler_MNETM.sh

