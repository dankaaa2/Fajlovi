#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Start TAP files creation
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Robert Frydrych
#
#  $RCSfile: tap_scheduler.sh,v $
#  $Revision: 1.3 $
#  $Author: pin $
#  $Date: 2009/12/08 12:29:41 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: tap_scheduler.sh,v 1.3 2009/12/08 12:29:41 pin Exp $
#  $Log: tap_scheduler.sh,v $
#  Revision 1.3  2009/12/08 12:29:41  pin
#  Mantis ID:2407
#  Problem nastao zbog pogresne kreacije RP u dijelu koje se odnosi na TAP i IMSi kod
#  usljed cega su se pojavili "netacni" rekordi za te RP-e
#
#  Revision 1.2  2005/11/11 09:49:08  pin09
#  MantisID: 973
#  Committed by RBF
#  added options for operator mode
#
#  Revision 1.1  2005/09/05 21:09:29  pin09
#  RBF: Initial release
#
# ==============================================================================

exec 2>&1

DATE_FORMAT="YYYYMMDDHH24MISS"

TIMESTAMP=`date +%Y%m%d%H%M%S`

#script name and directory
EXEC=${0}
PARAMS=${*}
PRG=${EXEC##*/}
BASE=${PRG%.*}
ORIG=${PWD}
DIR=${EXEC%/*}
if [[ "${DIR}" = "${EXEC}" || "${DIR}" = "" ]];
then
  DIR=.
fi

#variables for file names build
FILE_SUFFIX='_'${TIMESTAMP}

LOGIN_DENIED="ORA-01017"
FILE_ERROR="ORA-200"
ORA_ERROR="ORA-"
CONNECT="Connected."
SQLOUT=""

function UsageIs {
  echo "Usage is:" | tee -a ${LOG_FILE}
  echo "${PRG}" | tee -a ${LOG_FILE}
  echo "     -all [-c|-t] |" | tee -a ${LOG_FILE}
  echo "     -o operator |" | tee -a ${LOG_FILE}
  echo "     -ef export_tap_filename" | tee -a ${LOG_FILE}
  echo "" | tee -a ${LOG_FILE}
  echo "Note: Only one option can be used at a time" | tee -a ${LOG_FILE}
  echo "      When scheduling all operators" | tee -a ${LOG_FILE}
  echo "      optional mode (Commercial|Test) can be used" | tee -a ${LOG_FILE}
  echo "" | tee -a ${LOG_FILE}

  Exit 0
}

function Exit {
  EXIT=0

  if [ $# != 0 ];
  then
    EXIT=${1}
  fi

  case ${EXIT} in
    (0)
      echo 'I '`date` "${PRG} successfully finished" | tee -a ${LOG_FILE}
      ;;
    (1)
      echo 'I '`date` "${PRG} terminated by user" | tee -a ${LOG_FILE}
      ;;
    (2)
      echo 'I '`date` "${PRG} finished with configuration error" | tee -a ${LOG_FILE}
      ;;
    (3)
      echo 'I '`date` "${PRG} finished with database error: ${2}" | tee -a ${LOG_FILE}
      ;;
    (*)
      echo 'I '`date` "${PRG} finished with errors" | tee -a ${LOG_FILE}
      ;;
  esac

  exit ${EXIT}
}

trap "echo Exiting...; Exit 1" 1 2 15

function RunSQL {
  SQLOUT=`echo "
CONNECT ${ORACLE_USER}/${ORACLE_PASSWD}@${ORACLE_SID}
--SET HEADING OFF
--SET FEEDBACK OFF
--SET PAGES 0
VAR exit_code VARCHAR2(256)
BEGIN
  :exit_code := '';
  ${1};
EXCEPTION
  WHEN OTHERS THEN
  :exit_code := SQLERRM;
END;
/
SET TERMOUT ON
PRINT exit_code" | sqlplus -S /nolog`
  SQLOUT=`echo "${SQLOUT}" | grep -v ${CONNECT}`
}

function RunSQLSelect {
  SQLOUT=`echo "
CONNECT ${ORACLE_USER}/${ORACLE_PASSWD}@${ORACLE_SID}
--SET HEADING OFF
--SET FEEDBACK OFF
--SET PAGES 0
${1};" | sqlplus -S /nolog`
  SQLOUT=`echo "${SQLOUT}" | grep -v ${CONNECT}`
}

function MvFile {
  mv ${1}/${2} ${1}/${3#${TMP_PREFIX}}
  if [ $? != 0 ];
  then
    echo 'E '`date` "Cannot rename the file - ${2}" | tee -a ${LOG_FILE}
    Exit 9
  else
    echo 'I '`date` "File created - ${3#${TMP_PREFIX}}" | tee -a ${LOG_FILE}
  fi
#  Exit 0
}

# define config file
CONFIG_EXT="conf"
CONFIG_FILE="${DIR}/${BASE}.${CONFIG_EXT}"
LOG_EXT="log"
DEFAULT_LOG_FILE="${DIR}/${BASE}.${LOG_EXT}"
LOG_FILE=${DEFAULT_LOG_FILE}

####################################################################
# Check and initialize parameters
####################################################################
#### Search for config file
if [ ! -r "${CONFIG_FILE}" ];
then
  echo 'E '`date` Cannot open file ${CONFIG_FILE}! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Log file
LOG_FILE=`grep ^LOG_FILE ${CONFIG_FILE} | awk '{print $2}'`
if [ "${LOG_FILE}" = "" ]
then
  echo 'W '`date` "Configuration parameter LOG_FILE not set (use default)!" | tee -a ${LOG_FILE}
#  LOG_FILE=${DEFAULT_LOG_FILE}
fi

#### Get Oracle user
ORACLE_USER=`grep ^ORACLE_USER ${CONFIG_FILE} | awk '{print $2}'`
if [ "${ORACLE_USER}" = "" ]
then
  echo 'E '`date` Variable ORACLE_USER not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_USER
fi

#### Get Oracle password
ORACLE_PASSWD=`grep ^ORACLE_PASSWD ${CONFIG_FILE} | awk '{print $2}'`
if [ "${ORACLE_PASSWD}" = "" ]
then
  echo 'E '`date` Variable ORACLE_PASSWD not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_PASSWD
fi

#### Get Oracle SID
ORACLE_SID=`grep ^ORACLE_SID ${CONFIG_FILE} | awk '{print $2}'`
if [ "${ORACLE_SID}" = "" ]
then
  echo 'E '`date` Variable ORACLE_SID not set! | tee -a ${LOG_FILE}
  Exit 2
else
  export ORACLE_SID
fi

#### Get INPUT DIR
INPUT_DIR=`grep ^INPUT_DIR ${CONFIG_FILE} | awk '{print $2}'`
if [ "${INPUT_DIR}" = "" ]
then
  echo 'E '`date` Variable INPUT_DIR not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get OUTPUT DIR
OUTPUT_DIR=`grep ^OUTPUT_DIR ${CONFIG_FILE} | awk '{print $2}'`
if [ "${OUTPUT_DIR}" = "" ]
then
  echo 'E '`date` Variable OUTPUT_DIR not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get DB DIR
DB_DIR=`grep ^DB_DIR ${CONFIG_FILE} | awk '{print $2}'`
if [ "${DB_DIR}" = "" ]
then
  echo 'E '`date` Variable DB_DIR not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#variables for file_name build
#### Get TMP PREFIX
TMP_PREFIX=`grep ^TMP_PREFIX ${CONFIG_FILE} | awk '{print $2}'`
if [ "${TMP_PREFIX}" = "" ]
then
  echo 'E '`date` Variable TMP_PREFIX not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get FILE PREFIX
FILE_PREFIX=`grep ^FILE_PREFIX ${CONFIG_FILE} | awk '{print $2}'`
if [ "${FILE_PREFIX}" = "" ]
then
  echo 'E '`date` Variable FILE_PREFIX not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get HPLMN
HPLMN=`grep ^HPLMN ${CONFIG_FILE} | awk '{print $2}'`
if [ "${HPLMN}" = "" ]
then
  echo 'E '`date` Variable HPLMN not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get RECORD_TYPE
RECORD_TYPE=`grep ^RECORD_TYPE ${CONFIG_FILE} | awk '{print $2}'`
if [ "${RECORD_TYPE}" = "" ]
then
  echo 'E '`date` Variable RECORD_TYPE not set! | tee -a ${LOG_FILE}
  Exit 2
fi

#### Get SEP
SEP=`grep ^SEP ${CONFIG_FILE} | awk '{print $2}'`
if [ "${SEP}" = "" ]
then
  echo 'E '`date` Variable SEP not set! | tee -a ${LOG_FILE}
  Exit 2
fi

####################################################################
# Main program
####################################################################
cd ${DIR}
echo "" >> $LOG_FILE
PID=$$
echo 'I '`date` "${PRG} started with PID ${PID}" | tee -a  ${LOG_FILE}
echo 'I '`date` "executed as ${EXEC} ${PARAMS}" >> ${LOG_FILE}
echo 'I '`date` "from ${ORIG}" >> ${LOG_FILE}

case ${1} in
  (-o)
  if [ -z "${2}" ];
  then
    UsageIs
  else
    #create new file for HEADER
    FILE_NAME=${TMP_PREFIX}${FILE_PREFIX}D${HPLMN}${2}${FILE_SUFFIX}
    GMT_TIMESTAMP=`date -u +%Y%m%d%H%M%S`
    echo "${RECORD_TYPE}${SEP}${HPLMN}${SEP}${2}${SEP}${SEP}${SEP}${GMT_TIMESTAMP}" > ${INPUT_DIR}/${FILE_NAME}

    if [ $? != 0 ];
    then
      echo 'E '`date` "Error while creating file for ${2}" | tee -a ${LOG_FILE}
      Exit 9
    else
      MvFile ${INPUT_DIR} ${FILE_NAME} ${FILE_NAME}
    fi
  fi
  ;;
  (-all)
  #Query roaming partners TADIG names and execute self with -o 
  case ${2} in
    (-c)
    PROC="SELECT sal.name
            FROM service_t s,
                 service_alias_list_t sal,
                 account_t a,
                 profile_t p,
                 profile_t p2,
                 profile_customer_care_t pcc,
                 profile_acct_extrating_data_t paed,
                 device_t d
           WHERE -- Portal table join --
                 s.account_obj_id0 = a.poid_id0
             AND sal.obj_id0 = s.poid_id0
             AND pcc.obj_id0 = p.poid_id0
             AND paed.obj_id0 = p2.poid_id0
             AND p.account_obj_id0 = a.poid_id0
             AND p2.account_obj_id0 = a.poid_id0
                 -- Portal table join --
             AND paed.name = 'Mode  (T / C)'
             AND paed.value = 'C'
             AND pcc.customer_type = '10'  -- custom_define.h : #define ACC_TYPE_ROAMING 10
             AND s.poid_type = '/service/telco/gsm/telephony'
             AND d.device_id = sal.name
             AND d.poid_type = '/device/num'
             AND d.state_id  in (1,2)"
    ;;
    (-t)
    PROC="SELECT sal.name
            FROM service_t s,
                 service_alias_list_t sal,
                 account_t a,
                 profile_t p,
                 profile_t p2,
                 profile_customer_care_t pcc,
                 profile_acct_extrating_data_t paed,
                 device_t d
           WHERE -- Portal table join --
                 s.account_obj_id0 = a.poid_id0
             AND sal.obj_id0 = s.poid_id0
             AND pcc.obj_id0 = p.poid_id0
             AND paed.obj_id0 = p2.poid_id0
             AND p.account_obj_id0 = a.poid_id0
             AND p2.account_obj_id0 = a.poid_id0
                 -- Portal table join --
             AND paed.name = 'Mode  (T / C)'
             AND paed.value = 'T'
             AND pcc.customer_type = '10'  -- custom_define.h : #define ACC_TYPE_ROAMING 10
             AND s.poid_type = '/service/telco/gsm/telephony'
             AND d.device_id = sal.name
             AND d.poid_type = '/device/num'
             AND d.state_id  in (1,2)"
    ;;
    (*)
    PROC="SELECT sal.name
            FROM service_t s,
                 service_alias_list_t sal,
                 account_t a,
                 profile_t p,
                 profile_customer_care_t pcc,
                 device_t d
           WHERE -- Portal table join --
                 s.account_obj_id0 = a.poid_id0
             AND sal.obj_id0 = s.poid_id0
             AND pcc.obj_id0 = p.poid_id0
             AND p.account_obj_id0 = a.poid_id0
                 -- Portal table join --
             AND pcc.customer_type = '10'  -- custom_define.h : #define ACC_TYPE_ROAMING 10
             AND s.poid_type = '/service/telco/gsm/telephony'
             AND d.device_id = sal.name
             AND d.poid_type = '/device/num'
             AND d.state_id  in (1,2)"
    ;;
  esac

  RunSQLSelect "${PROC}"

  if [ "${SQLOUT}" ];
  then
    if [[  `echo "${SQLOUT}" | grep ${ORA_ERROR}` != "" ]];
    then
      if [[  `echo "${SQLOUT}" | grep ${LOGIN_DENIED}` != "" ]];
      then
        echo 'E '`date` "Login denied - check database connection" | tee -a ${LOG_FILE}
      else
        echo 'E '`date` "Error while executing ${PROC} - database error: ${SQLOUT}" | tee -a ${LOG_FILE}
      fi
      Exit 3 "${SQLOUT}"
    else
      COUNTER=0
      for OPER in $SQLOUT
      do
        ${EXEC} -o $OPER
        ((COUNTER=${COUNTER}+1))
      done
      echo 'I '`date` "Executed for ${COUNTER} roaming partner(s)" | tee -a ${LOG_FILE}
    fi
  else
    echo 'I '`date` "Roaming partners not configured" | tee -a ${LOG_FILE}
  fi
  ;;
  (-ef)
  if [ -z "${2}" ];
  then
    UsageIs
  else
    #Create TAP_FILENAME
    FILE_NAME=${2##*/}
    SEQ=${FILE_NAME##*_}
    DB_FILENAME=${FILE_NAME%_*}
    FILE_BASE=${DB_FILENAME%_*}
    TAP_FILENAME=${FILE_BASE#${TMP_PREFIX}${FILE_PREFIX}}${SEQ}

    #set the rights
    chmod 666 ${OUTPUT_DIR}/${FILE_NAME}

    #run SQL
    PROC="tap_scheduler.schedule_file('${DB_DIR}','${FILE_NAME}','${DB_FILENAME}','${TAP_FILENAME}')"
    RunSQL ${PROC}

    #check SQL error code and rename the file
    if [ "${SQLOUT}" = "" ];
    then
      MvFile ${OUTPUT_DIR} ${FILE_NAME} ${FILE_BASE}${SEQ}
    else
      if [[  `echo "${SQLOUT}" | grep ${LOGIN_DENIED}` != "" ]];
      then
        echo 'E '`date` "Login denied - check database connection" | tee -a ${LOG_FILE}
      elif [[  `echo "${SQLOUT}" | grep ${FILE_ERROR}` != "" ]];
      then
        echo 'E '`date` "Cannot extract to file ${FILE_NAME} - check configuration" | tee -a ${LOG_FILE}
      else
        echo 'E '`date` "Error while extracting to file ${FILE_NAME}" | tee -a ${LOG_FILE}
      fi
      Exit 3 "${SQLOUT}"
    fi
  fi
  ;;
  (*)
    UsageIs
  ;;
esac

Exit 0

