#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Create necessary data directories
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible:
#
#  $RCSfile: createData.sh,v $
#  $Revision: 1.27 $
#  $Author: pin06 $
#  $Date: 2013/05/10 09:20:32 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: createData.sh,v 1.27 2013/05/10 09:20:32 pin06 Exp $
#  $Log: createData.sh,v $
#  Revision 1.27  2013/05/10 09:20:32  pin06
#  MantisID:0002563 ePC Mediation
#
#  Revision 1.26  2012/08/20 10:39:09  pin09
#  0002490: MiO downloader
#
#  Revision 1.25  2010/11/23 08:39:47  pin09
#  0002453: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with SDP_PARSE pipeline
#
#  Revision 1.24  2010/11/15 10:36:29  pin09
#  0002451: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with CCN40_PARSE pipeline
#
#  Revision 1.23  2010/10/28 07:48:58  pin09
#  0002450: Prepaid system upgrade CS4.0 - Setting up mediationDWH40 framework with AIR_PARSE pipeline
#
#  Revision 1.22  2008/08/06 12:10:54  pin26
#  MantisID: 2343
#  Committed by RBF
#  added Starhome
#
#  Revision 1.21  2008/04/18 08:11:09  pin02
#  0002334: Modification of mediation due to DWH requests
#
#  Revision 1.20  2007/10/18 08:45:41  pin35
#  0002313: Configuring mediation framework to include SGSN3G pipeline
#
#  Revision 1.19  2007/09/26 11:50:30  pin03
#  0002311: Configuring mediation framework to include GGSN3G pipeline
#
#  Revision 1.18  2007/09/25 12:40:46  pin03
#  0002310: Configuration of SGSN3G and GGSN3G downloaders
#
#  Revision 1.17  2007/09/20 13:21:56  pin03
#  MantisID:0002308 Added directories TAP_IN_VALIDATE/TEST and TAP_IN_VALIDATE/TEST/BIHMS
#
#  Revision 1.16  2007/06/12 08:30:03  pin17
#  Mantis 0002290: Added data directories for MSCT3G_PARSE, SGSNT3G_PARSE and GGSNT3G_PARSE pipelines
#
#  Revision 1.15  2007/04/26 10:59:38  pin23
#  Mantis case 0002283: Configuration of Trial SGSN and Trial GGSN downloaders
#
#  Revision 1.14  2006/03/09 13:37:37  pin09
#  MantisID: 1759
#  Committed by RBF
#  added HUR
#
#  Revision 1.13  2006/02/20 10:23:30  pin09
#  MantisID: 1348
#  Committed by RBF
#  added aggregation
#
#  Revision 1.12  2005/09/15 18:46:38  pin09
#  RBF: added FTAM MSC directory
#
#  Revision 1.11  2005/09/15 18:28:11  pin09
#  RBF: added FTAM directory
#
#  Revision 1.10  2005/09/12 11:28:44  pin09
#  RBF: mkdir -p
#
#  Revision 1.9  2005/09/12 10:20:57  pin09
#  RBF: added FTP directories and input directory parameter
#
#  Revision 1.8  2005/08/25 16:09:08  pin
#  wkoko: production update
#
#  Revision 1.7  2005/08/19 14:36:35  pin09
#  RBF: added TAPout stream and MMS PreParser
#
#  Revision 1.6  2005/07/25 14:12:40  pin09
#  RBF: added aged directories for correlation
#
#  Revision 1.5  2005/07/06 18:12:22  pin09
#  RBF: added TAPin stream
#
#  Revision 1.4  2005/05/17 17:30:44  pin09
#  RBF: New pipelines
#
#  Revision 1.3  2005/05/11 16:15:15  pin09
#  Rating pipelines renaming
#
#  Revision 1.2  2005/04/20 12:27:35  pin27
#  Added data/balance path:wkokorzy
#
#  Revision 1.1  2005/03/30 13:11:49  pin09
#  RBF: Initial release
#
# ==============================================================================

COUNTER=0

function CreateDir {
  DIR=${1}
  if [ ! -d ${DIR} ]; then
    mkdir -p ${DIR}
    ((COUNTER=${COUNTER}+1))
  fi
}

function CreateLink {
  DIR=${1}
  if [[ $# = 1 ]]; then
    LINK=${1##*/}
  else
    LINK=${2}
  fi
  if [ ! -L ${LINK} ]; then
    ln -s ${DIR} ${LINK}
    ((COUNTER=${COUNTER}+1))
  fi
}

if [ -d "${1}" ];
then
  cd ${1}
fi

CreateDir data
CreateDir data/tam
CreateDir data/FTAM
CreateDir data/FTAM/MSC
CreateDir data/FTP
CreateDir data/FTP/CGSN
CreateDir data/FTP/MMSC
#Added directiores for MiO
CreateDir data/FTP/MiO
CreateDir data/FTP/MiO/tmp
CreateDir data/FTP/MiO/ready
#Added for new network element SGSNePC
CreateDir data/FTP/SGSN_ePC
CreateDir data/FTP/SGSN_ePC/ready
CreateDir data/FTP/SGSN_ePC/tmp
#End SGSNTePC
#Added for new network element SGSNT3G
CreateDir data/FTP/SGSNT3G
CreateDir data/FTP/SGSNT3G/in
CreateDir data/FTP/SGSNT3G/temp
#End SGSNT3G
#Added for new network element GGSNePC
CreateDir data/FTP/GGSN_ePC
CreateDir data/FTP/GGSN_ePC/ready
CreateDir data/FTP/GGSN_ePC/tmp
#End GGSNePC
#Added for new network element GGSNT3G
CreateDir data/FTP/GGSNT3G
CreateDir data/FTP/GGSNT3G/in
CreateDir data/FTP/GGSNT3G/temp
#End GGSNT3G
#Added for new network element SGSN3G
CreateDir data/FTP/SGSN3G
CreateDir data/FTP/SGSN3G/in
CreateDir data/FTP/SGSN3G/temp
#End SGSN3G
#Added for new network element GGSN3G
CreateDir data/FTP/GGSN3G
CreateDir data/FTP/GGSN3G/in
CreateDir data/FTP/GGSN3G/temp
#End GGSNT3G
CreateDir data/mms_pre_parse
CreateDir data/mms_pre_parse/mmsc
CreateDir data/mms_pre_parse/in
CreateDir data/mms_pre_parse/done
CreateDir data/mms_pre_parse/err
CreateDir data/MSC_PARSE
CreateDir data/MSC_PARSE/in
CreateDir data/MSC_PARSE/done
CreateDir data/MSC_PARSE/err
CreateDir data/MSC_PARSE/rej
#Added data directories for MSCT3G_PARSE
CreateDir data/MSCT3G_PARSE
CreateDir data/MSCT3G_PARSE/in
CreateDir data/MSCT3G_PARSE/done
CreateDir data/MSCT3G_PARSE/err
CreateDir data/MSCT3G_PARSE/rej
#End of MSCT3G_PARSE
CreateDir data/MSC_VALIDATE
CreateDir data/MSC_VALIDATE/in
CreateDir data/MSC_VALIDATE/done
CreateDir data/MSC_VALIDATE/err
CreateDir data/MSC_VALIDATE/rej
CreateDir data/MSC_VALIDATE/dup
CreateDir data/MSC_ASSEMBLE
CreateDir data/MSC_ASSEMBLE/in
CreateDir data/MSC_ASSEMBLE/done
CreateDir data/MSC_ASSEMBLE/err
CreateDir data/MSC_ASSEMBLE/rej
CreateDir data/MSC_ASSEMBLE/ass
CreateDir data/CGSN_PARSE
CreateDir data/CGSN_PARSE/in
CreateDir data/CGSN_PARSE/done
CreateDir data/CGSN_PARSE/err
CreateDir data/CGSN_PARSE/rej
#Added data directories for SGSNT3G_PARSE
CreateDir data/SGSNT3G_PARSE
CreateDir data/SGSNT3G_PARSE/in
CreateDir data/SGSNT3G_PARSE/done
CreateDir data/SGSNT3G_PARSE/err
CreateDir data/SGSNT3G_PARSE/rej
#End of SGSNT3G_PARSE
#Added data directories for SGSN3G_PARSE
CreateDir data/SGSN3G_PARSE
CreateDir data/SGSN3G_PARSE/in
CreateDir data/SGSN3G_PARSE/done
CreateDir data/SGSN3G_PARSE/err
CreateDir data/SGSN3G_PARSE/rej
#End of SGSN3G_PARSE
#Added data directories for GGSNT3G_PARSE
CreateDir data/GGSNT3G_PARSE
CreateDir data/GGSNT3G_PARSE/in
CreateDir data/GGSNT3G_PARSE/done
CreateDir data/GGSNT3G_PARSE/err
CreateDir data/GGSNT3G_PARSE/rej
#End of GGSNT3G_PARSE
#Added data directories for GGSN3G_PARSE
CreateDir data/GGSN3G_PARSE
CreateDir data/GGSN3G_PARSE/in
CreateDir data/GGSN3G_PARSE/done
CreateDir data/GGSN3G_PARSE/err
CreateDir data/GGSN3G_PARSE/rej
#End of GGSN3G_PARSE
CreateDir data/CGSN_VALIDATE
CreateDir data/CGSN_VALIDATE/in
CreateDir data/CGSN_VALIDATE/done
CreateDir data/CGSN_VALIDATE/err
CreateDir data/CGSN_VALIDATE/rej
CreateDir data/CGSN_VALIDATE/dup
CreateDir data/CGSN_ASSEMBLE
CreateDir data/CGSN_ASSEMBLE/in
CreateDir data/CGSN_ASSEMBLE/done
CreateDir data/CGSN_ASSEMBLE/err
CreateDir data/CGSN_ASSEMBLE/rej
CreateDir data/CGSN_ASSEMBLE/ass
CreateDir data/MMSC_PARSE
CreateDir data/MMSC_PARSE/in
CreateDir data/MMSC_PARSE/done
CreateDir data/MMSC_PARSE/err
CreateDir data/MMSC_PARSE/rej
CreateDir data/MMSC_VALIDATE
CreateDir data/MMSC_VALIDATE/in
CreateDir data/MMSC_VALIDATE/done
CreateDir data/MMSC_VALIDATE/err
CreateDir data/MMSC_VALIDATE/rej
CreateDir data/MMSC_VALIDATE/dup
CreateDir data/INTCON
CreateDir data/INTCON/in
CreateDir data/INTCON/done
CreateDir data/INTCON/err
CreateDir data/INTCON/rej
CreateDir data/INTCON/out
CreateDir data/CAMEL
CreateDir data/CAMEL/in
CreateDir data/CAMEL/done
CreateDir data/CAMEL/err
CreateDir data/CAMEL/rej
CreateDir data/CAMEL/aged
CreateDir data/USSD
CreateDir data/USSD/in
CreateDir data/USSD/done
CreateDir data/USSD/err
CreateDir data/USSD/rej
CreateDir data/USSD/aged
CreateDir data/STARHOME
CreateDir data/STARHOME/in
CreateDir data/STARHOME/done
CreateDir data/STARHOME/err
CreateDir data/STARHOME/rej
CreateDir data/STARHOME/aged
CreateDir data/GSM_RATE
CreateDir data/GSM_RATE/in
CreateDir data/GSM_RATE/done
CreateDir data/GSM_RATE/err
CreateDir data/GSM_RATE/rej
CreateDir data/GSM_RATE/out
CreateDir data/GPRS_RATE
CreateDir data/GPRS_RATE/in
CreateDir data/GPRS_RATE/done
CreateDir data/GPRS_RATE/err
CreateDir data/GPRS_RATE/rej
CreateDir data/GPRS_RATE/out
CreateDir data/RGSM_RATE
CreateDir data/RGSM_RATE/in
CreateDir data/RGSM_RATE/done
CreateDir data/RGSM_RATE/err
CreateDir data/RGSM_RATE/rej
CreateDir data/RGSM_RATE/out
CreateDir data/RGPRS_RATE
CreateDir data/RGPRS_RATE/in
CreateDir data/RGPRS_RATE/done
CreateDir data/RGPRS_RATE/err
CreateDir data/RGPRS_RATE/rej
CreateDir data/RGPRS_RATE/out
CreateDir data/AGGREGATE
CreateDir data/AGGREGATE/ctl
CreateDir data/AGGREGATE/tmp
CreateDir data/AGGREGATE/in
CreateDir data/AGGREGATE/done
CreateDir data/AGGREGATE/rej
CreateDir data/AGGREGATE/err
CreateDir data/HUR
CreateDir data/TAP_OUT_EXTRACT
CreateDir data/TAP_OUT_EXTRACT/in
CreateDir data/TAP_OUT_EXTRACT/done
CreateDir data/TAP_OUT_EXTRACT/err
CreateDir data/TAP_OUT_EXTRACT/rej
CreateDir data/TAP_OUT_PARSE
CreateDir data/TAP_OUT_PARSE/in
CreateDir data/TAP_OUT_PARSE/done
CreateDir data/TAP_OUT_PARSE/err
CreateDir data/TAP_OUT_PARSE/rej
CreateDir data/TAP_OUT_PARSE/out
CreateDir data/TAP_IN_PARSE
CreateDir data/TAP_IN_PARSE/in
CreateDir data/TAP_IN_PARSE/done
CreateDir data/TAP_IN_PARSE/err
CreateDir data/TAP_IN_PARSE/rej
CreateDir data/TAP_IN_VALIDATE
CreateDir data/TAP_IN_VALIDATE/in
CreateDir data/TAP_IN_VALIDATE/done
CreateDir data/TAP_IN_VALIDATE/err
CreateDir data/TAP_IN_VALIDATE/rej
CreateDir data/TAP_IN_VALIDATE/dup
CreateDir data/TAP_IN_VALIDATE/TEST
CreateDir data/TAP_IN_VALIDATE/TEST/BIHMS
CreateDir data/TAP_IN_ASSEMBLE
CreateDir data/TAP_IN_ASSEMBLE/in
CreateDir data/TAP_IN_ASSEMBLE/done
CreateDir data/TAP_IN_ASSEMBLE/err
CreateDir data/TAP_IN_ASSEMBLE/rej
CreateDir data/TAP_IN_ASSEMBLE/ass
CreateDir data/TAP_IN_UPMARK
CreateDir data/TAP_IN_UPMARK/in
CreateDir data/TAP_IN_UPMARK/done
CreateDir data/TAP_IN_UPMARK/err
CreateDir data/TAP_IN_UPMARK/rej
CreateDir data/TAP_IN_RATE
CreateDir data/TAP_IN_RATE/in
CreateDir data/TAP_IN_RATE/done
CreateDir data/TAP_IN_RATE/err
CreateDir data/TAP_IN_RATE/rej
CreateDir data/TAP_IN_RATE/out
CreateDir data/pin_rel
CreateDir data/pin_rel/in
CreateDir data/pin_rel/done
CreateDir data/pin_rel/err
CreateDir data/BT_DISCOUNT
#Directories for mediationDWH framework
#
#CCN_PARSE
CreateDir data/CCN_PARSE
CreateDir data/CCN_PARSE/in
CreateDir data/CCN_PARSE/done
CreateDir data/CCN_PARSE/err
CreateDir data/CCN_PARSE/rej
CreateDir data/CCN_PARSE/out
#End CCN_PARSE
#SCP_PARSE
CreateDir data/SCP_PARSE
CreateDir data/SCP_PARSE/in
CreateDir data/SCP_PARSE/done
CreateDir data/SCP_PARSE/err
CreateDir data/SCP_PARSE/rej
CreateDir data/SCP_PARSE/out
#End SCP_PARSE
#INTCON_DWH
CreateDir data/INTCON_DWH
CreateDir data/INTCON_DWH/in
CreateDir data/INTCON_DWH/done
CreateDir data/INTCON_DWH/err
CreateDir data/INTCON_DWH/rej
CreateDir data/INTCON_DWH/out
#End INTCON_DWH
#End mediationDWH
#Directories for mediationDWH40 framework
#
#AIR_PARSE
CreateDir data/AIR_PARSE
CreateDir data/AIR_PARSE/in
CreateDir data/AIR_PARSE/done
CreateDir data/AIR_PARSE/err
CreateDir data/AIR_PARSE/rej
CreateDir data/AIR_PARSE/out
#End AIR_PARSE
#
#CCN40_PARSE
CreateDir data/CCN40_PARSE
CreateDir data/CCN40_PARSE/in
CreateDir data/CCN40_PARSE/done
CreateDir data/CCN40_PARSE/err
CreateDir data/CCN40_PARSE/rej
CreateDir data/CCN40_PARSE/out
#End CCN40_PARSE
#CCNV40_PARSE
CreateDir data/CCNV40_PARSE
CreateDir data/CCNV40_PARSE/in
CreateDir data/CCNV40_PARSE/done
CreateDir data/CCNV40_PARSE/err
CreateDir data/CCNV40_PARSE/rej
CreateDir data/CCNV40_PARSE/out
#End CCNV40_PARSE
#SDP_PARSE
CreateDir data/SDP_PARSE
CreateDir data/SDP_PARSE/in
CreateDir data/SDP_PARSE/done
CreateDir data/SDP_PARSE/err
CreateDir data/SDP_PARSE/rej
CreateDir data/SDP_PARSE/out
#End SDP_PARSE

#End mediationDWH40

#Directories for mediation_ePC framework
#
#SGSNePC_PARSE
CreateDir data/SGSNePC_PARSE
CreateDir data/SGSNePC_PARSE/in
CreateDir data/SGSNePC_PARSE/done
CreateDir data/SGSNePC_PARSE/err
CreateDir data/SGSNePC_PARSE/rej
#End SGSNePC_PARSE
#GGSNePC_PARSE
CreateDir data/GGSNePC_PARSE
CreateDir data/GGSNePC_PARSE/in
CreateDir data/GGSNePC_PARSE/done
CreateDir data/GGSNePC_PARSE/err
CreateDir data/GGSNePC_PARSE/rej
#End GGSNePC_PARSE
#CGSNePC_VALIDATE
CreateDir data/CGSNePC_VALIDATE
CreateDir data/CGSNePC_VALIDATE/in
CreateDir data/CGSNePC_VALIDATE/done
CreateDir data/CGSNePC_VALIDATE/err
CreateDir data/CGSNePC_VALIDATE/dup
CreateDir data/CGSNePC_VALIDATE/rej
#End CGSNePC_VALIDATE
#CGSNePC_ASSEMBLE
CreateDir data/CGSNePC_ASSEMBLE
CreateDir data/CGSNePC_ASSEMBLE/in
CreateDir data/CGSNePC_ASSEMBLE/done
CreateDir data/CGSNePC_ASSEMBLE/err
CreateDir data/CGSNePC_ASSEMBLE/ass
CreateDir data/CGSNePC_ASSEMBLE/rej
#End CGSNePC_ASSEMBLE

#End mediation_ePC


echo "`date`\nCreated ${COUNTER} directories"

