#include "pin_conf.h"
/* For PIN Functions */
#include "pinlog.h"
#include "pin_errs.h"
#include "pcm.h"

void
get_pin_conf_str(
	char	*keyword,
	char	*valp,
	pin_errbuf_t    *ebufp)
{
	int32	err = PIN_ERR_NONE;
	char		*charp = NULL;
	
	/***********************************************************
	* Clear the error buffer.
	***********************************************************/

	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERRBUF_CLEAR(ebufp);

	pin_conf("pin_cdr_collector", keyword,
		PIN_FLDT_STR, (caddr_t *)&charp, &err);

	if (err == PIN_ERR_NONE) {
		if (charp != (char *)NULL) {
			strcpy(valp,charp);
			free(charp);
		}
	}
	else {
		ebufp->pin_err = err;
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"%s is %d", keyword, *valp);
                return;
        }
	return;
}

void
get_pin_conf_int(
	char		*keyword,
	int32		*valp,
	pin_errbuf_t    *ebufp)
{

	int32	err = PIN_ERR_NONE;
	int32	*intp = NULL;
	
	/***********************************************************
	* Clear the error buffer.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERRBUF_CLEAR(ebufp);

	pin_conf("pin_cdr_collector", keyword,
		PIN_FLDT_INT, (caddr_t *)&intp, &err);

	if (err == PIN_ERR_NONE) {
		if (intp != (int *)NULL) {
			*valp = *intp;
			free(intp);
		}
	}
	else {
		ebufp->pin_err = err;
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"%s is %d", keyword, *valp);
		return;
     }
	return;
}

void
read_pin_conf(app_connect_to_ftam *connect_detailsp,
	pin_errbuf_t	*ebufp)
{

                #ifdef DEBUG
                        printf("\nhello1\n");
                #endif
	/***********************************************************
	* Clear the error buffer.
	**********************************************************/
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Get the loglevel 
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_loglevel",
		&connect_detailsp->log_level, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
        	PIN_ERR_SET_LEVEL(PIN_ERR_LEVEL_ERROR);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_loglevel from pin.conf file", ebufp);
		return;
	}
	else{
		switch (connect_detailsp->log_level) 
		{
			case PIN_ERR_LEVEL_NONE:
			case PIN_ERR_LEVEL_ERROR:
			case PIN_ERR_LEVEL_WARNING:
			case PIN_ERR_LEVEL_DEBUG:
				PIN_ERR_SET_LEVEL(connect_detailsp->log_level);
				break;
			default:
				PIN_ERR_SET_LEVEL(PIN_ERR_LEVEL_ERROR);
		}
	}

	/***********************************************************
	* Get the logfile path 
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_logfile",
		connect_detailsp->logfile_path, ebufp); 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_logfile from pin.conf file", ebufp);
		return;
	}
        else{
		#ifdef DEBUG
			printf("\nhello2\n");
		#endif


                char * extracted_file_path;

                (void ) extractfilepath(connect_detailsp->logfile_path, & extracted_file_path);

                int return_value = checkDirPerm(extracted_file_path);

                if(return_value == 2)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",extracted_file_path);
                        exit(1);
                }
                else if ( return_value == 3)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",extracted_file_path);
                        exit(1);
                }
                else
                {
                        PIN_ERR_SET_LOGFILE(connect_detailsp->logfile_path);

                        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_logfile is: %s\n",connect_detailsp->logfile_path);
                }





                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_loglevel is: %d\n",connect_detailsp->log_level);

        }



        /***********************************************************
        * Get the IP address
        ***********************************************************/
        get_pin_conf_str("pin_cdr_collector_name",
                connect_detailsp->host_name, ebufp);
        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_name from pin.conf file", ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_name is: %s\n",connect_detailsp->host_name);
        }

	/***********************************************************
	* Get the Username
	***********************************************************/

	get_pin_conf_str("pin_cdr_collector_username",
		connect_detailsp->username, ebufp); 

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_username from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_username is: %s\n",connect_detailsp->username);
	}

	/***********************************************************
	* Get the password
	***********************************************************/
	 get_pin_conf_str("pin_cdr_collector_password",
		connect_detailsp->passwd, ebufp); 
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_password from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_password is: %s\n",connect_detailsp->passwd);
	}


	/***********************************************************
	* Get the FTAM Remote Server file
	* 
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftam_remote_file_path",
		connect_detailsp->ftam_remote_file_path, ebufp); 

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftam_remote_file_path from pin.conf file",
			ebufp);
		  if(ebufp->pin_err == PIN_ERR_NOT_FOUND)
                {
                        connect_detailsp->ftam_current_file_path[0]= '\0';
                        PIN_ERRBUF_CLEAR(ebufp);

                }
                else
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_ftam_remote_file_path is: %s\n",
			connect_detailsp->ftam_remote_file_path);
	}

	/***********************************************************
	* Get the FTAM local Server file path
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftam_download_file",
		connect_detailsp->ftam_current_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftam_download from pin.conf file",
			ebufp);
		return;
	}
	 else{

                int return_value = checkDirPerm(connect_detailsp->ftam_current_file_path);

                if(return_value == 2)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",connect_detailsp->ftam_current_file_path);
                        exit(1);
                }
                else if ( return_value == 3)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",connect_detailsp->ftam_current_file_path);
                        exit(1);
                }
                else
                {
                        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftam_download_file is: %s\n",
                        connect_detailsp->ftam_current_file_path);
                }
        }


	/***********************************************************
	* Get the transfer
	***********************************************************/

	 strcpy(connect_detailsp->transfer,"FTAM");
        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_transfer is: %s\n",connect_detailsp->transfer);	

	/***********************************************************
	* Get the FTAM local Server temp file path        //This should be set to remote path name
	*
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftam_temp_file",
		connect_detailsp->ftam_temp_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftam_command_file from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_ftam_temp_file is: %s\n",
		connect_detailsp->ftam_temp_file_path);
	}

	/***********************************************************
	* Get the FTAM local Server audit file path
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_ftam_audit_file",
		connect_detailsp->ftam_audit_file_path, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_ftam_audit_file from pin.conf file",
			ebufp);
		return;
	}
	else{

                int return_value = checkDirPerm(connect_detailsp->ftam_audit_file_path);

                if(return_value == 2)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not exist \n",connect_detailsp->ftam_audit_file_path);
                        exit(1);
                }
                else if ( return_value == 3)
                {
                                                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                        "%s does not have write permission\n",connect_detailsp->ftam_audit_file_path);
                        exit(1);
                }
                else
                {
                        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftam_audit_file is: %s\n",
                        connect_detailsp->ftam_audit_file_path);
                }
	}


	/***********************************************************
	* Get the Audit filename
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_audit_file",
		connect_detailsp->audit_file_name, ebufp);
			
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_audit_file from pin.conf file",
			ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_audit_file is: %s\n",
			connect_detailsp->audit_file_name);
	}


	/***********************************************************
	* Get the Audit filename Suffix
	***********************************************************/
	get_pin_conf_str("pin_cdr_collector_audit_file_suffix",
		connect_detailsp->audit_file_name_suffix, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_audit_file_suffix from pin.conf file",
		ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_audit_file is: %s\n",
			connect_detailsp->audit_file_name_suffix);
	}

	/***********************************************************
        * Get the Retry Count
        ***********************************************************/
        get_pin_conf_int("pin_cdr_collector_retry_count",
                &connect_detailsp->retry_count, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_retry_count from pin.conf file", ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_retry_count is: %d\n",connect_detailsp->retry_count);
        }

	/***********************************************************
        * Get the Temporary file path
        *
        ***********************************************************/
/*        get_pin_conf_str("pin_cdr_collector_ftam_tmp_file",
                connect_detailsp->tmp_file_path, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_ftam_command_file from pin.conf file",
                        ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftam_tmp_file is: %s\n",
                        connect_detailsp->tmp_file_path);
        }
*/
	strcpy(connect_detailsp->tmp_file_path,connect_detailsp->ftam_temp_file_path);


         /***********************************************************
        * Get the Temporary file name
        *
        ***********************************************************/
/*        get_pin_conf_str("pin_cdr_collector_ftam_tmp_file_name",
                connect_detailsp->tmp_file_name, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_ftam_tmp_file_name from pin.conf file",
                        ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftam_tmp_file_name is: %s\n",
                        connect_detailsp->tmp_file_name);
        }
*/


	/***********************************************************
	* Get the sleeep Count
	***********************************************************/
	get_pin_conf_int("pin_cdr_collector_sleep_time",
		&connect_detailsp->sleep_time, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"Error while processing the value of pin_cdr_collector_sleep_time from pin.conf file", ebufp);
		return;
	}
	else{
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"pin_cdr_collector_sleep_time is: %d\n",connect_detailsp->sleep_time);
	}
	
        /***********************************************************
        * Get the Temporary file path 
        *
        ***********************************************************/
/*        get_pin_conf_str("pin_cdr_collector_ftam_tmp_file",
                connect_detailsp->tmp_file_path, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_ftam_tmp_file from pin.conf file",
                        ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_ftam_tmp_file is: %s\n",
                        connect_detailsp->tmp_file_path);
        }
	

*/

	/***********************************************************
        * Get the directory control file path
        ***********************************************************/

        get_pin_conf_str("pin_cdr_collector_cntrl_file_path",
                connect_detailsp->cntrl_file_path, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_cntrl_file_path from pin.conf file", ebufp);

		 if(ebufp->pin_err == PIN_ERR_NOT_FOUND)
                {
                        connect_detailsp->cntrl_file_path[0]= '\0';
                        PIN_ERRBUF_CLEAR(ebufp);

                }
                else
		{
			#ifdef DEBUG
                                printf("\n***connect_detailsp->cntrl_file_path\n");
                        #endif
                return;
		}

        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_cntrl_file_path is: %s\n",connect_detailsp->cntrl_file_path);
        }
	
	/***********************************************************
        * Get the directory control file name  
        ***********************************************************/

        get_pin_conf_str("pin_cdr_collector_dcf1",
                connect_detailsp->dcf1, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_dcf1 from pin.conf file", ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_dcf1 is: %s\n",connect_detailsp->dcf1);
        }

	 /***********************************************************
        * Get the directory control file name
        ***********************************************************/

        get_pin_conf_str("pin_cdr_collector_dcf2",
                connect_detailsp->dcf2, ebufp);

        if (PIN_ERR_IS_ERR(ebufp)) {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "Error while processing the value of pin_cdr_collector_dcf2 from pin.conf file", ebufp);
                return;
        }
        else{
                pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                        "pin_cdr_collector_dcf2 is: %s\n",connect_detailsp->dcf2);
        }

	return;
}
