#if 0
static char sccsid[] = "@(#)main.c	8.6 (Berkeley) 10/9/94";
#endif

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/*#include <sys/ioctl.h>*/
#include <ctype.h>
#include <err.h>
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ftiuser.h>
#include "pinlog.h"
#include "pin_conf.h"
#include "pcm.h"
#include "pin_errs.h"
#define      MAXSTRLEN      64
//#define      RDB_FILE_NAME  "msc"     /* name of .rdb file to use for*/

char tmpfilename[512];

void print_error_info(ftiesrTp);

void write_audit_file(char *, app_connect_to_ftam , int);

int parse_dcf_file(ftilaiTp , app_connect_to_ftam );

int rename_file(app_connect_to_ftam, char *, char *, int);

char del_file[50];

struct file_info { char name[26];
	char status;
	char tmpstamp[12];
	char tmp_stamp[12];
	struct file_info * next;
};

struct node{
	char name[100];
	struct node * next;
};
struct node * startp = NULL;


void bubbleSort(struct file_info ** , int ); 
void swap(struct file_info **, struct file_info ** ,struct file_info **);

/*********************************************************************************************
* Run shell command and capture the output in a array
* return value : nil
*********************************************************************************************/
void usepipe(char * cmd, char *buf)
{
	FILE *ptr;

    if ((ptr = popen(cmd, "r")) != NULL)
		if (fgets(buf, BUFSIZ, ptr) != NULL)
        {
			buf[strlen(buf)-1]='\0';
        }
	
	(void) pclose(ptr);
}

/*********************************************************************************************
* Extract the parent directory for a file from its absolute path
* return value : 0 if '/' is found, othewise 1 
*********************************************************************************************/
int extractfilepath(char * filename, char * * extracted_file_path)
	{
    #ifdef DEBUG
                printf("\nhello3\n");
    #endif

    char * position = strrchr(filename,'/');

    if (!position)
        return 1;

    #ifdef DEBUG
                printf("\nhello4\n");
        #endif


    int linecount = 0;

    while((filename+linecount)< position)
    {
                if(! linecount)
                {
                        #ifdef DEBUG
                                printf("\nhello5\n");
                        #endif

                        * extracted_file_path = (char *) malloc(1);
                }
                else
                {
            #ifdef DEBUG
                                printf("\nhello6\n");
                        #endif

                        * extracted_file_path = (char *) realloc(* extracted_file_path,linecount+1);
                }
            (* extracted_file_path)[linecount] = filename[linecount];
            linecount++;
        }

        #ifdef DEBUG
                printf("\nhello7\n");
    #endif
 if( linecount)
        {
                        #ifdef DEBUG
                                printf("\nhello8\n");
            #endif

                        * extracted_file_path = (char *) realloc(* extracted_file_path,linecount+1);

            (* extracted_file_path)[linecount]='\0';
        }
    else                    //if the file is at the root directory
        {
                        #ifdef DEBUG
                                printf("\nhello9\n");
            #endif

                        * extracted_file_path = (char *) malloc(2);

            (* extracted_file_path)[0]='/';
            (* extracted_file_path)[1]='\0';
    }

    #ifdef DEBUG
                printf("\nhello10\n");
        #endif
	
    return 0;
}

/*********************************************************************************************
* Check whether directory exists and is writable
* return value : 1 on success 2 or 3 on failure 
*********************************************************************************************/
int checkDirPerm(char * directory)
{
        char buf[BUFSIZ];
        memset(buf,BUFSIZ,0);
        char framecommand[30];

        sprintf(framecommand,"ls -ld %s;RC=$?; if [ $RC -ne 0 ] \n then \n echo DIRECTORY DOES NOT EXIST\n fi",directory);

        usepipe(framecommand,buf);


        if(strstr(buf,"DIRECTORY DOES NOT EXIST"))
        {
                return 2;
        }

        if(buf[2]!='w')
        {
                return 3;
        }
        return 1;


}

/*********************************************************************************************
* Remove the ':' from the string coming from ls -lrt so as to get the hour and minute
* return value : nil 
*********************************************************************************************/
void extract_hr_min(char * hrmin)
{
        if(strstr(hrmin,":"))
        {
                hrmin[2]=hrmin[3];
                hrmin[3]=hrmin[4];
                hrmin[4]='\0';
        }
        else    //If the file hasnt been modified for the last six months
        {
                strcpy(hrmin,"0000");
                hrmin[4]='\0';
        }
}

/*********************************************************************************************
* Map the month which is coming from output of ls -lrt command into integer
* return value : nil 
*********************************************************************************************/
void mapmonth(int month, char * month_i)
{
         if(!strcmp(month,"Jan"))
                        {
                                strcpy(month_i,"01");
                        }
                        else if(!strcmp(month,"Feb"))
                        {
                                strcpy(month_i,"02");
                        }
                        else if(!strcmp(month,"Mar"))
                        {
                                strcpy(month_i,"03");
                        }
                        else if(!strcmp(month,"Apr"))
                        {
                                strcpy(month_i,"04");
                        }
                        else if(!strcmp(month,"May"))
                        {
                                strcpy(month_i,"05");
                        }
                        else if(!strcmp(month,"Jun"))
                        {
                                strcpy(month_i,"06");
                        }
                        else if(!strcmp(month,"Jul"))
                        {
                                strcpy(month_i,"07");
                        }
                        else if(!strcmp(month,"Aug"))
                        {
                                strcpy(month_i,"08");
                        }
                        else if(!strcmp(month,"Sep"))
                        {
                                strcpy(month_i,"09");
                        }
                        else if(!strcmp(month,"Oct"))
                        {
                                strcpy(month_i,"10");
                        }
                        else if(!strcmp(month,"Nov"))
                        {
                                strcpy(month_i,"11");
                        }
                        else if(!strcmp(month,"Dec"))
                        {
                                strcpy(month_i,"12");
                        }
                        else
                        {
                                printf("\nError while mapping the month\n");
                                                        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
								"Error while mapping the month\n");
								exit(1);
                        }

}


/*********************************************************************************************
* Get the year from local server  
* return value : year value 
*********************************************************************************************/
int getYear(int month)
{
        char            timestamp[20];
        char            timestamp_month[20];
        char            timestamp_year[20];
        time_t          result;

        result = time(NULL);
        cftime(timestamp_month,"%m", &result);
        cftime(timestamp_year,"%Y", &result);

        int int_month= atoi(timestamp_month);
        int int_year= atoi(timestamp_year);


        if(month>int_month)
        {
				//year changed while the file was under transfer
                return(--int_year);
        }
        else
        {
                return int_year;
        }


}

int flag1=0;
int flag2=0;


ftiadmT         adm;            /* Administrative structure     */
ftirdbT         rdb;            /* Rdb operations structure     */
ftibndT         bnd;            /* Bind structure               */
ftirenT         renfile;        /* Rename file structure        */
ftidockT        dock;           /* Docket structure             */
ftilaiT         lai      = 0;   /* Local identifier             */
ftiesrT         esr;            /* Status report                */
ftitrfT		trf;
ftircdT		rcd;
ftilcdT		lcdir;
int fti_rcd(ftilaiT *,ftircdT *,int,ftiesrT *);

int
ftam_main (
	app_connect_to_ftam *connect_details)
{
    int             trfid;          /* Transfer identifier number   */
	int		pid;
    char            *dir;           /* Environment variable         */
	char 		*ptrchar;
	char pro_id[15];
	int retry_cnt,ret_fun;
	int return_cmd=0;

	FILE * 	fd = 0;
	char rm_file[512];

        char timestamp[50];
	char command[150];
        time_t          result;
	struct node * ptr ;
	
	#ifdef DEBUG
		printf("\nconnect_details->dcf1=%s***\n",connect_details->dcf1);
		printf("\nconnect_details->dcf2=%s***\n",connect_details->dcf2);
	#endif

	int i=0;
	int file_check = 0;

	//while(i < connect_details->retry_count && return_cmd!=0)
	while(i <= connect_details->retry_count && return_cmd!=1)
	{

	 	memset(&esr,0,sizeof(esr));
		memset(&lai,0,sizeof(lai));
		memset(&trf,0,sizeof(trf));


		/***		TRANSACTION SECURITY		***/

		if(!file_check)
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
       		          "%s", "Checking for left out files...");
			free_list();
			startp = NULL;
			
			int count = 0;

		    if(!check_temporary_file(*connect_details))
		    {
				#ifdef DEBUG
					printf("\nInside first if \n");
               		printf("\ncount =%d***\n",count);
		        #endif
			}


			ptr = startp;

	        while(ptr && (ptr->name[0]))
       		{
				#ifdef DEBUG
					printf("\n!!!count =%d***\n",count);
			        #endif

				if(!check_temporary_dir(*connect_details,ptr->name))
				{
					#ifdef DEBUG
						printf("\nInside second if \n");
					#endif

					//rename_file(ptr->name, *connect_details);
					result = time(NULL);
					cftime(timestamp,"%Y%m%d", &result);
					int rename_ret = rename_file(*connect_details, ptr->name, timestamp,0);
					//sprintf(command,"%s%s%s%s%s","rm -f \"",(*connect_details).tmp_file_path,"/",ptr->name,"\"");
					sprintf(command,"%s%s%s%s%s%s","rm -f \"",(*connect_details).tmp_file_path,"/",ptr->name,".shf","\"");

                    #ifdef DEBUG
                        printf("\nRemoving tmp file command is =%s***\n",command);
                    #endif

                    pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
	                "%s%s", "Removing temporary file ",ptr->name);

					int lscommand = system(command);
					if(lscommand)
						 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

					if(! rename_ret)
					{
	                    write_audit_file( ptr->name, *connect_details, 1);
					}
					else
					{
	                    write_audit_file( ptr->name, *connect_details, 0);
							exit(1);
					}


                    // (void)write_audit_file(226, ptr->name, *connect_details);    //get auditfilename from check_temporary_file

                }
                else
                {
                    //sprintf(command,"%s%s%s%s%s","rm -f \"",(*connect_details).tmp_file_path,"/",ptr->name,"\"");
	                sprintf(command,"%s%s%s%s%s%s","rm -f \"",(*connect_details).tmp_file_path,"/",ptr->name,".shf","\"");

                    #ifdef DEBUG
                        printf("\nRemoving tmp file command is =%s***\n",command);
                    #endif

                    pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
	                "%s%s", "Removing temporary file ",ptr->name);

					int lscommand = system(command);
					if(lscommand)
						 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);

                }

                ptr = ptr -> next;

                #ifdef DEBUG
                count++;
                #endif

			}	//End of while loop

			free_list();

		    pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                 "%s", "File check completed...");
		}
		/***		END OF TRANSACTION SECURITY		***/



		#ifdef DEBUG
			printf("\nOut of file check\n");
		#endif


		if(!i)
		{
			printf("\n\nConnecting to the server ...\n");
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s", "Connecting to the server...\n");
		}
		else{	
			printf("\n\nReconnecting to the server ...\n");
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
						 "%s", "Reconnecting to the server...\n");
			sleep(connect_details->sleep_time);
		}

		ret_fun = connect_to_the_server(connect_details);

		#ifdef DEBUG
			printf("\nConnect to the server returned ret_fun = %d***\n",ret_fun);
		#endif

		i++;

	
		if(ret_fun == 0){
			return_cmd = cmdscanner(connect_details);

			if(!return_cmd)
				break;

			int failure_count = 0;

			while( return_cmd==2 && failure_count<5)
			{
				#ifdef DEBUG
				printf("\nfailure count =%d***\n",failure_count);
				#endif
				return_cmd = cmdscanner(connect_details);
				failure_count ++;
			}

			if(!return_cmd)
				break;

			if(failure_count == 5)
				exit(1);
	//		if(return_cmd == 1)
	//			i++;

			#ifdef DEBUG
				printf("\n return_cmd = %d**\n", return_cmd);
				printf("\nfailure count =%d***\n",failure_count);
			#endif
		}
	
		//close(fd);

	} //End of while loop

	if(i >= (connect_details->retry_count+1)){
	/*
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
        "Connection failed %d times",i+1);
        printf("\nConnection failed %d times\n",i+1);
	*/
		//close(fd);
	
	}


}


/*********************************************************************************************
* Check for temporary files on cnt_details.tmp_file_path and store the output in a linked list
* return value : non zero on sucess , zero on failure
*********************************************************************************************/

int check_temporary_file(app_connect_to_ftam cnt_details)
{
	struct node * ptr1;
	char    tmp[400];
	char command[200];

	#ifdef DEBUG
		printf("\nsizeof tmp =%d***\n",sizeof(tmp));
	#endif

	sprintf(command,"%s%s%s%s","ls -1 \"",cnt_details.tmp_file_path,"\""," > tempfile.tmp");
	//sprintf(command,"%s%s%s%c","ls -1 ",cnt_details.tmp_file_path,"\/TTFILE*.shf > tempfile.tmp",'\0');

	#ifdef DEBUG
		printf("\nfirst command is =%s***\n",command);
	#endif

	int lscommand = system(command);

	if(lscommand)
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);


	startp = NULL;

	FILE * fp1=NULL;

	#ifdef DEBUG
		printf("\n123\n");
	#endif

	fp1 = fopen("tempfile.tmp","r");

	#ifdef DEBUG
		printf("\nsizeof tmp =%d***\n",sizeof(tmp));
	#endif

	//      fgets (tmp,200, fp1);

	int count = 0;
	memset(tmp,0,sizeof(tmp));

	while (fgets (tmp, 100,fp1) != NULL)
	{
//			tmp[strlen(tmp)-1]='\0';


			//FTAM creates .shf files for each download
			if(!strstr(tmp,".shf"))
				continue;

			#ifdef DEBUG
					tmp[strlen(tmp)-1]='\0';
					printf("\nstrlen(tmp) =%d***\n",strlen(tmp));
					printf("\nBefore string compare tmp--------=%s***\n",tmp);
					printf("\nstrlen(cnt_details.tmp_file_name) =%d***\n",strlen(cnt_details.tmp_file_name));
					printf("\ncnt_details.tmp_file_name--------=%s***\n",cnt_details.tmp_file_name);

					tmp[strlen(tmp)-4] = '\0';

			#else
					if(strlen(tmp)>=5)
					tmp[strlen(tmp)-5] = '\0';

			#endif
			

			#ifdef DEBUG
							printf("\nAfter string compare tmp--------=%s***\n",tmp);

			#endif

			//SWITCH generates files with name TTFILE*
			if(!strstr(tmp,"TTFILE"))
			{
					continue;
			}


			count++;

			if(count == 1)
			{
					ptr1= (struct node *) malloc(sizeof(struct node));
					strcpy(ptr1->name,tmp);

					#ifdef DEBUG
					printf("\n ptr1->name=%s***\n",ptr1->name);
					#endif

					startp = ptr1;
					ptr1 ->next = NULL;
			}
			else{
					(ptr1)->next = (struct node *) malloc(sizeof(struct node));
					strcpy((ptr1->next)->name,tmp);
					ptr1=ptr1->next;

					 #ifdef DEBUG
					printf("\n ptr1->name=%s***\n",ptr1->name);
					#endif


			}


	}

	//      tmp[strlen(tmp)-1] = '\0';

	#ifdef DEBUG
		printf("In check_temporary_file after gets tmp =%s***\n",tmp);
	#endif

	fclose(fp1);

	sprintf(command,"%s","rm -f tempfile.tmp");

	#ifdef DEBUG
		printf("\nrm tempfile.tmp is =%s***\n",command);
	#endif

	int ret = system(command);

	if(ret)
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", command);


	#ifdef DEBUG
		printf("In check_temporary_file tmp =%s***\n",tmp);
	#endif

	#ifdef DEBUG
		printf("\nThe linked list contents are...\n");

	ptr1 = startp;

	while(ptr1)
	{
			printf("\n ptr1->name =%s***\n",ptr1->name);

			ptr1 = ptr1 -> next;
	}

	#endif

	if(count)
	{
			return 0;
	}
	else
	{
		#ifdef DEBUG
			printf("\ntmp is NULL\n");
		#endif

		return 1;
	}


}

/*********************************************************************************************
* For a linked list entry check for its presence in cnt_details.ftp_temp_file_path  
* return value : 0 if present , non zero on failure
*********************************************************************************************/
int check_temporary_dir(app_connect_to_ftam cnt_details, char * tmp)
{
        char command[200];
        #ifdef DEBUG
        printf("\nIn check_temporary_dir \n");
        printf(" In check_temporary_dir tmp =%s***\n",tmp);
        #endif
        sprintf(command,"%s%s%s%s%s","ls \"",cnt_details.ftam_temp_file_path,"/",tmp,"\"");

        #ifdef DEBUG
         printf("\nin check_temporary_dir ls command is =%s***\n",command);
        printf("\nin check_temporary_dir tmp=%s***\n",tmp);
        #endif

        int status= system(command);

        #ifdef DEBUG
			printf("\nstatus=%d***\n",status);
        #endif
        return status;
}



/*
 * Connect to the server and
 */
int connect_to_the_server(
app_connect_to_ftam cnt_details)
{
        char *host;
        int ret_login;

        ftiadmT         adm;            /* Administrative structure     */
        ftirdbT         rdb;            /* Rdb operations structure     */
        ftibndT         bnd;            /* Bind structure               */
        ftirenT         renfile;        /* Rename file structure        */
        ftidockT        dock;           /* Docket structure             */
        ftilaiT         lai      = 0;   /* Local identifier             */
        ftiesrT         esr;            /* Status report                */
		int  		recneg;
        char            *dir;           /* Environment variable         */

		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
                 "%s", "Entering into connect_to_the_server function");

		#ifdef DEBUG
		printf("\n Entering into the connect_to_the_server function\n");
		#endif

		/*----------------------------------------------------------------------*/
		/* ENVIRONMENT VARIABLES Initialization                                 */
		/*----------------------------------------------------------------------*/

        /* FTIINID: looks first into environment, if already defined    */
        dir = (char *)getenv("FTIINID") ;
        if (dir) {
              /* if yes, copy its value into fti_init structure */
              strcpy(adm.ftiinid,dir);
		#ifdef DEBUG
              printf("FTIINID : %s\n",dir);
		#endif
        }
        /* else use default installation value */
        else strcpy(adm.ftiinid,"\0");

        /* FTILOGD: same as above */
        dir = (char *)getenv("FTILOGD") ;
        if (dir) {      /* yes, it is defined */
              strcpy(adm.ftilogd,dir);
		#ifdef DEBUG
              printf("FTILOGD : %s\n",dir);
		#endif
        }
        else strcpy(adm.ftilogd,"\0");

        /* FTISHFD */
        dir = (char *)getenv("FTISHFD") ;
        if (dir) {      /* yes, defined */
              strcpy(adm.ftishfd,dir);
		#ifdef DEBUG
               printf("FTISHFD : %s\n",dir);
		#endif
        }
        else strcpy(adm.ftishfd,"\0");

        /* FTITRF */
        dir = (char *)getenv("FTITRFD");
        if (dir) {      /* yes, defined */
              strcpy(adm.ftitrfd,dir);
		#ifdef DEBUG
              printf("FTITRFD : %s\n",dir);
		#endif
        }
        else strcpy(adm.ftitrfd,"\0");

        /* NOTE: FTIRDBD take default installation value */
        strcpy(adm.ftirdbd, "\0");

		/*----------------------------------------------------------------------*/
		/* Call FTAM Library Initialization function                            */
		/*----------------------------------------------------------------------*/

		#ifdef DEBUG
			printf("fti INITIALIZATION\n\t------------------> ");
		#endif

        if (fti_init(&adm,&esr)) {
              /* error */
		#ifdef DEBUG
              printf("fti_init FAILED\n");
		#endif
	      pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "fti_int failed");
              print_error_info( &esr );
              exit(1);
        }
        else
		{
			#ifdef DEBUG
				  printf("fti_init SUCCEEDED\n");
			#endif
			  pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"%s", "fti_init succeeded");
		}


		/*----------------------------------------------------------------------*/
		/* Enter local network address for loopback operation into Remote       */
		/* Systems Database                                                     */
		/*----------------------------------------------------------------------*/

        /* Name of "rdb" file to use: msc */
//        strcpy( &rdb.hostname[0], RDB_FILE_NAME );
        strcpy( &rdb.hostname[0], cnt_details.host_name );


        /* Gets selector info for a requested RSDB entry */
		#ifdef DEBUG
			printf("Getting RDB file %s\n\t------------------> ", rdb.hostname );
		#endif

        if (fti_rdbget(&rdb, 1, &esr)) {
			#ifdef DEBUG
				  printf("fti_rdbget FAILED. return 1\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "fti_rdbget FAILED");  
			print_error_info( &esr );
			return 1;
        }
        else
		{
			#ifdef DEBUG
				  printf("Rdb file read SUCCESSFULLY\n");
			#endif
			 pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"%s", "Rdb file read SUCCESSFULLY");		
		}

        
		/* Enter host and username */
        strcpy(bnd.hostname, rdb.hostname);
        strcpy(bnd.username, cnt_details.username);
        strcpy(bnd.password,cnt_details.passwd);


        /* Init password parameter */
        /* NOTE: 1st char *must* be zero */
        bnd.password[0] = 0;
        bnd.password[1] = (int) strlen( cnt_details.passwd);
        strcpy( &bnd.password[2], cnt_details.passwd);
        bnd.account[0] = '\0';

		#ifdef DEBUG
			printf("Try to connect with %s\n\t------------------> ", bnd.hostname);
		#endif

        if (fti_connect(&lai,&bnd,&recneg,FTIEXBLK,&esr)) {

		#ifdef DEBUG
        	printf("fti_connect FAILED\n");
		#endif

		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                                "%s", "Unable to connect to host");
		print_error_info( &esr );
		return 1;
		}

		else /* OK */
		{
			#ifdef DEBUG
				printf("fti_connect SUCCEEDED\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
									"%s", "fti_connect SUCCEEDED");

					return 0;
		}
}






/*********************************************************************************************
* Command parser.
* Handles ftam initiator commands
* return value : 0 if a TTFILE is successfully downloaded
* 			   : 1 if connectin failed
* 			   : 2 if error occured while downloading TTFILE when connection still exists
*********************************************************************************************/
int
cmdscanner (
	app_connect_to_ftam cnt_details)
{
	char logfile[256];
	char rm_file[512];
	char command[150];
	char timestamp[50];
	char	name[50];
	char controlFileName[200];
	char remoteDirectory[200];
	char * current_path = NULL;

	FILE  *fout = NULL;
	int 	retValue;
	int 	idx;
	struct file_info  * fileInfo = NULL;
	struct file_info  * start;
	time_t          result;
	flag1=0;
	flag2=0;
	struct node * preptr;
	struct node * ptr ;

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
	                "%s", "Entering into cmdscanner function");


	#ifdef DEBUG
	printf("\nDirectory control file path = %s*\n", cnt_details.cntrl_file_path);
	#endif

	
	strcpy(remoteDirectory,cnt_details.cntrl_file_path);
	strcat(remoteDirectory,"/");
	strcat(remoteDirectory,"\0");


	//change the directory where the directory control file is residing
	int count_rcd_dcf =0;
	while(count_rcd_dcf<5)
	{
		if(cnt_details.cntrl_file_path[0]=='\0')
		{
			//printf("Remote directory is the default directory\n");

			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"Remote directory is the default directory");
			break;
		}

		else
		{
	
			strcpy(rcd.dirname, remoteDirectory);
			#ifdef DEBUG
			printf("rcd.dirname=%s\n",rcd.dirname);
			#endif
			printf("\nChanging remote directory to %s for downloading the DCF files...\n",rcd.dirname);

			if(fti_rcd(&lai,&rcd,FTIEXBLK,&esr)) 
			{
				#ifdef DEBUG
					printf("fti_rcd for getting the directory control file FAILED\n");
				#endif
			
				if(esr.errcode == FTIERCNE)
				{
					printf("\nConnection is lost\n");
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "Connection lost");
				}

				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Can not change remote directory to %s", rcd.dirname);
				print_error_info( &esr );

				if(!esr.errcnxs)
					return 1;
			}
			else { //OK
					printf("Remote directory changed to %s\n ", rcd.dirname);
					pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"The current remote directory is %s", rcd.dirname);
					break;
			}
		}

			count_rcd_dcf++;


	}

	//Get the directory control file.
	//       trf.doctyp   = FTMDTFT3;        // type FTAM-3           
	trf.doctyp   = FTMDTUNO;        // type unkown
	trf.mode = FTMTMREP;
	//*****************************
	

	int flag_dcf1 = 0;
	int count_dcf1=0;

	while(!flag_dcf1 && count_dcf1<5)
	{
		#ifdef DEBUG
		printf("\ncount_dcf1=%d***\n",count_dcf1);
		#endif
		memset(controlFileName,0,strlen(controlFileName));
		strcat(controlFileName,cnt_details.dcf1);
		strcat(controlFileName,"\0");	
		strcpy(trf.remname,controlFileName);
		#ifdef DEBUG
		printf("\ntrf.remname for cnt_details.dcf1 is =%s***\n",trf.remname);
		#endif

   
		strcpy(trf.locname,cnt_details.ftam_temp_file_path);
		strcat(trf.locname,"/");
		strcat(trf.locname,cnt_details.dcf1);

		#ifdef DEBUG
			printf("\ntrf.locname=%s***\n",trf.locname);
		#endif

		printf("\nDownloading %s...\n",cnt_details.dcf1);

		if (fti_get(&lai,&trf,FTIEXBLK,&esr)) {
			printf("Could not download %s\n",trf.remname);
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s%s%s","fti_get for the directory control file ",trf.remname," FAILED");
			print_error_info( &esr );

			if(esr.errcode == FTIERCNE)
			{
				printf("\nConnection is lost\n");
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "Connection lost");
				return 1;
			}
	
			if(esr.errcode == FTIERORF)
			{
				#ifdef DEBUG
				printf("\nRemote file not found \n");
				#endif
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s%s",cnt_details.dcf1," NOT FOUND");
				flag1=1;
				break;
			}
			else if(esr.errcode == FTIEROLF)
			{
					#ifdef DEBUG
					printf("\nLocal file not found \n");
					#endif
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"PATH FOR %s%s",cnt_details.dcf1," NOT VALID"); 
					flag1=1;
					break;
			}
			else{
					if(!esr.errcnxs)
						return 1;

			}
        }

        else {
			printf("\n%s successfully downloaded\n",cnt_details.dcf1);
			printf("\tBytes sent : %d\n",trf.result);
			printf("\tTime elapsed : %f seconds\n",trf.elapse);
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"%s%s",cnt_details.dcf1," successfully downloaded");
			flag_dcf1=1;
        }
	
		count_dcf1++;
	}

	int flag_dcf2=0;
	int count_dcf2=0;
	while(!flag_dcf2 && count_dcf2<5)
	{
		#ifdef DEBUG
		printf("\ncount_dcf2=%d***\n",count_dcf2);
		#endif
		memset(controlFileName,0,strlen(controlFileName));
		strcat(controlFileName,cnt_details.dcf2);
		strcat(controlFileName,"\0");	
		strcpy(trf.remname,controlFileName);
		#ifdef DEBUG
		 printf("\ntrf.remname for cnt_details.dcf2 is =%s***\n",trf.remname);
		#endif
    
   

		strcpy(trf.locname,cnt_details.ftam_temp_file_path);
		strcat(trf.locname,"/");
		strcat(trf.locname,cnt_details.dcf2);
		#ifdef DEBUG
		printf("\ntrf.locname=%s***\n",trf.locname);
		#endif

		printf("\nDownloading %s...\n",cnt_details.dcf2);

		if (fti_get(&lai,&trf,FTIEXBLK,&esr)) {
			printf("Could not download %s\n",trf.remname);
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s%s%s","fti_get for the directory control file ",trf.remname," FAILED");
			print_error_info( &esr );
		
			if(esr.errcode == FTIERCNE)
			{
							printf("\nConnection is lost\n");
							pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "Connection lost");
							return 1;
			}

			if(esr.errcode == FTIERORF)
			{       
					#ifdef DEBUG
					printf("\nRemote file not found \n");
					#endif
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s%s",cnt_details.dcf2," NOT FOUND");

					flag2 = 1;
					break;
			}
			else if(esr.errcode == FTIEROLF)
			{
					#ifdef DEBUG
					printf("\nLocal file not found \n");
					#endif
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"PATH FOR %s%s",cnt_details.dcf2," NOT VALID");  
					flag2=1;
					break;
			}
			else{
				if(!esr.errcnxs)
					return 1;
			}
        }

        else {
			printf("\n%s successfully downloaded\n",cnt_details.dcf2);
			printf("\tBytes sent : %d\n",trf.result);
			printf("\tTime elapsed : %f seconds\n",trf.elapse);
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"%s%s",cnt_details.dcf2," successfully downloaded");
			flag_dcf2 = 1;
        }

		count_dcf2++;
	}

	if(flag1 && flag2)
	{
		#ifdef DEBUG
			printf("\nflag1=%d*** , flag2=%d***\n",flag1,flag2);
		#endif
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Can not find both control files %s and %s...Exiting...", cnt_details.dcf1,cnt_details.dcf2);
		exit(1);
	}


	//change the remote directory for downloading cdrs

	int count_rcd_cdr =0;
	while(count_rcd_cdr<5)
	{
		if(cnt_details.ftam_remote_file_path[0]=='\0')
		{
				// printf("Remote directory is the default directory\n");

				pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"Remote directory is the default directory");
				break;
		}
        else
        {
			strcpy(remoteDirectory,cnt_details.ftam_remote_file_path);
			strcat(remoteDirectory,"/");
			strcat(remoteDirectory,"\0");
			strcpy(rcd.dirname,remoteDirectory);

			printf("\nChanging remote directory to %s for downloading the CDR files...\n",rcd.dirname);

			if(fti_rcd(&lai,&rcd,FTIEXBLK,&esr)) {
				printf("Cannot change remote directory to %s\n",cnt_details.ftam_remote_file_path);
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Can not change remote directory to %s", rcd.dirname);
				print_error_info( &esr );

				if(esr.errcode == FTIERCNE)
				{
					printf("\nConnection is lost\n");
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "Connection lost");		
				}
                if(!esr.errcnxs)
					return 1;
	
		   }
		   else { 
				printf("Remote directory changed to %s\n",rcd.dirname);

				pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"Remote directory changed to %s", rcd.dirname);
				break;
		   }
		}
		count_rcd_cdr++;
	}
	
	retValue = parse_dcf_file(& lai, cnt_details);

	if( retValue == 2){
		return 2;
	}
	if(retValue == 1)	//connection failure
		return 1;


	if( retValue == 3){
		//malloc has failed so disconnect .
		if (fti_disconnect(&lai,FTIEXBLK,&esr)){
			/* Error */
			#ifdef DEBUG
			printf("fti_disconnect FAILED\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Not able to disconnect from the server");
			print_error_info( &esr );
			exit(1);
		}
		else {     /* OK */
			#ifdef DEBUG
			printf("fti_disconnect SUCCEEDED\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"Disconnected from the server");
		}
		return 1;
	}	


	if( retValue == 0){

		printf( "\nNo file left to be downloaded\n");
		pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"%s", "No file left to be downloaded");


		if (fti_disconnect(&lai,FTIEXBLK,&esr)){
			/* Error */
			#ifdef DEBUG
			printf("fti_disconnect FAILED\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Not able to disconnect from the server");
			print_error_info( &esr );
			exit(1);
		}
        else {     /* OK */
			#ifdef DEBUG
			printf("fti_disconnect SUCCEEDED\n");
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"Disconnected from the server");
		}
    }

	return 0;
}


/*
	This function crates audit files.
*/
void
write_audit_file(char *filename, app_connect_to_ftam conn_struct, int scode){
        FILE            *fp;
        char            data[1024];
        char            delimiter[10];
        time_t          result;
        char            timestamp[20];
        char            status[20];
        char            outfile[1024];
        char            temp[10];

        memset(data, 0, sizeof(data));
        memset(delimiter, 0, sizeof(delimiter));
        memset(timestamp, 0, sizeof(timestamp));
        memset(status, 0, sizeof(status));
        memset(outfile, 0, sizeof(outfile));
        memset(temp, 0, sizeof(temp));

		        pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
		                     "%s", "Entering into  write_audit_file function");
        strcpy(outfile, conn_struct.ftam_audit_file_path);
        strcat(outfile, "/");
        strcat(outfile, conn_struct.audit_file_name);
        strcat(outfile, "_");
        result = time(NULL);
        cftime(timestamp,"%Y%m%d%H%M%S", &result);
        cftime(temp, "%b", &result);
        strcat(outfile, temp);
        memset(temp, 0, sizeof(temp));
        cftime(temp, "%d", &result);
        strcat(outfile, temp);
        strcat(outfile, conn_struct.audit_file_name_suffix);

        fp = fopen(outfile, "a");
        if (fp == NULL) {
                fprintf(stdout,"\nUnable to create output file\n");
                fprintf(stdout,"\nExiting... \n\n");
                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                      "%s", "Unable to create output file. Exiting...");
                exit(1);
        }
        sprintf(delimiter,"%s",";");
        if(scode == 1){
                sprintf(status,"%s","success");
        } else{
                sprintf(status,"%s","failed");
        }
        sprintf(data, "%s%s%s%s%s\n", filename, delimiter, timestamp, delimiter, status);
		// sprintf(data, "%s%s%s\n", filename, delimiter, timestamp);

        if( fwrite( data, strlen(data), 1, fp) != 1 ){
                pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
                      "%s", "Unable to write to the audit file.");
                printf("Unable to write to file\n");
                fclose(fp);
        }
        fclose(fp);
		       pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
		                      "%s", "Returning from write_audit_file function");

}


/*
 *      PRINT_ERROR:
 *      ------------
 *      prints out the error status report structure in case an API function
 *      returns an error code.
 *      PARAMETERS: -> pointer to Execution Status Report structure to print
 */
void      print_error_info(
                    ftiesrTp      err_ptr
                 )
{
        char      st_status[MAXSTRLEN];

		#ifdef DEBUG
			fprintf( stderr, "Execution Status Report:\n" );
		#endif
		 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
						  "%s", "Execution Status Report:");

        switch( err_ptr->status ) {
        case      FTISTLOC: /* Local Error */
              strcpy( st_status, "LOCAL Error");
              break;
        case      FTISTSYS: /* System Error */
              strcpy( st_status, "SYSTEM Error");
              break;
        case      FTISTFTM: /* FTAM Error */
              strcpy( st_status, "FTAM Error");
              break;
        case      FTISTUFE: /* Unexpected FTAM Event Error */
              strcpy( st_status, "Unexpected FTAM Event");
              break;
        case      FTISTWAR: /* Local Warning */
              strcpy( st_status, "LOCAL WARNING");
              break;
        default            : /* Should not be possible */
              strcpy( st_status, "NO ERROR!");
        } /* switch status */


		if(st_status){
			#ifdef DEBUG
				 fprintf( stderr, "Status\t\t= %s\n", st_status);
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Error Status = %s", st_status);
		}

		#ifdef DEBUG
			fprintf( stderr, "Error Code\t= %d\n", err_ptr->errcode);
		#endif

		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Error Code\t= %d\n", err_ptr->errcode);
		/*	if(err_ptr->errcode)
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Error Code = %d", err_ptr->errcode);
			fprintf( stderr, "Error Type\t= %s\n", (err_ptr->errtype) ? "RECOVERABLE"
													   : "NOT RECOVERABLE");
		*/
		if(err_ptr->errtype) 
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Error type = %s", "RECOVERABLE");	
		}
		else
		{
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Error type = %s", "NOT RECOVERABLE");	
		}	
		
		#ifdef DEBUG
			fprintf( stderr, "Cnx Status\t= %s\n", (err_ptr->errcnxs) ? "ON" : "OFF" );
		#endif

		if(err_ptr->errcnxs){
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Connection status = %s", "ON"); 
		}
		else{
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Connection status = %s", "OFF");
		}

	
		/*
		if( err_ptr->status == FTISTFTM )
		{
			//            fprintf( stderr, "Diagnostic\t= %.4d\n", err_ptr->diag);
			//			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Diagnostic = %.4d", err_ptr->diag);
		}
		else if( err_ptr->status == FTISTSYS )
		{	
			//             fprintf( stderr, "Diagnostic\t= %s\n", strerror( err_ptr->diag) );
			//			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Diagnostic = %s", err_ptr->diag);
		}
		else    
		{
			//		   fprintf( stderr, "Diagnostic\t= %.8x\n", err_ptr->diag);
			//			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"Diagnostic = %.8x", err_ptr->diag);
		}
		*/
} /* print_error_info end */




/*
  * Frees the linked list
  *
*/
free_linked_list(struct file_info * start)
{
	struct file_info * tempNode = start;
	struct file_info * preTempNode;

	#ifdef DEBUG
		int countNode=0;
	#endif
	while(tempNode)
	{
		#ifdef DEBUG
			printf("\nFreeing node number %d***\n",countNode);
			printf("\ntempNode->name=%s***\n", tempNode->name);
			printf("\ntempNode->status =%c***\n", tempNode->status);
			printf("\ntempNode->tmpstamp=%s***\n", tempNode->tmpstamp);
			countNode++;
		#endif

		preTempNode = tempNode;
		tempNode = tempNode->next;		
		free(preTempNode);
	}
}


/*
  * Frees the linked list
  *
*/
free_list()
{
        struct node * tempNode = startp;
        struct node * preTempNode;

        #ifdef DEBUG
                int countNode=0;
        #endif
        while(tempNode)
        {
                #ifdef DEBUG
                printf("\nFreeing node number %d***\n",countNode);
                printf("\ntempNode->name=%s***\n", tempNode->name);
                countNode++;
                #endif
                preTempNode = tempNode;
                tempNode = tempNode->next;
                free(preTempNode);
        }
}


/*********************************************************************************************
* parses both the dcf files , creates a linked list and downloades after sorting
* return value : 0 if there are no TTFILEs to be downloaded
* 			   : 1 if connectin failed
* 			   : 2 if error occured while downloading TTFILE while connection still exists
* 			   :   or all TTFILEs are successfully downloaded
* 			   : 3 if malloc fails  
*********************************************************************************************/

int parse_dcf_file(ftilaiTp  lai, app_connect_to_ftam cnt_details)
{
	int count;
	int idx;
	FILE * fout;
	char tmp[400];
	char tmp1[400];
	char    auditfilename[50];
	char temporaryfilename[200];
	char tmpstamp[15];
	char tempFile[600];
	char touchFile[610];
	struct file_info  * fileInfo = NULL;
	struct file_info  * start;


	int i=0;
	count = 0;

	while(i<2)
	{

		switch(i)
		{
			case 0:
				if(!flag1)
				{
					#ifdef DEBUG
						printf("\nFirst dcf file is =%s***\n",cnt_details.dcf1);
					#endif

					sprintf(tmpfilename,"%s%s%s%s",cnt_details.ftam_temp_file_path,"/",cnt_details.dcf1,"\0");
				}
				else
				{
					i++;
					continue;
				}
				break;

			case 1:
				if(!flag2)
				{
					#ifdef DEBUG
						printf("\nSecond dcf file is =%s***\n",cnt_details.dcf2);
					#endif

					sprintf(tmpfilename,"%s%s%s%s",cnt_details.ftam_temp_file_path,"/",cnt_details.dcf2,"\0");
				}
				else
				{
					i++;
					goto OUT;	
				}
				break;

		}


		#ifdef DEBUG
		printf("\nAfter switch statement tmpfilename =%s***\n",tmpfilename);
		#endif
	
        if ((fout =fopen(tmpfilename,"r"))==NULL){
			printf("Unable to open local file %s\n",tmpfilename);
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"Unable to open local file %s", tmpfilename);
			pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
			"Exiting...");
			exit(1);
        }


        while(fgets (tmp, sizeof(tmp),fout) != NULL)
        {

			idx = strlen(tmp);
			tmp[idx-1]='\0';
		

			if(tmp[26] == 'F' || tmp[26] == 'S')
			{
				count++;

				if(count == 1)
				{
						fileInfo = (struct file_info *) malloc( sizeof(struct file_info) );
						start = fileInfo;
				}
				else
				{
						fileInfo->next = malloc(sizeof(struct file_info));
						fileInfo = fileInfo->next;
				}
				fileInfo->next = NULL;

				if(fileInfo == NULL){
					printf("\n malloc failed\n");
					pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "malloc failed");
					count --;
					return 3;
				}

				#ifdef DEBUG
					printf("\ncount=%d\n",count);
				#endif

				strncpy( fileInfo->name, tmp, 25);
				fileInfo->name[25]='\0';
				fileInfo->status = tmp[26];
				strncpy(fileInfo->tmpstamp,tmp+28,6);
				fileInfo->tmpstamp[6]='\0';
				strncpy(fileInfo->tmp_stamp,tmp+35,4);
				fileInfo->tmp_stamp[4]='\0';

				#ifdef DEBUG
					printf("\nfileInfo->tmpstamp=%s***\n",fileInfo->tmpstamp);
					printf("\nfileInfo->tmp_stamp=%s***\n",fileInfo->tmp_stamp);
				#endif

			}
        }
		i++;
        fclose(fout);
	}
	
	OUT:
	#ifdef DEBUG
		printf("\n1234567\n");
	#endif

	if(count == 0)
	{
		#ifdef DEBUG
		printf("\ncount=0\n");
		#endif

		return 0;
	}
	else
		if(count != 1)
			bubbleSort(& start,count);

	#ifdef DEBUG
	printf("\nCOUNT =%d***\n",count);
	getchar();
	#endif

	fileInfo = start;

	memset(& trf, 0 , sizeof(trf));
	trf.doctyp   = FTMDTFT3;        // type FTAM-3          
	trf.mode = FTMTMREP;

	#ifdef DEBUG
		printf("\nNumber of nodes in linked list count=%d***\n",count);
	#endif

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,"There are %d CDR files to be downloaded",count);

	while(fileInfo)
	{


		//Download the files mentioned in control file
		fileInfo -> name[13] = '\0';
		#ifdef DEBUG
		printf("\nfileinto->name=%s***\n",fileInfo->name);
		printf("\nfileinto->status=%c***\n",fileInfo->status);
		#endif
		strcpy(trf.remname,fileInfo->name);
		#ifdef DEBUG
		printf("\ntrf.remname=%s\n",trf.remname);
		#endif
		strcpy(auditfilename, fileInfo -> name);
		//                        strcpy(trf.locname,cnt_details.ftam_current_file_path);
		sprintf(trf.locname,"%s%s%s%s",cnt_details.ftam_temp_file_path,"/",fileInfo->name,"\0");
		#ifdef DEBUG
		printf("\ntrf.locname=%s\n",trf.locname);
		#endif

		printf("\nDownloading %s...\n",trf.remname);


		#ifdef DEBUG
		if (1)
		#else
		if (fti_get(lai,&trf,FTIEXBLK,&esr))
		#endif
					
		{
			printf("Could not download %s\n",trf.remname);
			print_error_info( &esr );

			if(esr.errcode == FTIERCNE)
			{
				printf("\nConnection is lost\n");
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"%s", "Connection lost");
				free_linked_list(start);
				return 1;
			}
			else if(esr.errcode == FTIEROLF)
			{
				#ifdef DEBUG
				printf("\nLocal file not found \n");
				#endif
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,"PATH FOR %s%s",cnt_details.dcf2," NOT VALID");
			}

			write_audit_file(auditfilename, cnt_details, 0);

			free_linked_list(start);

			if(! esr.errcnxs )
				return 1;
			return 2;
		}
		else {
			sprintf(temporaryfilename,"%s",cnt_details.tmp_file_path);
			strcpy(tmp1,fileInfo->name);
			#ifdef DEBUG
			printf("\n---tmp1---=%s***\n",tmp1);
			printf("\ntemporaryfilename=%s***\n",temporaryfilename);
			#endif

			tmp1[sizeof(tmp1)-1]='\0';

			#ifdef DEBUG
			printf("\ntmp1333=%s\n",tmp1);
			#endif

			//                      sprintf(tempFile,"%s%s%s%s",temporaryfilename,"/",tmp1,".tmp");
			sprintf(tempFile,"%s%s%s",temporaryfilename,"/",tmp1);

			#ifdef DEBUG
			printf("\ntempFile=%s***\n",tempFile);
			#endif

			sprintf(touchFile,"%s%s%s","touch \"",tempFile,"\"");
			#ifdef DEBUG
			printf("\ntouch temp file command is =%s***\n",touchFile);
			#endif

			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s%s", "Creating temporary file ",tempFile);

			int lscommand = system(touchFile);
			if(lscommand)
				pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", touchFile);


			printf("%s has been successfully downloaded\n",trf.remname);
			printf("\tBytes sent : %d\n",trf.result);
			printf("\tTime elapsed : %f seconds\n",trf.elapse);

			//write_audit_file(auditfilename, cnt_details, 1);

			#ifdef DEBUG
			printf("\nBefore rename\n");
			getchar();
			#endif

			int rename_ret = rename_file(cnt_details, fileInfo -> name, fileInfo -> tmpstamp,1);
			if(! rename_ret)
			{
				write_audit_file(auditfilename, cnt_details, 1);
			}
			else
			{
				write_audit_file(auditfilename, cnt_details, 0);
				exit(1);
			}

			#ifdef DEBUG
			printf("\nRemoving tempfile\n");
			getchar();
			#endif
			sprintf(touchFile,"%s%s%s","rm -f \"",tempFile,"\"");
			#ifdef DEBUG
			 printf("\nRemove temp file command is =%s***\n",touchFile);
			#endif
			pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
			"%s%s", "Removing temporary file ",touchFile);

			lscommand = system(touchFile);
			if(lscommand)
					 pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR, "command failed: %s", touchFile);


		}

		fileInfo = fileInfo ->next;

	}

	free_linked_list(start);
	return 2;

}




/*
 * Suffix timestamp to the file
*/

int
rename_file(app_connect_to_ftam cnt_details, char * name, char * timestamp, int flag_time){
	char            file_name[1024];
	time_t          result;
	char            mv_file[1024];
	char            orgfile[1024];

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
	                       "%s", "entering into rename_file function");
	memset(file_name, 0, sizeof(file_name));
	memset(orgfile, 0, sizeof(orgfile));
	memset(mv_file, 0, sizeof(mv_file));

	sprintf(orgfile, "%s%s%s", cnt_details.ftam_temp_file_path, "/", name);
	name[8] = '_';

	#ifdef DEBUG
	printf("\nflag_time=%d***\n",flag_time);
	#endif

	if(flag_time)
	sprintf(file_name, "%s%s%s%s%s%s", cnt_details.ftam_current_file_path, "/", name,".", "20",timestamp);
	else
	sprintf(file_name, "%s%s%s%s%s", cnt_details.ftam_current_file_path, "/", name,".", timestamp);

	#ifdef DEBUG
	printf("\nThe file after renaming is=%s***\n", file_name);
	#endif

	sprintf(mv_file, "%s %s%s%s %s%s%s", "mv ","\"", orgfile,"\"","\"" ,file_name,"\"");

	#ifdef DEBUG
	printf("Move command is =%s***\n",mv_file);
	#endif

	int ret_move = system(mv_file);
	if(ret_move)
	{
		pinlog(__FILE__, __LINE__, LOG_FLAG_ERROR,
				"Move command failed with exit code %d\n",ret_move);

		return 1;
	}
	else
	{
		return 0;
	}

	pinlog(__FILE__, __LINE__, LOG_FLAG_DEBUG,
				"%s", "Returning from rename_file function");
}

void swap(struct file_info ** start, struct file_info ** pretemp, struct file_info **temp)
{
	#ifdef DEBUG
	printf("\nEntering into swap function\n");
	#endif

	struct file_info *next, *p;

	if(*temp == *start){
		printf("\n2\n");
		p = (*start) -> next;
		(*start) -> next = p->next;
		p->next =*start;
		*start = p;
		*pretemp = p;
		//		*temp = p;
	}
	else{

		if(*temp!=NULL)
		{
			printf("\n3\n");
			next = (*temp) -> next;
			(*pretemp) ->next = next;

			if(next != NULL){
				(*temp)-> next = next -> next;
				next -> next =*temp;
			}
		}
		*pretemp = (*pretemp)-> next;
	}
	//	 *temp = (*pretemp)-> next;
}


void bubbleSort(struct file_info ** start, int count )
{
	int ii, kk, tt;
	struct file_info *temp, *pretemp, *next;

   /* Get the data */

   for ( kk = count-1; kk > 0; kk-- )
   {

		for ( ii = 0,pretemp = * start,temp = * start; ii < kk,temp!=NULL,temp->next!=NULL; ii++ )
		{
			int itmpstamp = atoi(temp->tmpstamp);
			int itmp_stamp = atoi(temp->tmp_stamp); 
			int inext_tmpstamp = atoi((temp -> next)->tmpstamp);
			int inext_tmp_stamp = atoi((temp -> next)->tmp_stamp);

			if((itmpstamp>inext_tmpstamp)||((itmpstamp == inext_tmpstamp) && (itmp_stamp > inext_tmp_stamp)))
			{
				//	   swap(&start,&pretemp,&temp);
				swap(start,&pretemp,&temp);
				continue;
			}

			pretemp = temp;

			temp = temp->next;

		} /* End of inner loop */

	}  /* End of outer loop */


	#ifdef DEBUG
	printf("\nTHE SORTED VALUES ARE:\n");
	temp = * start;

	for ( ii = 0; ii < count; ii++ )
	{
		printf("\ntemp->name=%s***\n", temp->name);
		//         printf("\ntemp->status =%c***\n", temp->status);
		printf("\ntemp->tmpstamp=%s***\n", temp->tmpstamp);
		printf("\ntemp->tmp_stamp=%s***\n\n\n", temp->tmp_stamp);

		temp = temp -> next;
	}
	printf("\n\n");
	getchar();
	#endif
}
