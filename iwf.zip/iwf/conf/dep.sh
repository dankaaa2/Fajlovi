#!/bin/ksh
# ==============================================================================
#
#           Copyright (c) 1998 - 2003 Portal Software (Hamburg) GmbH.
#                             All rights reserved.
#                This material is the confidential property of
#        Portal Software (Hamburg) GmbH or its subsidiaries or licensors
#     and may be used, reproduced, stored or transmitted only in accordance
#             with a valid Portal license or sublicense agreement.
#
# ------------------------------------------------------------------------------
#
#  Module Description:
#    Expand the registry
#
#  Open Points:
#
#
#  Review Status:
#
#
# ------------------------------------------------------------------------------
#  Responsible: Portal Software
#
#  $RCSfile: dep.sh,v $
#  $Revision: 1.19 $
#  $Author: pin12 $
#  $Date: 2007/01/15 10:55:28 $
# ------------------------------------------------------------------------------
#  History:
#  $Id: dep.sh,v 1.19 2007/01/15 10:55:28 pin12 Exp $
#  $Log: dep.sh,v $
#  Revision 1.19  2007/01/15 10:55:28  pin12
#  MANTIS ID 0002234: Automatic setting of BufferLimit and StoreLimit values before starting mediation framework
#
#  Revision 1.18  2006/12/27 09:27:11  pin12
#  Mantis ID: unknown
#  Setting of IFW_TS_DAT and IFW_TS_IDX for DEV environment and ODISEJA database
#
#  Revision 1.17  2006/06/23 13:13:24  pin27
#  2140:waldek:new logic for passwords
#
#  Revision 1.16  2006/02/22 12:27:06  pin27
#  MantisID: 1693
#  Committed by waldek
#  added argument info
#
#  Revision 1.15  2006/01/04 17:32:42  pin27
#  MantisID: 1407
#  Committed by waldek
#  corrected tablespaces for duplicate tables
#
#  Revision 1.14  2005/12/17 21:38:04  pin27
#  MantisID: 1323
#  Committed by waldek
#  integrity in reg.conf names added.
#
#  Revision 1.13  2005/11/28 19:15:37  pin41
#  MantisID: dep.sh
#  Committed by PSEI
#  INT_P has been changed to PIPE
#
#  Revision 1.12  2005/09/26 18:59:20  pin25
#  wkoko: corrected the pissing one index tblspace
#
#  Revision 1.11  2005/09/26 18:54:39  pin25
#  wkoko: corrected names of tablespaces for duplicate check
#
#  Revision 1.10  2005/09/20 16:55:40  pin
#  wkoko: corrected tablespaces for duplicate check for DEV enviroments
#
#  Revision 1.9  2005/08/31 13:16:29  pin27
#  wkoko: corrected few mistakes
#
#  Revision 1.8  2005/08/29 15:20:04  pin
#  wkoko: production, tablespaces for duplicate
#
#  Revision 1.7  2005/08/26 08:21:13  pin
#  wkoko: corrected spaces at the beginnig of input string
#
#  Revision 1.6  2005/08/26 08:05:56  pin
#  changes for production : wkoko
#
#  Revision 1.5  2005/08/25 17:16:29  pin
#  wkoko: production update
#
#  Revision 1.4  2005/06/09 12:30:44  pin09
#  RBF: changed port setup
#
#  Revision 1.3  2005/06/03 10:21:31  pin13
#  Added an error handling - wkokorzy
#
#  Revision 1.2  2005/04/19 17:57:10  pin27
#  Added real time port for rerating
#
#  Revision 1.1  2005/04/04 17:57:46  pin09
#  RBF: added deploymnet procedure
#
# ==============================================================================
. $HOME/cm/install/scripts/global_settings

FILE=reg.conf.$VAR_EXT_TYPE

# =================================================
# Beginning of if command
# =================================================
echo "Start of expanding registry $1"

if [[ $# = 0 ]];
then
  echo "Enviroment type is: $VAR_EXT_TYPE"
   IU=${TAG_IFW_USER}
   PU=${TAG_PIN_USER}
   PIN_P=${TAG_PIN_PASS}
   INT_P=${TAG_IFW_PASS}

  case $VAR_EXT_TYPE in
     DEV)
          USER_NUMBER=$(echo $LOGNAME | cut -c 4-5)
          IFW_TS_DAT=${TAG_TABLE_TBLSP}
          IFW_TS_IDX=${TAG_INDEX_TBLSP}
          ;;
     ROU)
          IFW_TS_DAT=PIN_DAT06
          IFW_TS_IDX=PIN_IDX06
          ;;
     ORA)
          ;;
     RAT)
          IFW_TS_DAT=PIN_DAT06
          IFW_TS_IDX=PIN_IDX06
          ;;
  esac

  echo "Integrate user is: $IU"
  echo "Integrate password is: $INT_P"
  echo "IFW_TS_DAT is: $IFW_TS_DAT"
  echo "IFW_TS_IDX is: $IFW_TS_IDX"

  IP=`$IFW_HOME/bin/dbPasswd <<EOF
${IU}
${INT_P}
${INT_P}
Y
EOF`

  if [[ $? -ne 0 ]]
     then
        echo "Error in execution "
        exit 1
     fi

  IP=`echo "${IP}" | awk '{ if ($1 == "Encrypted") {print $4} }'`

  echo "Infranet user is: $PU"
  echo "Infranet password is: $PIN_P"

  PP=`$IFW_HOME/bin/dbPasswd <<EOF
${PU}
${PIN_P}
${PIN_P}
Y
EOF`

  if [[ $? -ne 0 ]]
     then
        echo "Error in execution "
        exit 1
     fi

  PP=`echo "${PP}" | awk '{ if ($1 == "Encrypted") {print $4} }'`

  cp ${FILE} ${FILE}.exp
  sed s/@IFW_USER/${IU}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@PIN_USER/${PU}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@IFW_PASSWD/${IP}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@PIN_PASSWD/${PP}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@PIN_DB/${PIN_DB}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@IFW_TS_DAT/${IFW_TS_DAT}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@IFW_TS_IDX/${IFW_TS_IDX}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@USER_NUMBER/${USER_NUMBER}/g ${FILE}.exp > ${FILE}.tmp 
  mv ${FILE}.tmp ${FILE}.exp
  BUFFER_LIMIT=`date '+ %Y%m%d' | cut -c 2-9`
  STORE_LIMIT=`date '+ %Y%m01' | cut -c 2-9`
  echo "BUFFER_LIMIT is "$BUFFER_LIMIT
  echo "STORE_LIMIT is "$STORE_LIMIT
  sed s/@IFW_BUFFER_LIMIT/$BUFFER_LIMIT/g ${FILE}.exp > ${FILE}.tmp
  mv ${FILE}.tmp ${FILE}.exp
  sed s/@IFW_STORE_LIMIT/$STORE_LIMIT/g ${FILE}.exp > ${FILE}.tmp
  mv ${FILE}.tmp ${FILE}.exp
# ================================================
# else section
# ================================================
else
  cp ${1} ${1}.exp
  while read PARAM1 PARAM2
  do
    #sed 's@'${PARAM1}'@'${PARAM2}'@g' ${1}.exp > ${1}.tmp 
    sed s/${PARAM1}/${PARAM2}/g ${1}.exp > ${1}.tmp 
    mv ${1}.tmp ${1}.exp
  done < ${FILE}.exp
fi
# ================================================
# end of if clause
# ================================================
